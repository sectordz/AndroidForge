package com.bekri.wordreminder

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

 data class Word(val pt: String, val ar: String)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("words", MODE_PRIVATE) }
    private val words = mutableListOf<Word>()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadWords()
        buildUi()
        askNotificationPermission()
        updateStatus()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        root.addView(TextView(this).apply { text = "كلمات البرتغالية 🇵🇹"; textSize = 25f; gravity = Gravity.CENTER; setPadding(0, 4, 0, 18) })
        root.addView(TextView(this).apply { text = "أضف كلماتك وترجمتها. سيظهر إشعار كل 5 دقائق من 08:00 إلى 22:00."; textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 0, 0, 16) })
        status = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 0, 0, 12) }
        root.addView(status)
        root.addView(Button(this).apply { text = "＋ إضافة كلمة"; setOnClickListener { editWord(null) } })
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        controls.addView(Button(this).apply { text = "▶ تشغيل التذكير"; setOnClickListener { requestExactAlarmThenSchedule() } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        controls.addView(Button(this).apply { text = "■ إيقاف"; setOnClickListener { ReminderScheduler.cancel(this@MainActivity); updateStatus("تم إيقاف التذكيرات") } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(controls)
        root.addView(TextView(this).apply { text = "كلماتك (اضغط للتعديل، واضغط مطولًا للحذف)"; textSize = 17f; setPadding(0, 20, 0, 8) })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        renderWords()
    }

    private fun editWord(existing: Int?) {
        val pt = EditText(this).apply { hint = "الكلمة بالبرتغالية"; textSize = 18f; setSingleLine(true); if (existing != null) setText(words[existing].pt) }
        val ar = EditText(this).apply { hint = "الترجمة بالعربية"; textSize = 18f; setSingleLine(true); if (existing != null) setText(words[existing].ar) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0); addView(pt); addView(ar) }
        AlertDialog.Builder(this).setTitle(if (existing == null) "إضافة كلمة" else "تعديل الكلمة").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val p = pt.text.toString().trim(); val a = ar.text.toString().trim()
                if (p.isNotEmpty() && a.isNotEmpty()) { if (existing == null) words.add(Word(p, a)) else words[existing] = Word(p, a); saveWords(); renderWords() }
                else Toast.makeText(this, "اكتب الكلمة والترجمة", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun renderWords() {
        list.removeAllViews()
        if (words.isEmpty()) list.addView(TextView(this).apply { text = "لم تضف كلمات بعد. ابدأ بإضافة أول كلمة."; textSize = 16f; setPadding(8, 16, 8, 16) })
        words.forEachIndexed { i, w ->
            val row = TextView(this).apply {
                text = "${w.pt}\n${w.ar}"; textSize = 18f; setPadding(16, 14, 16, 14)
                setBackgroundResource(android.R.drawable.list_selector_background)
                setOnClickListener { editWord(i) }
                setOnLongClickListener { AlertDialog.Builder(this@MainActivity).setMessage("حذف ${w.pt}؟").setPositiveButton("حذف") { _, _ -> words.removeAt(i); saveWords(); renderWords() }.setNegativeButton("إلغاء", null).show(); true }
            }
            list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val divider = View(this).apply { setBackgroundColor(0xFFE0E0E0.toInt()) }
            list.addView(divider, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        }
    }

    private fun loadWords() {
        words.clear()
        val arr = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) { val o = arr.optJSONObject(i) ?: continue; words.add(Word(o.optString("pt"), o.optString("ar"))) }
    }
    private fun saveWords() { val arr = JSONArray(); words.forEach { arr.put(JSONObject().put("pt", it.pt).put("ar", it.ar)) }; prefs.edit().putString("items", arr.toString()).apply() }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
    }
    private fun requestExactAlarmThenSchedule() {
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))); Toast.makeText(this, "اسمح للتطبيق بالمنبّهات الدقيقة ثم ارجع واضغط تشغيل", Toast.LENGTH_LONG).show(); return }
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) { askNotificationPermission(); Toast.makeText(this, "اسمح بالإشعارات ثم اضغط تشغيل مرة أخرى", Toast.LENGTH_LONG).show(); return }
        ReminderScheduler.scheduleNext(this)
        updateStatus("التذكير يعمل: كل 5 دقائق بين 08:00 و22:00")
    }
    private fun updateStatus(message: String? = null) { status.text = message ?: "عدد الكلمات المحفوظة: ${words.size}\nالتذكير: كل 5 دقائق، 08:00–22:00" }
}

object ReminderScheduler {
    fun scheduleNext(context: Context) {
        val now = System.currentTimeMillis()
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = now }
        val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
        if (hour >= 22 || hour < 8) {
            if (hour >= 22) { cal.add(java.util.Calendar.DAY_OF_YEAR, 1) }
            cal.set(java.util.Calendar.HOUR_OF_DAY, 8); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
            setAlarm(context, cal.timeInMillis); return
        }
        setAlarm(context, now + 5 * 60 * 1000L)
    }
    private fun setAlarm(context: Context, at: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(context, 12, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) else am.setExact(AlarmManager.RTC_WAKEUP, at, pi)
    }
    fun cancel(context: Context) { val pi = PendingIntent.getBroadcast(context, 12, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi) }
}

class ReminderReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
        val arr = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        val now = java.util.Calendar.getInstance(); val hour = now.get(java.util.Calendar.HOUR_OF_DAY)
        if (hour in 8..21 && arr.length() > 0) {
            val index = prefs.getInt("next_index", 0).let { if (it >= arr.length()) 0 else it }
            val item = arr.optJSONObject(index)
            if (item != null) {
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(android.app.NotificationChannel("words", "تذكير الكلمات", android.app.NotificationManager.IMPORTANCE_DEFAULT))
                val open = PendingIntent.getActivity(context, 2, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val notification = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, "words") else android.app.Notification.Builder(context)
                notification.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(item.optString("pt")).setContentText(item.optString("ar")).setStyle(android.app.Notification.BigTextStyle().bigText("${item.optString("pt")} — ${item.optString("ar")}" )).setContentIntent(open).setAutoCancel(true)
                manager.notify(1001, notification.build())
                prefs.edit().putInt("next_index", (index + 1) % arr.length()).apply()
            }
        }
        ReminderScheduler.scheduleNext(context)
    }
}

class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) { if (intent?.action == Intent.ACTION_BOOT_COMPLETED) ReminderScheduler.scheduleNext(context) }
}
