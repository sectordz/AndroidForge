// ─── background_task.dart ────────────────────────────────────────────────────
//
// FIX SUMMARY:
//
// BUG — BackgroundIsolateBinaryMessenger was required only for platform
//       channels (MethodChannel / EventChannel). youtube_explode_dart uses
//       pure Dart HTTP (dart:io / http package) — zero platform channels.
//       The token parameter was cargo-cult boilerplate that served no purpose.
//
// BUG — The [token] parameter forced the caller (audio_handler.dart) to wrap
//       this function in Isolate.run(). That spawns a NEW isolate for EVERY
//       song. Isolates do NOT share heap, so the YoutubeExplode singleton in
//       stream_service.dart was destroyed and re-created for every fetch,
//       completely negating the singleton fix.
//
// FIX — Remove the token/isolate coupling. getStreamInfo() is now a plain
//       async function. audio_handler.dart calls it with a bare `await`.
//       The singleton in stream_service.dart now actually persists across calls
//       (same heap, same HTTP session, same connection pool).
//
// NOTE — If you later add a platform channel to stream fetching (unlikely but
//        possible), re-introduce BackgroundIsolateBinaryMessenger at that point.

import 'package:harmonymusic/services/stream_service.dart';

/// Fetch stream metadata for [songId] and return it as a JSON-serialisable map.
///
/// Strips the "MPED" prefix that Harmony Music prepends to some internal IDs
/// before passing the clean YouTube video ID to [StreamProvider.fetch].
///
/// Called from [MyAudioHandler.checkNGetUrl] with a plain `await` (no isolate).
Future<Map<String, dynamic>> getStreamInfo(String songId) async {
  // Internal IDs for Piped-sourced songs are prefixed with "MPED".
  if (songId.length >= 4 && songId.substring(0, 4) == "MPED") {
    songId = songId.substring(4);
  }

  final result = await StreamProvider.fetch(songId);
  return result.hmStreamingData;
}
