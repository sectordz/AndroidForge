// ─── constant.dart ───────────────────────────────────────────────────────────
// FIX: Updated Chrome user-agent from 114 (August 2023) to 128 (2024).
//
// YouTube and YouTube Music fingerprint the UA string. Chrome 114 is over a
// year old and triggers heightened bot-detection scrutiny; a modern UA reduces
// that friction. Keep this in sync with whatever Chrome stable is at the time
// of your next build — the version alone is what matters.

const domain = "https://music.youtube.com/";
const String baseUrl = '${domain}youtubei/v1/';

// The API key below is the public innertube key embedded in the YouTube Music
// web app. It is read from the page JS at runtime by the real client; pinning
// it here is consistent with what all open-source YTM clients do.
const fixedParms =
    '?prettyPrint=false&alt=json&key=AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30';

// Chrome 128 stable (released August 2024). Update to latest stable when you
// notice increased 429 / bot-challenge rates.
const userAgent =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36';
