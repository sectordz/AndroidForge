// ─── stream_service.dart ─────────────────────────────────────────────────────
//
// FIX SUMMARY (three independent bugs fixed here):
//
// BUG 1 — New YoutubeExplode() on every call (primary rate-limit cause)
// -----------------------------------------------------------------------
// The old code did:
//   static Future<StreamProvider> fetch(String videoId) async {
//     final yt = YoutubeExplode();  // ← NEW INSTANCE EVERY SONG
//     // ... yt.close() was never called
//   }
//
// YouTube (and YT Music) rate-limit based on HTTP session fingerprinting.
// A brand-new YoutubeExplode instance means a brand-new http.Client with fresh
// connection pool, no cookies, no session continuity. YouTube sees a flood of
// novel clients and triggers 429 (Too Many Requests).
//
// NewPipe avoids this by keeping a single persistent YoutubeHttpDataSource
// across the app lifetime — same connection pool, same session headers, same
// request-number counter (rn param). We replicate that with _YtClientSingleton.
//
// BUG 2 — Connection / memory leak
// ----------------------------------
// YoutubeExplode wraps a dart:http Client. Calling close() on it is mandatory
// to release socket handles. The old code never closed it, leaking one Client
// per song play for the lifetime of the process.
//
// BUG 3 — Zero retry on transient errors
// ----------------------------------------
// A single 429, DNS hiccup, or temporary YouTube blip permanently failed the
// song. We now retry up to 4 times with exponential backoff + jitter, mirroring
// the resilience pattern used by NewPipe's ExtractorHelper.

import 'dart:io';
import 'dart:math';

import 'package:youtube_explode_dart/youtube_explode_dart.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Singleton wrapper — one YoutubeExplode for the entire app lifetime.
//
// IMPORTANT: This singleton lives on the main isolate. For it to work, the
// stream fetch must NOT be wrapped in Isolate.run() — see the companion fix
// in audio_handler.dart / background_task.dart.
// ─────────────────────────────────────────────────────────────────────────────
class _YtClient {
  _YtClient._();

  static YoutubeExplode? _instance;
  static int _consecutiveErrors = 0;

  // After this many consecutive failures we assume the session is poisoned
  // and recycle the client (get a fresh HTTP session from YouTube).
  static const int _maxErrorsBeforeReset = 5;

  static YoutubeExplode get instance {
    _instance ??= YoutubeExplode();
    return _instance!;
  }

  /// Gracefully close and nullify the current client.
  /// The next call to [instance] will create a fresh one.
  static void reset() {
    try {
      _instance?.close();
    } catch (_) {
      // close() can throw if the underlying socket is already gone — ignore.
    } finally {
      _instance = null;
      _consecutiveErrors = 0;
    }
  }

  static void onSuccess() => _consecutiveErrors = 0;

  static void onError() {
    _consecutiveErrors++;
    if (_consecutiveErrors >= _maxErrorsBeforeReset) {
      reset(); // Force fresh session on next call
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// StreamProvider
// ─────────────────────────────────────────────────────────────────────────────
class StreamProvider {
  final bool playable;
  final List<Audio>? audioFormats;
  final String statusMSG;

  StreamProvider({
    required this.playable,
    this.audioFormats,
    this.statusMSG = "",
  });

  // ───────────────────────────────────────────────────────────────────────────
  // fetch() — with exponential-backoff retry
  //
  // Retry schedule (base delay doubles each attempt, ±200 ms jitter):
  //   Attempt 1 — immediate
  //   Attempt 2 — ~1 000 ms
  //   Attempt 3 — ~2 000 ms
  //   Attempt 4 — ~4 000 ms (hard cap)
  //
  // "Definitive" errors (unplayable, unavailable, purchase required) are NOT
  // retried — YouTube has told us the answer; extra requests would just add
  // noise and increase the chance of further rate-limiting.
  // ───────────────────────────────────────────────────────────────────────────
  static Future<StreamProvider> fetch(
    String videoId, {
    int maxAttempts = 4,
  }) async {
    final rng = Random();

    for (int attempt = 0; attempt < maxAttempts; attempt++) {
      // Exponential back-off with ±200 ms jitter (skip on first attempt).
      if (attempt > 0) {
        final baseMs = 1000 * (1 << (attempt - 1)); // 1 000, 2 000, 4 000
        final jitterMs = rng.nextInt(401) - 200; //  −200 … +200
        final delayMs = (baseMs + jitterMs).clamp(100, 4000);
        await Future.delayed(Duration(milliseconds: delayMs));
      }

      final yt = _YtClient.instance;

      try {
        final manifest = await yt.videos.streamsClient.getManifest(videoId);
        final audioStreams = manifest.audioOnly;

        _YtClient.onSuccess();

        return StreamProvider(
          playable: true,
          statusMSG: "OK",
          audioFormats: audioStreams
              .map(
                (s) => Audio(
                  itag: s.tag,
                  audioCodec:
                      s.audioCodec.contains('mp') ? Codec.mp4a : Codec.opus,
                  bitrate: s.bitrate.bitsPerSecond,
                  duration: s.duration ?? 0,
                  loudnessDb: s.loudnessDb,
                  url: s.url.toString(),
                  size: s.size.totalBytes,
                ),
              )
              .toList(),
        );
      } catch (e) {
        // ── Definitive errors — no retry ──────────────────────────────────
        if (e is VideoUnplayableException) {
          return StreamProvider(
            playable: false,
            statusMSG: e.reason ?? "Song is unplayable",
          );
        }
        if (e is VideoRequiresPurchaseException) {
          return StreamProvider(
            playable: false,
            statusMSG: "Song requires purchase",
          );
        }
        if (e is VideoUnavailableException) {
          return StreamProvider(
            playable: false,
            statusMSG: "Song is unavailable",
          );
        }

        // ── Transient errors — retry ───────────────────────────────────────
        _YtClient.onError(); // may trigger client reset after N failures

        if (e is SocketException) {
          if (attempt < maxAttempts - 1) continue;
          return StreamProvider(
            playable: false,
            statusMSG: "networkError",
          );
        }

        if (e is YoutubeExplodeException) {
          // Covers HTTP 429, parse errors, signature errors, etc.
          if (attempt < maxAttempts - 1) continue;
          return StreamProvider(
            playable: false,
            statusMSG: e.message,
          );
        }

        // Unknown — still retry; return on last attempt.
        if (attempt < maxAttempts - 1) continue;
        return StreamProvider(
          playable: false,
          statusMSG: "Unknown error: ${e.runtimeType}",
        );
      }
    }

    // Dart requires a return after the loop; the loop itself always returns or
    // continues, so this line is unreachable.
    return StreamProvider(
      playable: false,
      statusMSG: "Max retries exceeded",
    );
  }

  // ── Quality selectors ──────────────────────────────────────────────────────

  /// Prefer Opus 160 kbps (itag 251) then AAC 128 kbps (itag 140).
  Audio? get highestQualityAudio => audioFormats?.lastWhere(
        (a) => a.itag == 251 || a.itag == 140,
        orElse: () => audioFormats!.first,
      );

  /// AAC only — itag 140 (128 kbps) → itag 139 (48 kbps).
  Audio? get highestBitrateMp4aAudio => audioFormats?.lastWhere(
        (a) => a.itag == 140 || a.itag == 139,
        orElse: () => audioFormats!.first,
      );

  /// Opus only — itag 251 (160 kbps) → itag 250 (70 kbps).
  Audio? get highestBitrateOpusAudio => audioFormats?.lastWhere(
        (a) => a.itag == 251 || a.itag == 250,
        orElse: () => audioFormats!.first,
      );

  /// Low-quality fallback — itag 249 (Opus 50 kbps) or itag 139 (AAC 48 kbps).
  Audio? get lowQualityAudio => audioFormats?.lastWhere(
        (a) => a.itag == 249 || a.itag == 139,
        orElse: () => audioFormats!.first,
      );

  Map<String, dynamic> get hmStreamingData => {
        "playable": playable,
        "statusMSG": statusMSG,
        "lowQualityAudio": lowQualityAudio?.toJson(),
        "highQualityAudio": highestQualityAudio?.toJson(),
      };
}

// ─────────────────────────────────────────────────────────────────────────────
// Audio model — unchanged from original except extension to Duration cast
// ─────────────────────────────────────────────────────────────────────────────
class Audio {
  final int itag;
  final Codec audioCodec;
  final int bitrate;
  final int duration;
  final int size;
  final double loudnessDb;
  final String url;

  Audio({
    required this.itag,
    required this.audioCodec,
    required this.bitrate,
    required this.duration,
    required this.loudnessDb,
    required this.url,
    required this.size,
  });

  Map<String, dynamic> toJson() => {
        "itag": itag,
        "audioCodec": audioCodec.toString(),
        "bitrate": bitrate,
        "loudnessDb": loudnessDb,
        "url": url,
        "approxDurationMs": duration,
        "size": size,
      };

  factory Audio.fromJson(Map json) => Audio(
        audioCodec: (json["audioCodec"] as String).contains("mp4a")
            ? Codec.mp4a
            : Codec.opus,
        itag: json['itag'] as int,
        duration: (json["approxDurationMs"] ?? 0) as int,
        bitrate: (json["bitrate"] ?? 0) as int,
        loudnessDb: ((json['loudnessDb']) as num?)?.toDouble() ?? 0.0,
        url: json['url'] as String,
        size: (json["size"] ?? 0) as int,
      );
}

enum Codec { mp4a, opus }

// Extension so Duration? casts from StreamInfo don't need explicit handling.
extension _DurationExt on Duration? {
  int get msOrZero => this?.inMilliseconds ?? 0;
}
