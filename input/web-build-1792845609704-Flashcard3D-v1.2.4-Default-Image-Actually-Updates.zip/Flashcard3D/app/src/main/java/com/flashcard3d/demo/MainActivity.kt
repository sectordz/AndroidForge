package com.flashcard3d.demo

import android.app.Activity
import android.content.Intent
import android.content.ContentValues
import android.provider.MediaStore
import android.os.Build
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.speech.tts.TextToSpeech
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.w3c.dom.Element
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.Locale
import android.util.Base64
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val excelRequestCode = 4107
    private val imageRequestCode = 4108
    private var pendingImageKey: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(2, 9, 26)
        window.navigationBarColor = android.graphics.Color.rgb(2, 9, 26)
        tts = TextToSpeech(this, this)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        @Suppress("DEPRECATION")
        webView.settings.allowFileAccessFromFileURLs = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(VoiceBridge(), "NativeVoice")
        webView.addJavascriptInterface(FileBridge(), "NativeFiles")
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(true)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = 0
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale.forLanguageTag("pt-PT")
        }
    }

    inner class VoiceBridge {
        @JavascriptInterface fun speak(text: String, language: String) {
            runOnUiThread {
                if (!ttsReady) return@runOnUiThread
                val locale = if (language == "ar") Locale.forLanguageTag("ar") else Locale.forLanguageTag("pt-PT")
                val result = tts?.setLanguage(locale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.getDefault())
                }
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "flashcard-" + System.currentTimeMillis())
            }
        }
    }

    inner class FileBridge {
        @JavascriptInterface fun pickExcel() {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            "text/csv", "text/comma-separated-values", "application/octet-stream"
                        ))
                    }
                    startActivityForResult(intent, excelRequestCode)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر فتح الملفات", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface fun pickWordImage(wordKey: String) {
            runOnUiThread {
                try {
                    pendingImageKey = wordKey.trim()
                    if (pendingImageKey.isBlank()) {
                        Toast.makeText(this@MainActivity, "تعذر تحديد الكلمة", Toast.LENGTH_SHORT).show()
                        return@runOnUiThread
                    }
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "image/*"
                    }
                    startActivityForResult(intent, imageRequestCode)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر فتح معرض الصور", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface fun getWordImageUrl(wordKey: String): String {
            return try {
                val uri = findSharedImageUri(wordKey) ?: return ""
                val bytes = contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Cannot read saved image" }.readBytes()
                }
                "data:image/png;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
            } catch (e: Exception) {
                android.util.Log.e("FlashcardImage", "Failed to load persistent image", e)
                ""
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == imageRequestCode) {
            if (resultCode != RESULT_OK) return
            val imageUri = data?.data ?: return
            val key = pendingImageKey
            try {
                val dataUrl = saveWordImage(imageUri, key)
                pendingImageKey = ""
                val safeKey = JSONObject.quote(key)
                val safeDataUrl = JSONObject.quote(dataUrl)
                webView.evaluateJavascript("window.onWordImageSaved && window.onWordImageSaved($safeKey, $safeDataUrl);", null)
                Toast.makeText(this, "تم حفظ الصورة وتحديث البطاقة", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                android.util.Log.e("FlashcardImage", "Failed to save selected image", e)
                Toast.makeText(this, "تعذر حفظ الصورة. جرّب صورة أخرى.", Toast.LENGTH_LONG).show()
            }
            return
        }
        if (requestCode != excelRequestCode || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val json = readWorkbook(uri)
            if (json.length() == 0) throw IllegalArgumentException("empty")
            val safe = JSONObject.quote(json.toString())
            webView.evaluateJavascript("window.importRowsFromNative && window.importRowsFromNative(JSON.parse($safe));", null)
        } catch (e: Exception) {
            android.util.Log.e("FlashcardExcel", "Failed to parse XLSX", e)
            Toast.makeText(this, "تعذرت قراءة ملف Excel. تأكد أنه ملف .xlsx صالح وغير محمي بكلمة مرور.", Toast.LENGTH_LONG).show()
        }
    }

    // Store user-selected images in the shared Pictures collection, not app-private storage.
    // Android's "Clear storage" removes app-private files but leaves these images intact.
    private fun imageNameForKey(key: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(key.trim().toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) } + ".png"
    }

    private fun findSharedImageUri(key: String): Uri? {
        val name = imageNameForKey(key)
        val projection = arrayOf(MediaStore.Images.Media._ID)
        val selection = "${MediaStore.Images.Media.DISPLAY_NAME}=?"
        val collections = linkedSetOf<Uri>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                for (volume in MediaStore.getExternalVolumeNames(this)) {
                    collections.add(MediaStore.Images.Media.getContentUri(volume))
                }
            } catch (_: Exception) { }
        }
        collections.add(MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        for (collection in collections) {
            try {
                contentResolver.query(collection, projection, selection, arrayOf(name), null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                        return Uri.withAppendedPath(collection, id.toString())
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w("FlashcardImage", "Image lookup failed in $collection", e)
            }
        }
        return null
    }

    private fun saveWordImage(uri: Uri, key: String): String {
        require(key.isNotBlank()) { "Missing word key" }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri).use { stream ->
            requireNotNull(stream) { "Cannot open selected image" }
            BitmapFactory.decodeStream(stream, null, bounds)
        }
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Invalid image" }
        var sample = 1
        while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bitmap = contentResolver.openInputStream(uri).use { stream ->
            requireNotNull(stream) { "Cannot reopen selected image" }
            BitmapFactory.decodeStream(stream, null, options)
        } ?: throw IllegalArgumentException("Unsupported image")
        try {
            val encoded = ByteArrayOutputStream()
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, encoded)) throw IllegalStateException("PNG encoding failed")
            val imageBytes = encoded.toByteArray()
            val name = imageNameForKey(key)
            var target = findSharedImageUri(key)
            if (target == null) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Flashcard3D")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                }
                target = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Cannot create shared image")
            }
            contentResolver.openOutputStream(target, "wt").use { output ->
                requireNotNull(output) { "Cannot write shared image" }
                output.write(imageBytes)
                output.flush()
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                contentResolver.update(target, values, null, null)
            }
            // Return the saved bytes to WebView so the selected picture appears immediately,
            // even if the device's MediaStore query is temporarily stale.
            return "data:image/png;base64," + Base64.encodeToString(imageBytes, Base64.NO_WRAP)
        } finally {
            bitmap.recycle()
        }
    }

    private fun readWorkbook(uri: Uri): JSONArray {
        val entries = HashMap<String, ByteArray>()
        contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open file" }
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val out = ByteArrayOutputStream()
                        zip.copyTo(out)
                        entries[entry.name] = out.toByteArray()
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
        val firstSheetPath = firstWorksheetPath(entries)
        val sheetBytes = entries[firstSheetPath] ?: throw IllegalArgumentException("Missing worksheet")
        val shared = mutableListOf<String>()
        entries["xl/sharedStrings.xml"]?.let { bytes ->
            val doc = xmlDoc(bytes)
            val sis = doc.getElementsByTagName("si")
            for (i in 0 until sis.length) {
                val node = sis.item(i)
                val ts = (node as Element).getElementsByTagName("t")
                val sb = StringBuilder()
                for (j in 0 until ts.length) sb.append(ts.item(j).textContent ?: "")
                shared.add(sb.toString())
            }
        }
        val sheet = xmlDoc(sheetBytes)
        val rows = sheet.getElementsByTagName("row")
        val matrix = mutableListOf<List<String>>()
        val physicalRowNumbers = mutableListOf<Int>()
        for (r in 0 until rows.length) {
            val rowNode = rows.item(r) as Element
            val cells = rowNode.getElementsByTagName("c")
            val values = mutableMapOf<Int, String>()
            var maxCol = -1
            for (c in 0 until cells.length) {
                val cell = cells.item(c) as Element
                val ref = cell.getAttribute("r")
                val col = columnIndex(ref)
                if (col < 0) continue
                maxCol = maxOf(maxCol, col)
                val type = cell.getAttribute("t")
                val value = when (type) {
                    "s" -> {
                        val v = cell.getElementsByTagName("v")
                        if (v.length > 0) shared.getOrNull(v.item(0).textContent.toIntOrNull() ?: -1).orEmpty() else ""
                    }
                    "inlineStr" -> cell.getElementsByTagName("t").let { if (it.length > 0) it.item(0).textContent.orEmpty() else "" }
                    "b" -> cell.getElementsByTagName("v").let { if (it.length > 0 && it.item(0).textContent == "1") "true" else "false" }
                    else -> cell.getElementsByTagName("v").let { if (it.length > 0) it.item(0).textContent.orEmpty() else "" }
                }
                values[col] = value.trim()
            }
            if (maxCol >= 0) {
                matrix.add((0..maxCol).map { values[it].orEmpty() })
                physicalRowNumbers.add(rowNode.getAttribute("r").toIntOrNull() ?: (r + 1))
            }
        }
        if (matrix.size < 2) throw IllegalArgumentException("No rows")
        val embeddedImages = readEmbeddedImages(entries, firstSheetPath)
        val headers = matrix.first().mapIndexed { index, value -> if (value.isBlank()) "column_${index + 1}" else value.trim() }
        val result = JSONArray()
        for (rowIndex in 1 until matrix.size) {
            val row = matrix[rowIndex]
            if (row.all { it.isBlank() }) continue
            val obj = JSONObject()
            headers.forEachIndexed { index, header -> obj.put(header, row.getOrElse(index) { "" }) }
            val physicalRow = physicalRowNumbers.getOrElse(rowIndex) { rowIndex + 1 }
            obj.put("image", embeddedImages[physicalRow] ?: "")
            result.put(obj)
        }
        return result
    }


    /**
     * Extract pictures embedded in an XLSX drawing and map each picture to its worksheet row.
     * Excel anchors use zero-based row indexes; the returned map uses one-based worksheet rows.
     */
    private fun readEmbeddedImages(entries: Map<String, ByteArray>, sheetPath: String): Map<Int, String> {
        val result = mutableMapOf<Int, String>()
        val sheetDir = sheetPath.substringBeforeLast('/', "")
        val sheetName = sheetPath.substringAfterLast('/')
        val sheetRelsPath = if (sheetDir.isEmpty()) "_rels/$sheetName.rels"
            else "$sheetDir/_rels/$sheetName.rels"
        val sheetRelsBytes = entries[sheetRelsPath] ?: return result
        val relDoc = xmlDoc(sheetRelsBytes)
        val relNodes = relDoc.getElementsByTagName("Relationship")
        var drawingPath: String? = null
        for (i in 0 until relNodes.length) {
            val rel = relNodes.item(i) as Element
            if (rel.getAttribute("Type").endsWith("/drawing")) {
                drawingPath = resolveZipPath(sheetPath, rel.getAttribute("Target"))
                break
            }
        }
        val resolvedDrawing = drawingPath ?: return result
        val drawingBytes = entries[resolvedDrawing] ?: return result
        val drawingDir = resolvedDrawing.substringBeforeLast('/', "")
        val drawingName = resolvedDrawing.substringAfterLast('/')
        val drawingRelsPath = if (drawingDir.isEmpty()) "_rels/$drawingName.rels"
            else "$drawingDir/_rels/$drawingName.rels"
        val drawingRels = entries[drawingRelsPath] ?: return result
        val drawingRelDoc = xmlDoc(drawingRels)
        val imageTargets = mutableMapOf<String, String>()
        val imageRelNodes = drawingRelDoc.getElementsByTagName("Relationship")
        for (i in 0 until imageRelNodes.length) {
            val rel = imageRelNodes.item(i) as Element
            val id = rel.getAttribute("Id")
            val target = rel.getAttribute("Target")
            if (id.isNotBlank() && target.isNotBlank()) {
                imageTargets[id] = resolveZipPath(resolvedDrawing, target)
            }
        }
        val drawingDoc = xmlDoc(drawingBytes)
        val anchors = listOf("twoCellAnchor", "oneCellAnchor")
        for (anchorTag in anchors) {
            val anchorNodes = drawingDoc.getElementsByTagName(anchorTag)
            for (i in 0 until anchorNodes.length) {
                val anchor = anchorNodes.item(i) as Element
                val fromNodes = anchor.getElementsByTagName("from")
                if (fromNodes.length == 0) continue
                val rowNodes = (fromNodes.item(0) as Element).getElementsByTagName("row")
                if (rowNodes.length == 0) continue
                val excelRow = (rowNodes.item(0).textContent ?: "").trim().toIntOrNull() ?: continue
                // DrawingML uses the qualified tag name "a:blip" in many XLSX files.
                // getElementsByTagName("blip") does not match prefixed names when namespaceAware=false.
                val blips = anchor.getElementsByTagName("a:blip")
                val blip = if (blips.length > 0) {
                    blips.item(0) as Element
                } else {
                    val fallback = anchor.getElementsByTagName("blip")
                    if (fallback.length == 0) continue
                    fallback.item(0) as Element
                }
                val relId = blip.getAttribute("r:embed").ifBlank {
                    blip.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "embed")
                }.ifBlank {
                    // Fallback for XML parsers that retain a different qualified attribute name.
                    (0 until blip.attributes.length)
                        .map { blip.attributes.item(it) }
                        .firstOrNull { it.localName == "embed" || it.nodeName.endsWith(":embed") }
                        ?.nodeValue.orEmpty()
                }
                val mediaPath = imageTargets[relId] ?: continue
                val imageBytes = entries[mediaPath] ?: continue
                val ext = mediaPath.substringAfterLast('.', "png").lowercase()
                val mime = when (ext) {
                    "jpg", "jpeg", "jfif" -> "image/jpeg"
                    "gif" -> "image/gif"
                    "webp" -> "image/webp"
                    "bmp" -> "image/bmp"
                    "svg" -> "image/svg+xml"
                    else -> "image/png"
                }
                val dataUri = "data:$mime;base64," + Base64.encodeToString(imageBytes, Base64.NO_WRAP)
                result[excelRow + 1] = dataUri
            }
        }
        return result
    }

    private fun resolveZipPath(sourceFile: String, target: String): String {
        val combined = if (target.startsWith("/")) target.removePrefix("/")
            else sourceFile.substringBeforeLast('/', "").let { dir ->
                if (dir.isEmpty()) target else "$dir/$target"
            }
        val stack = mutableListOf<String>()
        for (part in combined.split('/')) {
            when (part) {
                "", "." -> {}
                ".." -> if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex)
                else -> stack.add(part)
            }
        }
        return stack.joinToString("/")
    }

    private fun firstWorksheetPath(entries: Map<String, ByteArray>): String {
        val workbook = entries["xl/workbook.xml"]
        val relationships = entries["xl/_rels/workbook.xml.rels"]
        if (workbook != null && relationships != null) {
            val workbookDoc = xmlDoc(workbook)
            val sheets = workbookDoc.getElementsByTagName("sheet")
            if (sheets.length > 0) {
                val relationId = (sheets.item(0) as Element).getAttribute("r:id")
                val relDoc = xmlDoc(relationships)
                val rels = relDoc.getElementsByTagName("Relationship")
                for (i in 0 until rels.length) {
                    val rel = rels.item(i) as Element
                    if (rel.getAttribute("Id") == relationId) {
                        val target = rel.getAttribute("Target").removePrefix("/")
                        val path = if (target.startsWith("xl/")) target else "xl/$target"
                        if (entries.containsKey(path)) return path
                    }
                }
            }
        }
        return "xl/worksheets/sheet1.xml"
    }

    // Android's built-in XML parser does not implement every Apache/Xerces feature URI.
    // Setting unsupported feature flags can throw ParserConfigurationException before an
    // otherwise valid XLSX worksheet is read. XLSX XML parts are local ZIP entries; disable
    // entity expansion and parse with the platform parser for Android compatibility.
    private fun xmlDoc(bytes: ByteArray) = DocumentBuilderFactory.newInstance().apply {
        isNamespaceAware = false
        isExpandEntityReferences = false
    }.newDocumentBuilder().parse(bytes.inputStream())

    private fun columnIndex(cellRef: String): Int {
        var result = 0
        var found = false
        for (ch in cellRef) {
            if (ch.isLetter()) {
                found = true
                result = result * 26 + (ch.uppercaseChar() - 'A' + 1)
            } else break
        }
        return if (found) result - 1 else -1
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        webView.destroy()
        super.onDestroy()
    }
}
