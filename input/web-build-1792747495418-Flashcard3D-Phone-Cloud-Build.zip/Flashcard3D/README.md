# Flashcard 3D — HTML/CSS/JavaScript + Three.js prototype

This is a standalone Android WebView app. The full learning interface is implemented in HTML5, CSS3, and JavaScript. Android/Kotlin remains only as the app shell and native Portuguese/Arabic text-to-speech bridge.

## Technologies
- HTML5: card structure and bilingual content
- CSS3: responsive layout, neon glass panels, 3D-like lighting, mobile-safe sizing and fallback animation
- JavaScript: interaction, settings, navigation feedback, audio controls and pointer/touch response
- Three.js/WebGL: transparent character artwork rendered as a textured plane in a 3D scene with perspective, floating animation and touch/mouse tilt
- The character artwork is packaged as `app/src/main/assets/avo-grandfather.glb` and loaded with Three.js GLTFLoader. This GLB contains a textured 2D cutout on a 3D plane, with perspective, floating animation and touch/mouse tilt; it is not a sculpted or rigged 3D human model.
- Android WebView + Kotlin TextToSpeech bridge

## Build
Open the `Flashcard3D` folder in Android Studio and run/build the app. Internet access is currently used to load Three.js from jsDelivr. If that CDN is unavailable, the bundled CSS image fallback still displays the card.

## Notes
- The app has one sample word: `avô` (الجدّ), one Portuguese example and Arabic translation.
- The project is source code; a successful APK build has not been verified in this environment.


## Applied vocabulary update (2026-10-23)
The app now opens on the first of ten Portuguese vocabulary cards, from também through a televisão. Each card loads its own image from app/src/main/assets/vocab/word_001.jpg through word_010.jpg. The legacy grandfather GLB is retained in the project but is not displayed by the vocabulary screen. This is source code; build and install a new APK in Android Studio to see the change on the phone.
