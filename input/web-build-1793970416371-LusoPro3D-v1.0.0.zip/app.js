const words=[
{pt:"Saudade",ar:"الشوق والحنين",ex:"Tenho saudades de casa.",tr:"أشتاق إلى المنزل.",level:"A2"},
{pt:"Trabalho",ar:"العمل",ex:"Vou para o trabalho.",tr:"أذهب إلى العمل.",level:"A1"},
{pt:"Aprender",ar:"يتعلم",ex:"Quero aprender português.",tr:"أريد تعلم البرتغالية.",level:"A1"},
{pt:"Autocarro",ar:"حافلة",ex:"Apanho o autocarro às oito.",tr:"أستقل الحافلة في الثامنة.",level:"A1"},
{pt:"Pequeno-almoço",ar:"وجبة الفطور",ex:"Tomo o pequeno-almoço todos os dias.",tr:"أتناول الفطور كل يوم.",level:"A1"},
{pt:"Desenvolvimento",ar:"تطوير",ex:"Gosto de desenvolvimento de aplicações.",tr:"أحب تطوير التطبيقات.",level:"B1"},
{pt:"Morada",ar:"عنوان",ex:"Qual é a sua morada?",tr:"ما عنوانك؟",level:"A2"},
{pt:"Comboio",ar:"قطار",ex:"O comboio chega às nove.",tr:"يصل القطار في التاسعة.",level:"A1"}
];
const lessons=[
["التحيات والتعارف","Cumprimentos e apresentações","Olá · Bom dia · Boa tarde","A1"],
["الأرقام والأيام","Números e dias da semana","Um · Dois · Segunda-feira","A1"],
["العائلة","A família","Mãe · Pai · Irmão","A1"],
["الطعام والشراب","Comida e bebidas","Água · Pão · Café","A1"],
["الحياة اليومية","A rotina diária","Acordar · Trabalhar · Dormir","A2"],
["السكن والعمل","Casa e trabalho","Morada · Emprego · Horário","A2"]
];
let page="home",level="A1",card=0,flipped=false,known=[],favorites=[],quizStep=0,quizScore=0,quizChoice=null,quizDone=false;
const app=document.querySelector("#app");
function nav(p){page=p;render();document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===p))}
document.querySelectorAll(".bottom-nav button").forEach(b=>b.onclick=()=>nav(b.dataset.page));
document.querySelector("#themeBtn").onclick=()=>document.body.classList.toggle("light");
function render(){
 if(page==="home") app.innerHTML=home();
 if(page==="dictionary") app.innerHTML=dictionary();
 if(page==="cards") app.innerHTML=cards();
 if(page==="lessons") app.innerHTML=lessonPage();
 if(page==="quiz") app.innerHTML=quizPage();
 if(page==="progress") app.innerHTML=progress();
 bind();
}
function home(){return `<section class="hero"><div class="muted">PORTUGUÊS EUROPEU 🇵🇹</div><h1>تعلم البرتغالية بثقة</h1><p>كلمات، قواعد، محادثات ونطق برتغالي أوروبي.</p><div class="hero-art">📚 🗣️ 🇵🇹</div><div class="levels">${["A1","A2","B1"].map(x=>`<button class="level ${level===x?"active":""}" data-level="${x}">${x}</button>`).join("")}</div></section><h2>ماذا تريد أن تتعلم اليوم؟</h2><div class="grid">${tile("📖","الدروس","تعلم خطوة بخطوة","lessons")}${tile("🔎","القاموس","بحث برتغالي وعربي","dictionary")}${tile("🃏","البطاقات","احفظ المفردات","cards")}${tile("🧩","الاختبارات","اختبر معلوماتك","quiz")}${tile("🎧","الاستماع","تدرب على السمع","dictionary")}${tile("💬","المحادثات","مواقف يومية","lessons")}</div><section class="panel"><div class="row"><strong>كلمة اليوم</strong><span class="muted">${words[0].level}</span></div><div class="word">Saudade</div><div class="translation">الشوق والحنين</div><div class="example">Tenho saudades de casa.</div><div class="muted">أشتاق إلى المنزل.</div><br><button class="btn" data-go="cards">ابدأ التعلم</button></section>`}
function tile(e,t,s,p){return `<button class="tile" data-go="${p}"><span class="emoji">${e}</span><strong>${t}</strong><small>${s}</small></button>`}
function dictionary(){return `<h1>القاموس الشامل</h1><p>ابحث بالبرتغالية أو العربية.</p><input id="search" class="search" placeholder="مثلاً: casa أو منزل"><div id="results">${wordResults("")}</div>`}
function wordResults(q){return words.filter(w=>(w.pt+" "+w.ar+" "+w.ex+" "+w.tr).toLowerCase().includes(q.toLowerCase())).map(w=>`<section class="panel"><div class="row"><div class="word">${w.pt}</div><button class="btn secondary" data-speak="${w.pt}">🔊</button></div><div class="translation">${w.ar}</div><div class="example">${w.ex}</div><div class="muted">${w.tr}</div><div class="row"><small class="muted">${w.level}</small><button class="btn secondary" data-fav="${w.pt}">${favorites.includes(w.pt)?"♥":"♡"}</button></div></section>`).join("")||`<p>لا توجد نتائج في القاموس التجريبي.</p>`}
function cards(){let w=words[card];return `<h1>البطاقات التعليمية</h1><p>اضغط على البطاقة لرؤية الترجمة.</p><section class="panel flashcard" id="flip"><div class="muted">${flipped?"الترجمة العربية":"Português europeu"}</div><div class="word">${flipped?w.ar:w.pt}</div><div class="example">${flipped?w.tr:w.ex}</div><div class="muted">${card+1} / ${words.length}</div></section><div class="row"><button class="btn secondary" id="prev">السابق</button><button class="btn" id="next">التالي</button></div><div class="row" style="margin-top:12px"><button class="btn secondary" id="known">✓ أعرفها</button><button class="btn secondary" id="fav">♡ المفضلة</button></div>`}
function lessonPage(){return `<h1>الدروس ${level}</h1><p>دروس تدريجية في البرتغالية الأوروبية.</p>${lessons.filter(x=>x[3]===level||level==="B1").map((l,i)=>`<section class="panel"><div class="row"><strong>${l[0]}</strong><span class="muted">${l[3]}</span></div><p>${l[1]}</p><div class="example">${l[2]}</div><button class="btn secondary" data-lesson="${i}">فتح الدرس</button></section>`).join("")}`}
const questions=[["ماذا تعني Casa؟",["سيارة","منزل","ماء"],1],["كيف تقول صباح الخير؟",["Boa noite","Bom dia","Adeus"],1],["ما معنى Água؟",["ماء","طعام","عمل"],0],["ما معنى Trabalho؟",["صديق","عمل","وقت"],1]];
function quizPage(){if(quizDone)return `<section class="panel"><h1>انتهى الاختبار!</h1><div class="word">${quizScore} / ${questions.length}</div><button class="btn" id="restart">إعادة الاختبار</button></section>`;let q=questions[quizStep];return `<h1>اختبار المفردات</h1><div class="muted">السؤال ${quizStep+1} من ${questions.length}</div><section class="panel"><h2>${q[0]}</h2>${q[1].map((a,i)=>`<button class="quiz-option" data-choice="${i}" style="${quizChoice===i?"border-color:#68b8ff":""}">${a}</button>`).join("")}<button class="btn" id="submit" ${quizChoice===null?"disabled":""}>${quizStep===questions.length-1?"إنهاء":"التالي"}</button></section>`}
function progress(){return `<h1>تقدمي</h1><section class="panel"><div class="word">${level}</div><p>مستواك المختار</p><div class="row"><span>الكلمات التي أعرفها</span><strong>${known.length}</strong></div><div class="row"><span>المفضلة</span><strong>${favorites.length}</strong></div><div class="row"><span>الدروس المتاحة</span><strong>${lessons.length}</strong></div></section><h2>كلمات المفضلة</h2>${words.filter(w=>favorites.includes(w.pt)).map(w=>`<section class="panel"><strong>${w.pt}</strong> — ${w.ar}</section>`).join("")||"<p>لم تضف كلمات بعد.</p>"}`}
function bind(){
 document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>nav(b.dataset.go));
 document.querySelectorAll("[data-level]").forEach(b=>b.onclick=()=>{level=b.dataset.level;render()});
 const search=document.querySelector("#search");if(search)search.oninput=()=>document.querySelector("#results").innerHTML=wordResults(search.value);
 document.querySelectorAll("[data-speak]").forEach(b=>b.onclick=()=>speak(b.dataset.speak));
 document.querySelectorAll("[data-fav]").forEach(b=>b.onclick=()=>toggleFav(b.dataset.fav));
 if(document.querySelector("#flip"))document.querySelector("#flip").onclick=()=>{flipped=!flipped;render()};
 const prev=document.querySelector("#prev");if(prev)prev.onclick=()=>{card=(card+words.length-1)%words.length;flipped=false;render()};
 const next=document.querySelector("#next");if(next)next.onclick=()=>{card=(card+1)%words.length;flipped=false;render()};
 const knownBtn=document.querySelector("#known");if(knownBtn)knownBtn.onclick=()=>{if(!known.includes(words[card].pt))known.push(words[card].pt);card=(card+1)%words.length;flipped=false;render()};
 const favBtn=document.querySelector("#fav");if(favBtn)favBtn.onclick=()=>toggleFav(words[card].pt);
 document.querySelectorAll("[data-choice]").forEach(b=>b.onclick=()=>{quizChoice=+b.dataset.choice;render()});
 const submit=document.querySelector("#submit");if(submit)submit.onclick=()=>{if(quizChoice===questions[quizStep][2])quizScore++;quizStep++;quizChoice=null;if(quizStep>=questions.length)quizDone=true;render()};
 const restart=document.querySelector("#restart");if(restart)restart.onclick=()=>{quizStep=0;quizScore=0;quizChoice=null;quizDone=false;render()};
 document.querySelectorAll("[data-lesson]").forEach(b=>b.onclick=()=>alert("سيتم توسيع هذا الدرس بمحتوى كامل في المرحلة التالية."));
}
function toggleFav(w){favorites.includes(w)?favorites=favorites.filter(x=>x!==w):favorites.push(w);render()}
function speak(t){if("speechSynthesis"in window){let u=new SpeechSynthesisUtterance(t);u.lang="pt-PT";speechSynthesis.speak(u)}else alert("النطق غير مدعوم في هذا المتصفح.")}
render();
if("serviceWorker"in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
