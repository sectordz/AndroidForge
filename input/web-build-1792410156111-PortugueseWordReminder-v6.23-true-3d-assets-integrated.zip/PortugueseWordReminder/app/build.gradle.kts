plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Stable signing requires the SAME private keystore for every build.
// Supply these values securely from the build service; never commit the keystore/passwords.
val stableKeystorePath = System.getenv("ANDROID_KEYSTORE_PATH")
val stableKeystorePassword = System.getenv("ANDROID_KEYSTORE_PASSWORD")
val stableKeyAlias = System.getenv("ANDROID_KEY_ALIAS")
val stableKeyPassword = System.getenv("ANDROID_KEY_PASSWORD")
val hasStableSigning = !stableKeystorePath.isNullOrBlank() &&
    !stableKeystorePassword.isNullOrBlank() && !stableKeyAlias.isNullOrBlank() &&
    !stableKeyPassword.isNullOrBlank()

android {
    namespace = "com.bekri.wordreminder"
    compileSdk = 35
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    signingConfigs {
        if (hasStableSigning) {
            create("stable") {
                storeFile = file(stableKeystorePath!!)
                storePassword = stableKeystorePassword
                keyAlias = stableKeyAlias
                keyPassword = stableKeyPassword
            }
        }
    }

    buildTypes {
        getByName("debug") {
            if (hasStableSigning) signingConfig = signingConfigs.getByName("stable")
        }
        getByName("release") {
            if (hasStableSigning) signingConfig = signingConfigs.getByName("stable")
        }
    }

    defaultConfig {
        applicationId = "com.bekri.wordreminder"
        minSdk = 26
        targetSdk = 35
        versionCode = 25
        versionName = "3.4"
    }
}
