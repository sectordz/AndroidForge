package com.bekri.portugueslockscreen

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.Locale

class ScreenWakeService : Service() {
    private val channelId = "portugues_learning"
    private val notificationId = 401
    private var index = 0
    private val prefs by lazy { getSharedPreferences("learning_cards", MODE_PRIVATE) }
    private var tts: TextToSpeech? = null
    private var receiverRegistered = false

    private data class Card(val pt: String, val ar: String, val example: String)
    private val cards = listOf(
        Card("Queres ir comigo?", "هل تريد الذهاب معي؟", "Queres ir comigo ao café?"),
        Card("O que queres fazer?", "ماذا تريد أن تفعل؟", "O que queres fazer hoje?"),
        Card("Sabes?", "هل تعرف؟", "Sabes onde fica a estação?"),
        Card("Onde foste?", "أين ذهبت؟", "Onde foste ontem?"),
        Card("Podes ajudar-me?", "هل يمكنك مساعدتي؟", "Podes ajudar-me, por favor?"),
        Card("Quando vais voltar?", "متى ستعود؟", "Quando vais voltar para casa?"),
        Card("Gostaste?", "هل أعجبك؟", "Gostaste do restaurante?"),
        Card("O que fizeste?", "ماذا فعلت؟", "O que fizeste ontem?"),
        Card("Ainda não sei.", "لا أعرف بعد.", "Ainda não sei a resposta."),
        Card("Queres trabalhar amanhã?", "هل تريد العمل غداً؟", "A que horas queres começar?")
    )

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_ON) {
                index = (index + 1) % cards.size
                prefs.edit().putInt("current_index", index).apply()
                showCard()
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate() {
        super.onCreate()
        createChannel()
        index = prefs.getInt("current_index", 0).coerceIn(cards.indices)
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.forLanguageTag("pt-PT")
        }
        val filter = IntentFilter(Intent.ACTION_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(screenReceiver, filter)
        receiverRegistered = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "NEXT_CARD") {
            index = (index + 1) % cards.size
            prefs.edit().putInt("current_index", index).apply()
        }
        val initial = buildNotification(cards[index])
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(notificationId, initial, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(notificationId, initial)
        return START_STICKY
    }

    private fun showCard() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(notificationId, buildNotification(cards[index]))
    }

    private fun buildNotification(card: Card): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val speakIntent = PendingIntent.getBroadcast(
            this, 2, Intent(this, CardActionReceiver::class.java).setAction("SPEAK_PT").putExtra("phrase", card.pt),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val knownIntent = PendingIntent.getBroadcast(
            this, 3, Intent(this, CardActionReceiver::class.java).setAction("NEXT_CARD"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val bitmap = makeCardArt(card.pt)
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("🇵🇹 Português do Dia · ${index + 1}/${cards.size}")
            .setContentText("${card.pt} — ${card.ar}")
            .setStyle(NotificationCompat.BigPictureStyle().bigPicture(bitmap).bigLargeIcon(null as Bitmap?))
            .setContentIntent(openIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_play, "استمع", speakIntent)
            .addAction(android.R.drawable.checkbox_on_background, "أعرفها", knownIntent)
            .build()
    }

    private fun makeCardArt(phrase: String): Bitmap {
        val bmp = Bitmap.createBitmap(1000, 520, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(0xFF10264A.toInt())
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = 0xFF294B7D.toInt()
        canvas.drawRoundRect(25f, 25f, 975f, 495f, 42f, 42f, p)
        p.color = 0xFFFFD166.toInt()
        canvas.drawCircle(115f, 115f, 48f, p)
        p.color = 0xFFFFFFFF.toInt()
        p.textSize = 58f
        p.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        canvas.drawText("PORTUGUÊS DO DIA", 205f, 135f, p)
        p.textSize = 48f
        canvas.drawText(phrase.take(28), 70f, 300f, p)
        p.textSize = 30f
        p.color = 0xFFBBD0EF.toInt()
        canvas.drawText("Ouça · Aprenda · Repita", 70f, 390f, p)
        return bmp
    }

    private fun createChannel() {
        val channel = NotificationChannel(channelId, "بطاقات تعلم البرتغالية", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "بطاقة تتغير عند تشغيل الشاشة"
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onDestroy() {
        if (receiverRegistered) unregisterReceiver(screenReceiver)
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
