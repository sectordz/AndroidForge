package com.bekri.wordreminder

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.*
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

 data class Word(val pt: String, val ar: String, val examplePt: String = "", val exampleAr: String = "")

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val prefs by lazy { getSharedPreferences("words", MODE_PRIVATE) }
    private val words = mutableListOf<Word>()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var intervalSpinner: Spinner
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val exportRequest = 431
    private val importRequest = 432

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        loadWords()
        buildUi()
        askNotificationPermission()
        updateStatus()
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("pt", "PT"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 10)
            setBackgroundColor(Color.rgb(246, 248, 252))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 14, 14, 14)
            background = rounded(0xFF1769E8.toInt(), 22)
        }
        header.addView(TextView(this).apply {
            text = "🇵🇹 كلمات البرتغالية"
            textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD)
        })
        header.addView(TextView(this).apply {
            text = "Português • تعلّم الكلمات والجمل يوميًا"
            textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 5, 0, 0)
        })
        content.addView(header, marginParams())

        status = TextView(this).apply {
            textSize = 15f; gravity = Gravity.CENTER; setTextColor(0xFF253858.toInt()); setPadding(8, 12, 8, 12)
            background = rounded(Color.WHITE, 16)
        }
        content.addView(status, marginParams())

        content.addView(makeTile("＋ إضافة كلمة", 0xFF168B55.toInt()) { editWord(null) }, marginParams())
        val reminderRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        reminderRow.addView(makeTile("▶ تشغيل التذكير", 0xFF1769E8.toInt()) { requestExactAlarmThenSchedule() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 3, 4, 3) })
        reminderRow.addView(makeTile("■ إيقاف", 0xFF64748B.toInt()) {
            prefs.edit().putBoolean("reminders_enabled", false).apply(); ReminderScheduler.cancel(this@MainActivity); updateStatus("تم إيقاف التذكيرات")
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 3, 0, 3) })
        content.addView(reminderRow)

        val intervalCard = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(12, 6, 12, 6); background = rounded(Color.WHITE, 14) }
        intervalCard.addView(TextView(this).apply { text = "⏱ الفاصل:"; textSize = 16f; setTextColor(0xFF253858.toInt()); setPadding(0, 0, 8, 0) })
        intervalSpinner = Spinner(this)
        intervalSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, (1..10).map { "كل $it دقيقة" })
        intervalSpinner.setSelection((prefs.getInt("interval_minutes", 5).coerceIn(1, 10)) - 1)
        intervalSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val minutes = position + 1
                val old = prefs.getInt("interval_minutes", 5)
                prefs.edit().putInt("interval_minutes", minutes).apply()
                if (old != minutes && prefs.getBoolean("reminders_enabled", false)) ReminderScheduler.scheduleNext(this@MainActivity)
                updateStatus()
            }
        }
        intervalCard.addView(intervalSpinner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(intervalCard, marginParams())

        val learnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        learnRow.addView(makeTile("🃏 البطاقات التعليمية", 0xFF168B55.toInt()) { startFlashcards() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 3, 4, 3) })
        learnRow.addView(makeTile("🎯 اختبار الكلمات", 0xFF7C3AED.toInt()) { startQuiz() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 3, 0, 3) })
        content.addView(learnRow)

        val toolsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        toolsRow.addView(makeTile("📥 استيراد Excel", 0xFF0D9488.toInt()) { importWords() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 3, 4, 3) })
        toolsRow.addView(makeTile("📤 تصدير الكلمات", 0xFFF59E0B.toInt()) { exportWords() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 3, 0, 3) })
        content.addView(toolsRow)
        val soundRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        soundRow.addView(makeTile("🔊 تجربة النطق الأوروبي", 0xFF2563EB.toInt()) { if (words.isEmpty()) toast("أضف كلمة أولًا") else speak(words.first().pt) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 3, 4, 3) })
        soundRow.addView(makeTile("📖 الجمل والأمثلة", 0xFFDB2777.toInt()) { showExamples() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 3, 0, 3) })
        content.addView(soundRow, marginParams())

        content.addView(TextView(this).apply {
            text = "📚 كلماتك (اضغط تعديل، أو حذف لإزالتها)"; textSize = 19f; setTextColor(0xFF172B4D.toInt()); setPadding(4, 12, 4, 6); setTypeface(null, android.graphics.Typeface.BOLD)
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        renderWords()
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radiusDp * resources.displayMetrics.density
    }

    private fun marginParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        setMargins(0, 4, 0, 4)
    }

    private fun makeTile(label: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 14f; setTextColor(Color.WHITE); isAllCaps = false; setPadding(8, 8, 8, 8)
        background = rounded(color, 14)
        setOnClickListener { action() }
    }

    private fun editWord(existing: Int?) {
        val current = existing?.let { words[it] }
        val pt = EditText(this).apply { hint = "الكلمة بالبرتغالية"; textSize = 17f; setSingleLine(true); current?.let { setText(it.pt) } }
        val ar = EditText(this).apply { hint = "الترجمة بالعربية"; textSize = 17f; setSingleLine(true); current?.let { setText(it.ar) } }
        val exPt = EditText(this).apply { hint = "مثال بالبرتغالية (اختياري)"; textSize = 16f; current?.let { setText(it.examplePt) } }
        val exAr = EditText(this).apply { hint = "ترجمة المثال (اختياري)"; textSize = 16f; current?.let { setText(it.exampleAr) } }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 0, 22, 0); addView(pt); addView(ar); addView(exPt); addView(exAr) }
        AlertDialog.Builder(this).setTitle(if (existing == null) "إضافة كلمة" else "تعديل الكلمة").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val p = pt.text.toString().trim(); val a = ar.text.toString().trim()
                if (p.isNotEmpty() && a.isNotEmpty()) {
                    val w = Word(p, a, exPt.text.toString().trim(), exAr.text.toString().trim())
                    if (existing == null) words.add(w) else if (existing in words.indices) words[existing] = w
                    saveWords(); renderWords(); updateStatus()
                } else toast("اكتب الكلمة والترجمة")
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun renderWords() {
        list.removeAllViews()
        if (words.isEmpty()) {
            list.addView(TextView(this).apply { text = "لم تضف كلمات بعد. أضف كلمة أو استورد ملف Excel."; textSize = 16f; setTextColor(0xFF64748B.toInt()); setPadding(12, 18, 12, 18); background = rounded(Color.WHITE, 16) }, marginParams())
            return
        }
        words.forEachIndexed { i, w ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 12); background = rounded(Color.WHITE, 16)
            }
            card.addView(TextView(this).apply { text = w.pt; textSize = 22f; setTextColor(0xFF102A43.toInt()); setTypeface(null, android.graphics.Typeface.BOLD) })
            card.addView(TextView(this).apply { text = w.ar; textSize = 18f; gravity = Gravity.END; setTextColor(0xFF334E68.toInt()); setPadding(0, 2, 0, 4) })
            if (w.examplePt.isNotBlank()) {
                card.addView(TextView(this).apply { text = "${w.examplePt}\n${w.exampleAr}"; textSize = 14f; setTextColor(0xFF486581.toInt()); setPadding(8, 8, 8, 8); background = rounded(0xFFF1F5F9.toInt(), 10) })
            }
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            buttons.addView(makeTile("🔊", 0xFF1769E8.toInt()) { speak(w.pt) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.7f).apply { setMargins(0, 4, 3, 0) })
            buttons.addView(makeTile("تعديل", 0xFF64748B.toInt()) { editWord(i) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 4, 3, 0) })
            buttons.addView(makeTile("حذف", 0xFFDC2626.toInt()) { confirmDelete(i) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 4, 0, 0) })
            card.addView(buttons)
            list.addView(card, marginParams())
        }
    }

    private fun confirmDelete(i: Int) {
        if (i !in words.indices) return
        AlertDialog.Builder(this).setMessage("حذف ${words[i].pt}؟").setPositiveButton("حذف") { _, _ -> words.removeAt(i); saveWords(); renderWords(); updateStatus() }.setNegativeButton("إلغاء", null).show()
    }

    private fun showExamples() {
        val examples = words.filter { it.examplePt.isNotBlank() }
        if (examples.isEmpty()) {
            AlertDialog.Builder(this).setTitle("الجمل والأمثلة")
                .setMessage("لا توجد أمثلة محفوظة بعد. أضف كلمة ثم اكتب المثال البرتغالي وترجمته، أو استورد ملف Excel بأربعة أعمدة: البرتغالية، العربية، المثال، ترجمة المثال.")
                .setPositiveButton("حسنًا", null).show()
            return
        }
        val body = examples.joinToString("\n\n──────────\n\n") { "${it.examplePt}\n${it.exampleAr}\n(${it.pt} = ${it.ar})" }
        val text = TextView(this).apply { this.text = body; textSize = 17f; setTextColor(0xFF243B53.toInt()); setPadding(22, 14, 22, 14) }
        AlertDialog.Builder(this).setTitle("الجمل والأمثلة (${examples.size})").setView(ScrollView(this).apply { addView(text) }).setPositiveButton("إغلاق", null).show()
    }

    private fun startFlashcards() {
        if (words.isEmpty()) { toast("أضف كلمات أولًا"); return }
        var index = 0
        var revealed = false
        val cardText = TextView(this).apply { textSize = 20f; gravity = Gravity.CENTER; setPadding(24, 24, 24, 24); minHeight = 180 }
        val dialog = AlertDialog.Builder(this).setTitle("بطاقات الكلمات").setView(cardText).setPositiveButton("إظهار الترجمة", null).setNeutralButton("التالي ⟶", null).setNegativeButton("إغلاق", null).create()
        fun showCard() {
            val w = words[index % words.size]
            cardText.text = if (revealed) {
                buildString {
                    append("${index + 1} / ${words.size}\n\n${w.pt}\n${w.ar}")
                    if (w.examplePt.isNotBlank()) append("\n\n${w.examplePt}\n${w.exampleAr}")
                }
            } else "${index + 1} / ${words.size}\n\n${w.pt}\n\nحاول تذكّر المعنى ثم اضغط إظهار الترجمة"
        }
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { revealed = !revealed; dialog.getButton(AlertDialog.BUTTON_POSITIVE).text = if (revealed) "إخفاء الترجمة" else "إظهار الترجمة"; showCard() }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { index = (index + 1) % words.size; revealed = false; dialog.getButton(AlertDialog.BUTTON_POSITIVE).text = "إظهار الترجمة"; showCard() }
            showCard()
        }
        dialog.show()
    }

    private fun startQuiz() {
        if (words.size < 2) { toast("أضف كلمتين على الأقل لبدء الاختبار"); return }
        val item = words.random()
        val options = (words.filter { it.pt != item.pt }.shuffled().take(3).map { it.ar } + item.ar).distinct().shuffled()
        AlertDialog.Builder(this).setTitle("ما ترجمة: ${item.pt}؟").setItems(options.toTypedArray()) { _, which ->
            if (options[which] == item.ar) AlertDialog.Builder(this).setMessage("✅ صحيح! ${item.pt} = ${item.ar}").setPositiveButton("حسنًا", null).show()
            else AlertDialog.Builder(this).setMessage("❌ الإجابة الصحيحة: ${item.ar}").setPositiveButton("حسنًا", null).show()
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun speak(text: String) {
        if (!ttsReady) { toast("الصوت البرتغالي غير متاح حاليًا على الهاتف"); return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "word-${System.currentTimeMillis()}")
    }

    private fun importWords() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-excel", "text/csv", "text/comma-separated-values", "text/plain"
            ))
        }
        startActivityForResult(intent, importRequest)
    }

    private fun importFromUri(uri: Uri) {
        try {
            val name = (contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else ""
            } ?: "").lowercase(Locale.ROOT)
            val rows = if (name.endsWith(".xlsx")) readXlsx(uri) else readDelimited(uri)
            if (rows.isEmpty()) { toast("لم أجد صفوفًا في الملف"); return }
            val first = rows.first().map { it.trim().lowercase(Locale.ROOT) }
            val headerLikely = first.any { it.contains("portugu") || it == "pt" || it.contains("العربي") || it == "ar" || it.contains("ترجم") }
            var ptCol = 0; var arCol = 1; var exPtCol = 2; var exArCol = 3
            var startRow = 0
            if (headerLikely) {
                fun findCol(predicate: (String) -> Boolean, fallback: Int): Int = first.indexOfFirst(predicate).let { if (it >= 0) it else fallback }
                ptCol = findCol({ it.contains("portugu") || it == "pt" || it == "portugues" || it == "português" }, 0)
                arCol = findCol({ it.contains("العربي") || it == "ar" || it.contains("ترجم") }, if (ptCol == 0) 1 else 0)
                exPtCol = findCol({ it.contains("exemplo") || it.contains("مثال") && it.contains("برتغ") }, 2)
                exArCol = findCol({ it.contains("tradução do exemplo") || it.contains("ترجمة المثال") }, 3)
                startRow = 1
            }
            var added = 0; var updated = 0
            for (r in startRow until rows.size) {
                val row = rows[r]
                val pt = row.getOrNull(ptCol)?.trim().orEmpty()
                val ar = row.getOrNull(arCol)?.trim().orEmpty()
                if (pt.isBlank() || ar.isBlank()) continue
                val exPt = row.getOrNull(exPtCol)?.trim().orEmpty()
                val exAr = row.getOrNull(exArCol)?.trim().orEmpty()
                val index = words.indexOfFirst { it.pt.equals(pt, ignoreCase = true) }
                val word = Word(pt, ar, exPt, exAr)
                if (index >= 0) { words[index] = word; updated++ } else { words.add(word); added++ }
            }
            saveWords(); renderWords(); updateStatus()
            toast("تم الاستيراد: أضيف $added، وتم تحديث $updated كلمة")
        } catch (e: Exception) {
            toast("تعذر استيراد الملف. استخدم Excel بصيغة .xlsx أو CSV")
        }
    }

    private fun readDelimited(uri: Uri): List<List<String>> {
        val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: return emptyList()
        val lines = text.removePrefix("\uFEFF").split(Regex("\r?\n")).filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList()
        val delimiter = listOf('\t', ';', ',').maxByOrNull { d -> lines.first().count { it == d } } ?: ','
        return lines.map { line ->
            val cells = mutableListOf<String>(); val cell = StringBuilder(); var quoted = false; var i = 0
            while (i < line.length) {
                val ch = line[i]
                if (ch == '"') {
                    if (quoted && i + 1 < line.length && line[i + 1] == '"') { cell.append('"'); i++ } else quoted = !quoted
                } else if (ch == delimiter && !quoted) { cells.add(cell.toString()); cell.setLength(0) } else cell.append(ch)
                i++
            }
            cells.add(cell.toString()); cells
        }
    }

    private fun readXlsx(uri: Uri): List<List<String>> {
        val entries = mutableMapOf<String, ByteArray>()
        val input = contentResolver.openInputStream(uri) ?: return emptyList()
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && (entry.name == "xl/sharedStrings.xml" || entry.name == "xl/worksheets/sheet1.xml")) {
                    val out = ByteArrayOutputStream(); zip.copyTo(out); entries[entry.name] = out.toByteArray()
                }
                entry = zip.nextEntry
            }
        }
        val sheet = entries["xl/worksheets/sheet1.xml"] ?: return emptyList()
        val shared = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) } ?: emptyList()
        val result = mutableListOf<List<String>>()
        val parser = Xml.newPullParser(); parser.setInput(ByteArrayInputStream(sheet), "UTF-8")
        var event = parser.eventType; var inCell = false; var cellType = ""; var cellRef = ""; var value = ""; var inValue = false; var row = mutableMapOf<Int, String>()
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> row = mutableMapOf()
                    "c" -> { inCell = true; cellType = parser.getAttributeValue(null, "t") ?: ""; cellRef = parser.getAttributeValue(null, "r") ?: ""; value = "" }
                    "v", "t" -> if (inCell) inValue = true
                }
                XmlPullParser.TEXT -> if (inValue) value += parser.text
                XmlPullParser.END_TAG -> when (parser.name) {
                    "v", "t" -> inValue = false
                    "c" -> {
                        val col = cellRef.takeWhile { it.isLetter() }.fold(0) { acc, ch -> acc * 26 + (ch.uppercaseChar() - 'A' + 1) } - 1
                        val decoded = if (cellType == "s") shared.getOrNull(value.toIntOrNull() ?: -1).orEmpty() else value
                        if (col >= 0) row[col] = decoded
                        inCell = false
                    }
                    "row" -> if (row.isNotEmpty()) result.add((0..(row.keys.maxOrNull() ?: 0)).map { row[it].orEmpty() })
                }
            }
            event = parser.next()
        }
        return result
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val out = mutableListOf<String>(); val parser = Xml.newPullParser(); parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        var event = parser.eventType; var inSi = false; var inText = false; val current = StringBuilder()
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) { "si" -> { inSi = true; current.setLength(0) }; "t" -> if (inSi) inText = true }
                XmlPullParser.TEXT -> if (inSi && inText) current.append(parser.text)
                XmlPullParser.END_TAG -> when (parser.name) { "t" -> inText = false; "si" -> { out.add(current.toString()); inSi = false } }
            }
            event = parser.next()
        }
        return out
    }

    private fun exportWords() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "PortugueseWords.json") }
        startActivityForResult(intent, exportRequest)
    }

    @Deprecated("Deprecated in Android but kept for compatibility with target devices")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == importRequest && resultCode == RESULT_OK && data?.data != null) {
            importFromUri(data.data!!)
        }
        if (requestCode == exportRequest && resultCode == RESULT_OK && data?.data != null) {
            try {
                val arr = JSONArray(); words.forEach { arr.put(JSONObject().put("pt", it.pt).put("ar", it.ar).put("examplePt", it.examplePt).put("exampleAr", it.exampleAr)) }
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(arr.toString(2)) }
                toast("تم تصدير الكلمات بنجاح")
            } catch (e: Exception) { toast("تعذر التصدير: ${e.message}") }
        }
    }

    private fun loadWords() {
        words.clear()
        val arr = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) { val o = arr.optJSONObject(i) ?: continue; words.add(Word(o.optString("pt"), o.optString("ar"), o.optString("examplePt"), o.optString("exampleAr"))) }
    }
    private fun saveWords() { val arr = JSONArray(); words.forEach { arr.put(JSONObject().put("pt", it.pt).put("ar", it.ar).put("examplePt", it.examplePt).put("exampleAr", it.exampleAr)) }; prefs.edit().putString("items", arr.toString()).apply() }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
    }
    private fun requestExactAlarmThenSchedule() {
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))); toast("اسمح للتطبيق بالمنبّهات الدقيقة ثم ارجع واضغط تشغيل"); return }
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) { askNotificationPermission(); toast("اسمح بالإشعارات ثم اضغط تشغيل مرة أخرى"); return }
        prefs.edit().putBoolean("reminders_enabled", true).apply()
        ReminderScheduler.scheduleNext(this)
        updateStatus("التذكير يعمل في الخلفية: كل ${prefs.getInt("interval_minutes", 5)} دقيقة بين 08:00 و22:00")
    }
    private fun updateStatus(message: String? = null) { status.text = message ?: "عدد الكلمات المحفوظة: ${words.size}\nالتذكير: كل ${prefs.getInt("interval_minutes", 5)} دقيقة، 08:00–22:00" }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

object ReminderScheduler {
    fun scheduleNext(context: Context) {
        val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("reminders_enabled", false)) return
        val now = System.currentTimeMillis()
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = now }
        val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
        if (hour >= 22 || hour < 8) {
            if (hour >= 22) cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
            cal.set(java.util.Calendar.HOUR_OF_DAY, 8); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
            setAlarm(context, cal.timeInMillis); return
        }
        val minutes = prefs.getInt("interval_minutes", 5).coerceIn(1, 10)
        setAlarm(context, now + minutes * 60 * 1000L)
    }
    private fun setAlarm(context: Context, at: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(context, 12, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); return }
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) else am.setExact(AlarmManager.RTC_WAKEUP, at, pi)
    }
    fun cancel(context: Context) { val pi = PendingIntent.getBroadcast(context, 12, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi) }
}

class ReminderReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("reminders_enabled", false)) return
        val arr = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        val now = java.util.Calendar.getInstance(); val hour = now.get(java.util.Calendar.HOUR_OF_DAY)
        if (hour in 8..21 && arr.length() > 0) {
            val index = prefs.getInt("next_index", 0).let { if (it >= arr.length()) 0 else it }
            val item = arr.optJSONObject(index)
            if (item != null) {
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(android.app.NotificationChannel("words", "تذكير الكلمات", android.app.NotificationManager.IMPORTANCE_DEFAULT))
                val open = PendingIntent.getActivity(context, 2, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val notification = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, "words") else android.app.Notification.Builder(context)
                val text = "${item.optString("pt")} — ${item.optString("ar")}"
                notification.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(item.optString("pt")).setContentText(item.optString("ar")).setStyle(android.app.Notification.BigTextStyle().bigText(text)).setContentIntent(open).setAutoCancel(true)
                manager.notify(1001, notification.build())
                prefs.edit().putInt("next_index", (index + 1) % arr.length()).apply()
            }
        }
        ReminderScheduler.scheduleNext(context)
    }
}

class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) ReminderScheduler.scheduleNext(context)
    }
}
