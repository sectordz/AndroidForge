package com.flashcard3d.demo

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.speech.tts.TextToSpeech
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.w3c.dom.Element
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val excelRequestCode = 4107

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(2, 9, 26)
        window.navigationBarColor = android.graphics.Color.rgb(2, 9, 26)
        tts = TextToSpeech(this, this)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(VoiceBridge(), "NativeVoice")
        webView.addJavascriptInterface(FileBridge(), "NativeFiles")
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(true)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = 0
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale.forLanguageTag("pt-PT")
        }
    }

    inner class VoiceBridge {
        @JavascriptInterface fun speak(text: String, language: String) {
            runOnUiThread {
                if (!ttsReady) return@runOnUiThread
                val locale = if (language == "ar") Locale.forLanguageTag("ar") else Locale.forLanguageTag("pt-PT")
                val result = tts?.setLanguage(locale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.getDefault())
                }
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "flashcard-" + System.currentTimeMillis())
            }
        }
    }

    inner class FileBridge {
        @JavascriptInterface fun pickExcel() {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            "text/csv", "text/comma-separated-values", "application/octet-stream"
                        ))
                    }
                    startActivityForResult(intent, excelRequestCode)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر فتح الملفات", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != excelRequestCode || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val json = readWorkbook(uri)
            if (json.length() == 0) throw IllegalArgumentException("empty")
            val safe = JSONObject.quote(json.toString())
            webView.evaluateJavascript("window.importRowsFromNative && window.importRowsFromNative(JSON.parse($safe));", null)
        } catch (e: Exception) {
            android.util.Log.e("FlashcardExcel", "Failed to parse XLSX", e)
            Toast.makeText(this, "تعذرت قراءة ملف Excel. تأكد أنه ملف .xlsx صالح وغير محمي بكلمة مرور.", Toast.LENGTH_LONG).show()
        }
    }

    private fun readWorkbook(uri: Uri): JSONArray {
        val entries = HashMap<String, ByteArray>()
        contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Cannot open file" }
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val out = ByteArrayOutputStream()
                        zip.copyTo(out)
                        entries[entry.name] = out.toByteArray()
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
        val firstSheetPath = firstWorksheetPath(entries)
        val sheetBytes = entries[firstSheetPath] ?: throw IllegalArgumentException("Missing worksheet")
        val shared = mutableListOf<String>()
        entries["xl/sharedStrings.xml"]?.let { bytes ->
            val doc = xmlDoc(bytes)
            val sis = doc.getElementsByTagName("si")
            for (i in 0 until sis.length) {
                val node = sis.item(i)
                val ts = (node as Element).getElementsByTagName("t")
                val sb = StringBuilder()
                for (j in 0 until ts.length) sb.append(ts.item(j).textContent ?: "")
                shared.add(sb.toString())
            }
        }
        val sheet = xmlDoc(sheetBytes)
        val rows = sheet.getElementsByTagName("row")
        val matrix = mutableListOf<List<String>>()
        for (r in 0 until rows.length) {
            val rowNode = rows.item(r) as Element
            val cells = rowNode.getElementsByTagName("c")
            val values = mutableMapOf<Int, String>()
            var maxCol = -1
            for (c in 0 until cells.length) {
                val cell = cells.item(c) as Element
                val ref = cell.getAttribute("r")
                val col = columnIndex(ref)
                if (col < 0) continue
                maxCol = maxOf(maxCol, col)
                val type = cell.getAttribute("t")
                val value = when (type) {
                    "s" -> {
                        val v = cell.getElementsByTagName("v")
                        if (v.length > 0) shared.getOrNull(v.item(0).textContent.toIntOrNull() ?: -1).orEmpty() else ""
                    }
                    "inlineStr" -> cell.getElementsByTagName("t").let { if (it.length > 0) it.item(0).textContent.orEmpty() else "" }
                    "b" -> cell.getElementsByTagName("v").let { if (it.length > 0 && it.item(0).textContent == "1") "true" else "false" }
                    else -> cell.getElementsByTagName("v").let { if (it.length > 0) it.item(0).textContent.orEmpty() else "" }
                }
                values[col] = value.trim()
            }
            if (maxCol >= 0) matrix.add((0..maxCol).map { values[it].orEmpty() })
        }
        if (matrix.size < 2) throw IllegalArgumentException("No rows")
        val headers = matrix.first().mapIndexed { index, value -> if (value.isBlank()) "column_${index + 1}" else value.trim() }
        val result = JSONArray()
        for (row in matrix.drop(1)) {
            if (row.all { it.isBlank() }) continue
            val obj = JSONObject()
            headers.forEachIndexed { index, header -> obj.put(header, row.getOrElse(index) { "" }) }
            result.put(obj)
        }
        return result
    }


    private fun firstWorksheetPath(entries: Map<String, ByteArray>): String {
        val workbook = entries["xl/workbook.xml"]
        val relationships = entries["xl/_rels/workbook.xml.rels"]
        if (workbook != null && relationships != null) {
            val workbookDoc = xmlDoc(workbook)
            val sheets = workbookDoc.getElementsByTagName("sheet")
            if (sheets.length > 0) {
                val relationId = (sheets.item(0) as Element).getAttribute("r:id")
                val relDoc = xmlDoc(relationships)
                val rels = relDoc.getElementsByTagName("Relationship")
                for (i in 0 until rels.length) {
                    val rel = rels.item(i) as Element
                    if (rel.getAttribute("Id") == relationId) {
                        val target = rel.getAttribute("Target").removePrefix("/")
                        val path = if (target.startsWith("xl/")) target else "xl/$target"
                        if (entries.containsKey(path)) return path
                    }
                }
            }
        }
        return "xl/worksheets/sheet1.xml"
    }

    // Android's built-in XML parser does not implement every Apache/Xerces feature URI.
    // Setting unsupported feature flags can throw ParserConfigurationException before an
    // otherwise valid XLSX worksheet is read. XLSX XML parts are local ZIP entries; disable
    // entity expansion and parse with the platform parser for Android compatibility.
    private fun xmlDoc(bytes: ByteArray) = DocumentBuilderFactory.newInstance().apply {
        isNamespaceAware = false
        isExpandEntityReferences = false
    }.newDocumentBuilder().parse(bytes.inputStream())

    private fun columnIndex(cellRef: String): Int {
        var result = 0
        var found = false
        for (ch in cellRef) {
            if (ch.isLetter()) {
                found = true
                result = result * 26 + (ch.uppercaseChar() - 'A' + 1)
            } else break
        }
        return if (found) result - 1 else -1
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        webView.destroy()
        super.onDestroy()
    }
}
