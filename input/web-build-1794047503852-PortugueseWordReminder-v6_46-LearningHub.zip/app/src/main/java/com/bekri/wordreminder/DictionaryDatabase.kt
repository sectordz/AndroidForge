package com.bekri.wordreminder

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Locale

data class DictionaryEntry(
    val id: Long,
    val portuguese: String,
    val arabic: String,
    val examplePt: String,
    val exampleAr: String
)

/**
 * Offline Portuguese-European/Arabic dictionary.
 * FTS4 provides indexed full-text lookup; the ordinary table remains the source of truth.
 */
class DictionaryDatabase(context: Context) :
    SQLiteOpenHelper(context, "portuguese_dictionary.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE dictionary (
                _id INTEGER PRIMARY KEY AUTOINCREMENT,
                portuguese TEXT NOT NULL,
                arabic TEXT NOT NULL,
                example_pt TEXT NOT NULL DEFAULT '',
                example_ar TEXT NOT NULL DEFAULT ''
            )
        """.trimIndent())
        db.execSQL("""
            CREATE VIRTUAL TABLE dictionary_fts USING fts4(
                portuguese, arabic, example_pt, example_ar,
                content='dictionary'
            )
        """.trimIndent())
        seed(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Keep user-created words in their separate existing storage.
    }

    private fun seed(db: SQLiteDatabase) {
        val rows = listOf(
            arrayOf("olá","مرحباً","Olá, tudo bem?","مرحباً، هل كل شيء بخير؟"),
            arrayOf("bom dia","صباح الخير","Bom dia, como está?","صباح الخير، كيف حالك؟"),
            arrayOf("boa tarde","مساء الخير","Boa tarde a todos.","مساء الخير للجميع."),
            arrayOf("boa noite","تصبح على خير / مساء الخير","Boa noite e até amanhã.","تصبح على خير وإلى الغد."),
            arrayOf("obrigado","شكراً (للمذكر)","Muito obrigado pela ajuda.","شكراً جزيلاً على المساعدة."),
            arrayOf("obrigada","شكراً (للمؤنث)","Obrigada por tudo.","شكراً على كل شيء."),
            arrayOf("por favor","من فضلك","Um café, por favor.","قهوة من فضلك."),
            arrayOf("desculpe","عذراً","Desculpe, não percebi.","عذراً، لم أفهم."),
            arrayOf("casa","منزل","A minha casa é pequena.","منزلي صغير."),
            arrayOf("trabalho","عمل","Vou para o trabalho.","أنا ذاهب إلى العمل."),
            arrayOf("água","ماء","Quero beber água.","أريد شرب الماء."),
            arrayOf("comida","طعام","A comida está boa.","الطعام لذيذ."),
            arrayOf("pão","خبز","Compro pão todos os dias.","أشتري الخبز كل يوم."),
            arrayOf("leite","حليب","Bebo leite ao pequeno-almoço.","أشرب الحليب في الفطور."),
            arrayOf("café","قهوة","Quero um café curto.","أريد قهوة قصيرة."),
            arrayOf("chá","شاي","Prefiro chá sem açúcar.","أفضل الشاي دون سكر."),
            arrayOf("carro","سيارة","O meu carro está na rua.","سيارتي في الشارع."),
            arrayOf("autocarro","حافلة"," apanho o autocarro às oito.","أستقل الحافلة في الثامنة."),
            arrayOf("comboio","قطار","O comboio chega às nove.","يصل القطار في التاسعة."),
            arrayOf("rua","شارع","A loja fica nesta rua.","المتجر في هذا الشارع."),
            arrayOf("cidade","مدينة","Loulé é uma cidade no Algarve.","لولي مدينة في الغارف."),
            arrayOf("escola","مدرسة","A escola fica perto de casa.","المدرسة قريبة من المنزل."),
            arrayOf("amigo","صديق","O meu amigo é português.","صديقي برتغالي."),
            arrayOf("família","عائلة","A minha família vive na Argélia.","عائلتي تعيش في الجزائر."),
            arrayOf("mãe","أم","A minha mãe cozinha bem.","أمي تطبخ جيداً."),
            arrayOf("pai","أب","O meu pai trabalha muito.","أبي يعمل كثيراً."),
            arrayOf("hoje","اليوم","Hoje vou estudar português.","اليوم سأدرس البرتغالية."),
            arrayOf("amanhã","غداً","Amanhã tenho aulas.","غداً لدي دروس."),
            arrayOf("ontem","أمس","Ontem trabalhei muito.","عملت كثيراً أمس."),
            arrayOf("agora","الآن","Estou ocupado agora.","أنا مشغول الآن."),
            arrayOf("sempre","دائماً","Ela chega sempre a horas.","هي تصل دائماً في الوقت."),
            arrayOf("nunca","أبداً","Nunca bebo café à noite.","لا أشرب القهوة أبداً في الليل."),
            arrayOf("querer","يريد","Quero aprender português.","أريد تعلم البرتغالية."),
            arrayOf("precisar","يحتاج","Preciso de ajuda.","أحتاج إلى مساعدة."),
            arrayOf("gostar","يحب","Gosto de aprender línguas.","أحب تعلم اللغات."),
            arrayOf("falar","يتكلم","Falo um pouco de português.","أتكلم قليلاً من البرتغالية."),
            arrayOf("compreender","يفهم","Compreendo a pergunta.","أفهم السؤال."),
            arrayOf("aprender","يتعلم","Quero aprender todos os dias.","أريد التعلم كل يوم."),
            arrayOf("pequeno","صغير","O quarto é pequeno.","الغرفة صغيرة."),
            arrayOf("grande","كبير","O supermercado é grande.","السوبرماركت كبير."),
            arrayOf("bonito","جميل","O Algarve é bonito.","الغارف جميلة."),
            arrayOf("rápido","سريع","O comboio é rápido.","القطار سريع."),
            arrayOf("devagar","ببطء","Fale mais devagar, por favor.","تحدث ببطء أكثر من فضلك."),
            arrayOf("dinheiro","مال","Não tenho dinheiro comigo.","ليس لدي مال معي."),
            arrayOf("preço","سعر","Qual é o preço?","ما هو السعر؟"),
            arrayOf("loja","متجر","A loja está aberta.","المتجر مفتوح."),
            arrayOf("hospital","مستشفى","Onde fica o hospital?","أين يوجد المستشفى؟"),
            arrayOf("farmácia","صيدلية","A farmácia está aberta.","الصيدلية مفتوحة."),
            arrayOf("ajuda","مساعدة","Preciso da sua ajuda.","أحتاج إلى مساعدتك."),
            arrayOf("saudade","شوق وحنين","Tenho saudades de casa.","أشتاق إلى المنزل.")
        )
        db.beginTransaction()
        try {
            rows.forEach { row ->
                val values = ContentValues().apply {
                    put("portuguese", row[0]); put("arabic", row[1])
                    put("example_pt", row[2]); put("example_ar", row[3])
                }
                val id = db.insert("dictionary", null, values)
                val fts = ContentValues().apply {
                    put("docid", id); put("portuguese", row[0]); put("arabic", row[1])
                    put("example_pt", row[2]); put("example_ar", row[3])
                }
                db.insert("dictionary_fts", null, fts)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun search(rawQuery: String, limit: Int = 50): List<DictionaryEntry> {
        val query = rawQuery.trim()
        val db = readableDatabase
        val result = mutableListOf<DictionaryEntry>()
        val cursor = if (query.isBlank()) {
            db.rawQuery("SELECT _id, portuguese, arabic, example_pt, example_ar FROM dictionary ORDER BY portuguese LIMIT ?", arrayOf(limit.toString()))
        } else {
            val safe = query.replace("\"", "\"\"")
            try {
                db.rawQuery(
                    "SELECT d._id, d.portuguese, d.arabic, d.example_pt, d.example_ar " +
                        "FROM dictionary_fts f JOIN dictionary d ON d._id = f.docid " +
                        "WHERE dictionary_fts MATCH ? ORDER BY d.portuguese LIMIT ?",
                    arrayOf("\"$safe\"*", limit.toString())
                )
            } catch (_: Exception) {
                db.rawQuery(
                    "SELECT _id, portuguese, arabic, example_pt, example_ar FROM dictionary " +
                        "WHERE portuguese LIKE ? OR arabic LIKE ? OR example_pt LIKE ? OR example_ar LIKE ? " +
                        "ORDER BY portuguese LIMIT ?",
                    arrayOf("%$query%", "%$query%", "%$query%", "%$query%", limit.toString())
                )
            }
        }
        cursor.use {
            while (it.moveToNext()) result.add(
                DictionaryEntry(it.getLong(0), it.getString(1), it.getString(2), it.getString(3), it.getString(4))
            )
        }
        return result
    }
}
