import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LusoProApp());
}

const navy = Color(0xFF08152B);
const panel = Color(0xFF142B49);
const panel2 = Color(0xFF1D3C63);
const ice = Color(0xFF9CCEFF);
const gold = Color(0xFFFFC95C);

class LusoProApp extends StatelessWidget {
  const LusoProApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LusoPro 3D',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: navy,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF168DE6), brightness: Brightness.dark),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const AppShell(),
    );
  }
}

class WordEntry {
  final int? id;
  final String pt, ar, examplePt, exampleAr;
  const WordEntry({this.id, required this.pt, required this.ar, required this.examplePt, required this.exampleAr});
  Map<String, Object?> toMap() => {'pt': pt, 'ar': ar, 'example_pt': examplePt, 'example_ar': exampleAr};
  factory WordEntry.fromMap(Map<String, Object?> m) => WordEntry(
    id: m['id'] as int?, pt: m['pt'] as String, ar: m['ar'] as String,
    examplePt: m['example_pt'] as String? ?? '', exampleAr: m['example_ar'] as String? ?? '');
}

class DictionaryDb {
  static final DictionaryDb instance = DictionaryDb._();
  DictionaryDb._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'lusopro_dictionary.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('CREATE TABLE words(id INTEGER PRIMARY KEY AUTOINCREMENT, pt TEXT NOT NULL, ar TEXT NOT NULL, example_pt TEXT, example_ar TEXT)');
      await db.execute('CREATE VIRTUAL TABLE words_fts USING fts4(pt, ar, example_pt, example_ar)');
      final seed = sampleWords;
      for (final w in seed) {
        final id = await db.insert('words', w.toMap());
        await db.insert('words_fts', {'docid': id, ...w.toMap()});
      }
    });
    return _db!;
  }

  Future<List<WordEntry>> search(String query) async {
    final db = await database;
    List<Map<String, Object?>> rows;
    if (query.trim().isEmpty) {
      rows = await db.query('words', orderBy: 'pt COLLATE NOCASE', limit: 100);
    } else {
      final q = query.trim().replaceAll('"', '""');
      try {
        rows = await db.rawQuery(
          'SELECT w.* FROM words_fts f JOIN words w ON w.id=f.docid WHERE words_fts MATCH ? ORDER BY w.pt LIMIT 100',
          ['"$q"*'],
        );
      } catch (_) {
        rows = await db.query('words', where: 'pt LIKE ? OR ar LIKE ? OR example_pt LIKE ? OR example_ar LIKE ?',
          whereArgs: ['%$q%', '%$q%', '%$q%', '%$q%'], orderBy: 'pt', limit: 100);
      }
    }
    return rows.map(WordEntry.fromMap).toList();
  }
}

const sampleWords = <WordEntry>[
  WordEntry(pt:'Olá', ar:'مرحباً', examplePt:'Olá, tudo bem?', exampleAr:'مرحباً، هل كل شيء بخير؟'),
  WordEntry(pt:'Bom dia', ar:'صباح الخير', examplePt:'Bom dia, como está?', exampleAr:'صباح الخير، كيف حالك؟'),
  WordEntry(pt:'Obrigado', ar:'شكراً (للمذكر)', examplePt:'Obrigado pela ajuda.', exampleAr:'شكراً على المساعدة.'),
  WordEntry(pt:'Casa', ar:'منزل', examplePt:'A minha casa é grande.', exampleAr:'منزلي كبير.'),
  WordEntry(pt:'Trabalho', ar:'العمل', examplePt:'Vou para o trabalho.', exampleAr:'أذهب إلى العمل.'),
  WordEntry(pt:'Água', ar:'ماء', examplePt:'Quero beber água.', exampleAr:'أريد شرب الماء.'),
  WordEntry(pt:'Autocarro', ar:'حافلة', examplePt:'Apanho o autocarro às oito.', exampleAr:'أستقل الحافلة في الثامنة.'),
  WordEntry(pt:'Comboio', ar:'قطار', examplePt:'O comboio chega às nove.', exampleAr:'يصل القطار في التاسعة.'),
  WordEntry(pt:'Pequeno-almoço', ar:'وجبة الفطور', examplePt:'Tomo o pequeno-almoço todos os dias.', exampleAr:'أتناول الفطور كل يوم.'),
  WordEntry(pt:'Saudade', ar:'الشوق والحنين', examplePt:'Tenho saudades de casa.', exampleAr:'أشتاق إلى المنزل.'),
  WordEntry(pt:'Aprender', ar:'يتعلم', examplePt:'Quero aprender português.', exampleAr:'أريد تعلم البرتغالية.'),
  WordEntry(pt:'Morada', ar:'عنوان', examplePt:'Qual é a sua morada?', exampleAr:'ما عنوانك؟'),
];

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override State<AppShell> createState() => _AppShellState();
}
class _AppShellState extends State<AppShell> {
  int index = 0;
  String level = 'A1';
  final favorites = <String>{};
  final known = <String>{};
  final tts = FlutterTts();
  @override void initState() {
    super.initState();
    tts.setLanguage('pt-PT');
    tts.setSpeechRate(0.43);
  }
  void speak(String text) => tts.speak(text);
  @override void dispose() { tts.stop(); super.dispose(); }

  @override Widget build(BuildContext context) {
    final pages = [
      HomePage(level: level, onLevel: (v)=>setState(()=>level=v), onNavigate:(v)=>setState(()=>index=v)),
      LessonsPage(level: level),
      DictionaryPage(favorites:favorites, onFavorite:(w)=>setState(()=>favorites.contains(w)?favorites.remove(w):favorites.add(w)), onSpeak:speak),
      FlashcardsPage(favorites:favorites, known:known, onSpeak:speak, onKnown:(w)=>setState(()=>known.add(w)), onFavorite:(w)=>setState(()=>favorites.contains(w)?favorites.remove(w):favorites.add(w))),
      ProgressPage(level:level, known:known, favorites:favorites),
    ];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF0C1D34), indicatorColor: const Color(0xFF234D79),
        selectedIndex:index, onDestinationSelected:(v)=>setState(()=>index=v),
        destinations: const [
          NavigationDestination(icon:Icon(Icons.home_rounded),label:'الرئيسية'),
          NavigationDestination(icon:Icon(Icons.menu_book_rounded),label:'الدروس'),
          NavigationDestination(icon:Icon(Icons.search_rounded),label:'القاموس'),
          NavigationDestination(icon:Icon(Icons.style_rounded),label:'البطاقات'),
          NavigationDestination(icon:Icon(Icons.insights_rounded),label:'تقدمي'),
        ],
      ),
    ));
  }
}

class GlassPanel extends StatelessWidget {
  final Widget child; final EdgeInsets padding;
  const GlassPanel({super.key, required this.child, this.padding=const EdgeInsets.all(16)});
  @override Widget build(BuildContext context)=>Container(
    padding:padding, decoration:BoxDecoration(
      gradient:const LinearGradient(colors:[Color(0xFF1B3A60),Color(0xFF102440)],begin:Alignment.topLeft,end:Alignment.bottomRight),
      borderRadius:BorderRadius.circular(22), border:Border.all(color:ice.withOpacity(.28)),
      boxShadow:[BoxShadow(color:Colors.black.withOpacity(.35),blurRadius:18,offset:const Offset(0,10)),BoxShadow(color:ice.withOpacity(.05),blurRadius:4,offset:const Offset(-2,-2))],
    ), child:child);
}

class PageHeader extends StatelessWidget {
  final String title, subtitle;
  const PageHeader(this.title,{super.key,this.subtitle='Português Europeu 🇵🇹'});
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.fromLTRB(18,16,18,12),child:Row(children:[
    Container(width:48,height:48,decoration:BoxDecoration(borderRadius:BorderRadius.circular(16),gradient:const LinearGradient(colors:[Color(0xFF168DE6),Color(0xFF17345A)]),boxShadow:const [BoxShadow(color:Colors.black54,blurRadius:10,offset:Offset(4,5))]),child:const Center(child:Text('🇵🇹',style:TextStyle(fontSize:26)))),
    const SizedBox(width:12), Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Text(subtitle,style:const TextStyle(color:ice,fontSize:12))])),
  ]));
}

class HomePage extends StatelessWidget {
  final String level; final ValueChanged<String> onLevel; final ValueChanged<int> onNavigate;
  const HomePage({super.key,required this.level,required this.onLevel,required this.onNavigate});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.only(bottom:18),children:[
    const PageHeader('LusoPro 3D'),
    Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:GlassPanel(child:Stack(children:[
      const Positioned(left:0,bottom:0,child:Text('📚  🗣️  🚋',style:TextStyle(fontSize:42))),
      Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('تعلم البرتغالية بثقة',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900)),
        const SizedBox(height:6),const Text('كلمات وقواعد ومحادثات باللغة البرتغالية الأوروبية.',style:TextStyle(color:Colors.white70,height:1.5)),
        const SizedBox(height:18),Row(children:['A1','A2','B1'].map((v)=>Expanded(child:Padding(padding:const EdgeInsetsDirectional.only(end:8),child:ChoiceChip(label:Text(v),selected:level==v,onSelected:(_)=>onLevel(v),selectedColor:const Color(0xFF168DE6))))).toList()),
      ]),
    ]))),
    const Padding(padding:EdgeInsets.fromLTRB(18,22,18,8),child:Text('ماذا تريد أن تتعلم اليوم؟',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold))),
    Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,mainAxisSpacing:12,crossAxisSpacing:12,childAspectRatio:1.35,children:[
      _HomeTile('📖','الدروس','تعلم خطوة بخطوة',()=>onNavigate(1)),
      _HomeTile('🔎','القاموس','بحث برتغالي وعربي',()=>onNavigate(2)),
      _HomeTile('🃏','البطاقات','احفظ المفردات',()=>onNavigate(3)),
      _HomeTile('🎓','القواعد','شرح وأمثلة',()=>onNavigate(1)),
      _HomeTile('🎧','الاستماع','تدرب على النطق',()=>onNavigate(2)),
      _HomeTile('💬','المحادثات','مواقف يومية',()=>onNavigate(1)),
    ])),
    Padding(padding:const EdgeInsets.all(16),child:GlassPanel(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Row(children:[Text('كلمة اليوم',style:TextStyle(fontWeight:FontWeight.bold)),Spacer(),Chip(label:Text('A1'))]),
      const Text('Saudade',style:TextStyle(fontSize:30,color:ice,fontWeight:FontWeight.w900)),
      const Text('الشوق والحنين',style:TextStyle(fontSize:18)),
      const SizedBox(height:8),const Text('Tenho saudades de casa.',style:TextStyle(color:Colors.white70)),
      const Text('أشتاق إلى المنزل.',style:TextStyle(color:Colors.white54)),
    ]))),
  ]);
}
class _HomeTile extends StatelessWidget {
  final String emoji,title,sub;final VoidCallback onTap;
  const _HomeTile(this.emoji,this.title,this.sub,this.onTap);
  @override Widget build(BuildContext context)=>InkWell(onTap:onTap,borderRadius:BorderRadius.circular(20),child:GlassPanel(child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[
    Text(emoji,style:const TextStyle(fontSize:31,shadows:[Shadow(color:Colors.black54,blurRadius:8,offset:Offset(4,5))])),
    const SizedBox(height:6),Text(title,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16)),Text(sub,style:const TextStyle(color:Colors.white60,fontSize:11)),
  ])));
}

class DictionaryPage extends StatefulWidget {
  final Set<String> favorites;final ValueChanged<String> onFavorite;final ValueChanged<String> onSpeak;
  const DictionaryPage({super.key,required this.favorites,required this.onFavorite,required this.onSpeak});
  @override State<DictionaryPage> createState()=>_DictionaryPageState();
}
class _DictionaryPageState extends State<DictionaryPage> {
  final controller=TextEditingController();List<WordEntry> results=[];bool loading=true;
  @override void initState(){super.initState();_search('');controller.addListener(()=>_search(controller.text));}
  Future<void> _search(String q) async {setState(()=>loading=true);try{final r=await DictionaryDb.instance.search(q);if(mounted)setState(()=>results=r);}catch(_){if(mounted)setState(()=>results=sampleWords.where((w)=>('${w.pt} ${w.ar}').toLowerCase().contains(q.toLowerCase())).toList());}if(mounted)setState(()=>loading=false);}
  @override void dispose(){controller.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Column(children:[
    const PageHeader('القاموس الشامل',subtitle:'بحث محلي • برتغالي وعربي'),
    Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:TextField(controller:controller,decoration:InputDecoration(hintText:'ابحث بالبرتغالية أو العربية...',prefixIcon:const Icon(Icons.search),filled:true,fillColor:panel,border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide(color:ice.withOpacity(.25)))))),
    if(loading)const LinearProgressIndicator(minHeight:2),
    Expanded(child:ListView.builder(padding:const EdgeInsets.all(16),itemCount:results.length,itemBuilder:(c,i){final w=results[i];return Padding(padding:const EdgeInsets.only(bottom:10),child:GlassPanel(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[Expanded(child:Text(w.pt,style:const TextStyle(color:ice,fontSize:21,fontWeight:FontWeight.w900))),IconButton(onPressed:()=>widget.onSpeak(w.pt),icon:const Icon(Icons.volume_up_rounded,color:ice)),IconButton(onPressed:()=>widget.onFavorite(w.pt),icon:Icon(widget.favorites.contains(w.pt)?Icons.favorite:Icons.favorite_border,color:Colors.pinkAccent))]),
      Text(w.ar,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w600)),const SizedBox(height:8),Text(w.examplePt,style:const TextStyle(color:Colors.white70)),Text(w.exampleAr,style:const TextStyle(color:Colors.white54)),
    ])));})),
  ]);
}

class FlashcardsPage extends StatefulWidget {
  final Set<String> favorites,known;final ValueChanged<String> onSpeak,onKnown,onFavorite;
  const FlashcardsPage({super.key,required this.favorites,required this.known,required this.onSpeak,required this.onKnown,required this.onFavorite});
  @override State<FlashcardsPage> createState()=>_FlashcardsPageState();
}
class _FlashcardsPageState extends State<FlashcardsPage>{
  int index=0;bool flipped=false;WordEntry get word=>sampleWords[index];
  void next(int d){setState(() { index=(index+d+sampleWords.length)%sampleWords.length; flipped=false; });}
  @override Widget build(BuildContext context)=>Column(children:[
    const PageHeader('البطاقات التعليمية'),
    Padding(padding:const EdgeInsets.symmetric(horizontal:18),child:Row(children:[Text('${index+1} / ${sampleWords.length}',style:const TextStyle(color:ice)),const Spacer(),Text('المعروفة: ${widget.known.length}',style:const TextStyle(color:Colors.white60))])),
    Padding(padding:const EdgeInsets.all(16),child:InkWell(onTap:()=>setState(()=>flipped=!flipped),child:GlassPanel(child:SizedBox(height:300,width:double.infinity,child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
      Text(flipped?'الترجمة العربية':'PORTUGUÊS EUROPEU',style:const TextStyle(color:Colors.white60,fontSize:12)),
      const SizedBox(height:24),Text(flipped?word.ar:word.pt,textAlign:TextAlign.center,style:const TextStyle(fontSize:32,color:ice,fontWeight:FontWeight.w900)),
      const SizedBox(height:14),Text(flipped?word.exampleAr:word.examplePt,textAlign:TextAlign.center,style:const TextStyle(fontSize:16,color:Colors.white70)),
      const SizedBox(height:20),const Icon(Icons.flip_rounded,color:ice,size:28),const Text('اضغط لقلب البطاقة',style:TextStyle(color:Colors.white54)),
    ]))))),
    Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[OutlinedButton(onPressed:()=>next(-1),child:const Text('السابق')),ElevatedButton(onPressed:()=>next(1),child:const Text('التالي'))]),
    const SizedBox(height:14),Wrap(spacing:10,children:[
      FilledButton.icon(onPressed:()=>setState(()=>widget.onKnown(word.pt)),icon:const Icon(Icons.check),label:const Text('أعرفها')),
      OutlinedButton.icon(onPressed:()=>setState(()=>widget.onFavorite(word.pt)),icon:const Icon(Icons.favorite_border),label:const Text('المفضلة')),
      IconButton(onPressed:()=>widget.onSpeak(word.pt),icon:const Icon(Icons.volume_up,color:ice)),
    ]),
  ]);
}

class LessonsPage extends StatelessWidget {
  final String level;const LessonsPage({super.key,required this.level});
  static const items=[('التحيات والتعارف','Cumprimentos e apresentações','👋','A1'),('الأرقام والأيام','Números e dias da semana','📅','A1'),('العائلة','A família','👨‍👩‍👧','A1'),('الطعام والشراب','Comida e bebidas','🥐','A1'),('الحياة اليومية','A rotina diária','⏰','A2'),('السكن والعمل','Casa e trabalho','🏠','A2'),('التواصل في العمل','Comunicação no trabalho','💼','B1')];
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.only(bottom:18),children:[
    const PageHeader('الدروس المنظمة',subtitle:'تعلم تدريجي من A1 إلى B1'),
    Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Text('المستوى المختار: $level',style:const TextStyle(color:ice,fontWeight:FontWeight.bold))),
    ...items.where((x)=>x.$4==level || level=='B1').map((x)=>Padding(padding:const EdgeInsets.fromLTRB(16,10,16,0),child:GlassPanel(child:Row(children:[
      Text(x.$3,style:const TextStyle(fontSize:32)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(x.$1,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16)),Text(x.$2,style:const TextStyle(color:Colors.white60,fontSize:12))])),Chip(label:Text(x.$4)),
    ])))),
  ]);
}
class ProgressPage extends StatelessWidget {
  final String level;final Set<String> known,favorites;
  const ProgressPage({super.key,required this.level,required this.known,required this.favorites});
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
    const PageHeader('تقدمي الدراسي'),
    GlassPanel(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(level,style:const TextStyle(fontSize:34,color:ice,fontWeight:FontWeight.w900)),const Text('المستوى الحالي'),
      const SizedBox(height:20),_stat('الكلمات التي أعرفها',known.length.toString()),_stat('كلمات المفضلة',favorites.length.toString()),_stat('أهداف التعلم','يومي'),
    ])),
  ]);
}
Widget _stat(String a,String b)=>Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Row(children:[Expanded(child:Text(a)),Text(b,style:const TextStyle(color:ice,fontWeight:FontWeight.bold))]));
