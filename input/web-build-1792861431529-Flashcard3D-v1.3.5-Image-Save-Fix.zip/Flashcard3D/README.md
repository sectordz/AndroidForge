# Flashcard 3D — Android demo

A new standalone Android Studio project for a single Portuguese-Arabic 3D-style learning card (`avô` / `الجدّ`). It does not modify or depend on PortugueseWordReminder.

## Build
1. Open this folder in Android Studio (Giraffe or newer recommended).
2. Allow Gradle sync; Android Gradle Plugin 8.7.3 and Kotlin 2.0.21 are declared in the build files.
3. Install Android SDK Platform 35 if prompted.
4. Select **Run** to install on an Android device or emulator.

The UI is an offline HTML/CSS screen rendered in Android WebView. The speak buttons call Android TextToSpeech with Portuguese (Portugal). Actual voice availability depends on the device's installed TTS voice data.

## Project structure
- `app/src/main/java/com/flashcard3d/demo/MainActivity.kt`: WebView host and native TTS bridge
- `app/src/main/assets/index.html`: card UI, styling and button interactions
- `app/src/main/assets/avo-grandfather.png`: image asset used in the demo

No internet permission or remote assets are required. This is a source project, not a prebuilt APK.

## Layout adjustment
The grandfather portrait is positioned lower with extra breathing room below the progress bar, and the word card spacing is adjusted to keep the hat/head visually clear on tall and short screens.


## Excel import (v1.1.0)

The Android app now has an **استيراد كلمات من Excel** action in Settings. Select an `.xlsx` workbook; the app reads the first worksheet and maps column headers to the card fields. Supported header examples:

- Portuguese word: `Português`, `Palavra`, `Palavra (Português)`, `word`, or `الكلمة`
- Arabic translation: `العربية`, `Tradução`, `translation`, or `ترجمة`
- Word class: `نوع الكلمة`, `Categoria`, `category`, or `tipo`
- Portuguese example: `Exemplo`, `Exemplo (Português)`, `example`, or `المثال`
- Arabic example translation: `ترجمة المثال`, `Tradução do exemplo`, `example translation`, or `ترجمة الجملة`

Imported cards are saved locally on the device and can be browsed with the previous/next buttons. Speech uses the existing Portuguese (Portugal) text-to-speech bridge. When no dedicated illustration is included, the app shows a contextual emoji illustration; the existing grandfather image remains for `avô`. Embedded Excel pictures are not extracted. Use `.xlsx` (not legacy `.xls`).


Excel image support: the Android importer now extracts images embedded in XLSX drawing anchors and displays the matching row image in the flashcard. Re-import the workbook after installing this build to refresh saved words.


Excel image import fix: image extraction now recognizes DrawingML's qualified `a:blip` element, which is how embedded pictures are commonly represented in XLSX drawing XML. Rebuild the APK and re-import the workbook to replace old emoji placeholders.

## Manual image replacement (v1.2.0)
- Open Settings and enable **تفعيل تغيير صور الكلمات**.
- Tap the current word's image and select a picture from the Android file picker.
- The selected image is copied into the app's private `files/word_images` folder as a PNG, preserving transparency and resizing oversized images to a maximum dimension of 1600 px.
- Image overrides are keyed by the normalized Portuguese word and remain available after app restarts and Excel re-imports. Turn the setting off to make the image display-only again.
- The image display uses a transparent background with no CSS frame or shadow, so transparent PNGs display without an added card frame.


## Image replacement fix (v1.2.6)
- Selected images are saved in the app-private `files/word_images` directory, keyed by normalized word.
- Selecting an image no longer creates an extra image in the phone gallery. Replacing a word's image overwrites its existing private file.
- Export a full ZIP backup before clearing app storage. Restore the ZIP afterward to recover words and customized images; clearing app storage deletes private files by Android design.


## Backup and restore (v1.2.5)
- Settings now provide full ZIP backup export and restore.
- The ZIP contains `backup.json` and image files under `images/`.
- Restore replaces the current word list (it does not merge) and restores customized images to the app-private image folder, without adding gallery photos.
- Excel import remains available separately.
