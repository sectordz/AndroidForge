plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.flashcard3d.demo"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.flashcard3d.demo"
        minSdk = 23
        targetSdk = 34
        versionCode = 8
        versionName = "1.3.4"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
