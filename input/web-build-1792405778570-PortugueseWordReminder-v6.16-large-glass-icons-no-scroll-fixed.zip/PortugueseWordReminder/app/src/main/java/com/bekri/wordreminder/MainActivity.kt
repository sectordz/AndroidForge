package com.bekri.wordreminder

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.*
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

 data class Word(val pt: String, val ar: String, val examplePt: String = "", val exampleAr: String = "", val category: String = "", val categoryManual: Boolean = false)

private fun notificationWordKey(pt: String, ar: String): String =
    "${pt.trim().lowercase(Locale.ROOT)}|${ar.trim().lowercase(Locale.ROOT)}"

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val prefs by lazy { getSharedPreferences("words", MODE_PRIVATE) }
    private val words = mutableListOf<Word>()
    private lateinit var list: LinearLayout
    private var status: TextView? = null
    private lateinit var intervalSpinner: Spinner
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val exportRequest = 431
    private val importRequest = 432
    private var showingMyWords = false
    private var showingConjugations = false
    private var showingTimeVocabulary = false
    private var showingTimeWordList = false
    private var refreshNumbers: () -> Unit = {}
    // Dedicated navigation stack for the learning hub and its learning modes.
    private var flashcardsHubView: View? = null
    private var learningHubShowing = false
    private var learningGameShowing = false

    private fun learningScreenRoot(content: View, backgroundColor: Int): View {
        val root = FrameLayout(this).apply {
            setBackgroundColor(backgroundColor)
            setOnApplyWindowInsetsListener { view, insets ->
                val top: Int
                val bottom: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    top = bars.top
                    bottom = bars.bottom
                } else {
                    @Suppress("DEPRECATION")
                    run { top = insets.systemWindowInsetTop; bottom = insets.systemWindowInsetBottom }
                }
                view.setPadding(0, top, 0, bottom)
                insets
            }
        }
        root.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        return root
    }

    private fun showLearningGame(view: View) {
        learningHubShowing = true
        learningGameShowing = true
        val bg = if (prefs.getBoolean("home_dark", false)) 0xFF0B1220.toInt() else 0xFFF1F7FF.toInt()
        setContentView(learningScreenRoot(view, bg))
    }

    private fun returnToLearningHub() {
        val hub = flashcardsHubView
        if (hub != null) {
            learningHubShowing = true
            learningGameShowing = false
            setContentView(hub)
        } else {
            learningHubShowing = false
            learningGameShowing = false
            buildUi()
        }
    }

    private fun closeLearningHub() {
        flashcardsHubView = null
        learningHubShowing = false
        learningGameShowing = false
        buildUi()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        loadWords()
        buildUi()
        askNotificationPermission()
        updateStatus()
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("pt", "PT"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun buildUi() {
        flashcardsHubView = null
        learningHubShowing = false
        learningGameShowing = false
        showingMyWords = false
        showingConjugations = false
        showingTimeVocabulary = false
        showingTimeWordList = false
        val dark = prefs.getBoolean("home_dark", false)
        val bg = if (dark) 0xFF101827.toInt() else 0xFFF1F8FF.toInt()
        val ink = if (dark) Color.WHITE else 0xFF14294D.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
            setBackgroundColor(bg)
            setOnApplyWindowInsetsListener { view, insets ->
                val top: Int; val bottom: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    top = bars.top; bottom = bars.bottom
                } else {
                    @Suppress("DEPRECATION")
                    run { top = insets.systemWindowInsetTop; bottom = insets.systemWindowInsetBottom }
                }
                view.setPadding(0, top, 0, bottom); insets
            }
        }
        // Scale the dashboard to the available screen height so the eight feature cards
        // fit on common phones without scrolling; small phones retain safe scrolling.
        val screenHeightDp = resources.configuration.screenHeightDp
        val screenWidthDp = resources.configuration.screenWidthDp
        val compact = screenHeightDp < 820
        val tiny = screenHeightDp < 740
        val horizontalPad = if (screenWidthDp < 360) 8 else 10
        val heroHeightDp = when { tiny -> 132; compact -> 150; else -> 172 }
        val cardHeightDp = when { tiny -> 91; compact -> 104; else -> 120 }
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(horizontalPad), dp(if (tiny) 4 else 6), dp(horizontalPad), dp(4)) }
        scroll.addView(content)

        // Hero area: scenic Portuguese banner, app title, couple label and theme switch.
        val hero = FrameLayout(this).apply {
            background = rounded(0xFF168FE8.toInt(), 28); clipToOutline = true; elevation = 3f
        }
        hero.addView(ImageView(this).apply {
            setImageResource(R.drawable.portugal_banner); scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "منظر ساحلي من البرتغال"
        }, FrameLayout.LayoutParams(-1, dp(heroHeightDp)))
        val shade = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x220057B8, 0x000057B8, 0x990057B8.toInt()))
        }
        hero.addView(shade, FrameLayout.LayoutParams(-1, dp(heroHeightDp)))
        val heroColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(if (tiny) 4 else 8), dp(8), dp(5)) }
        val logo = ImageView(this).apply { setImageResource(R.drawable.portugal_book_icon); scaleType = ImageView.ScaleType.FIT_CENTER; contentDescription = "كتاب اللغة البرتغالية" }
        heroColumn.addView(logo, LinearLayout.LayoutParams(dp(if (tiny) 64 else if (compact) 76 else 88), dp(if (tiny) 42 else if (compact) 48 else 54)))
        heroColumn.addView(TextView(this).apply { text = "Português"; textSize = if (tiny) 21f else if (compact) 24f else 27f; setTextColor(0xFF092A70.toInt()); gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD) })
        heroColumn.addView(TextView(this).apply { text = "تعلّم يوميًا"; textSize = if (tiny) 13f else if (compact) 15f else 17f; setTextColor(0xFF102A55.toInt()); gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD) })
        heroColumn.addView(TextView(this).apply { text = "♥  Racha & Med  ♥"; textSize = if (tiny) 12f else if (compact) 13f else 14f; setTextColor(0xFF14294D.toInt()); gravity = Gravity.CENTER; maxLines = 1; includeFontPadding = false; setPadding(dp(10), dp(1), dp(10), dp(1)); background = rounded(0xFFFFD6E4.toInt(), 22) })
        hero.addView(heroColumn, FrameLayout.LayoutParams(-1, dp(heroHeightDp)))
        val theme = TextView(this).apply {
            text = if (dark) "🌙  ☀️" else "☀️  🌙"; textSize = 19f; gravity = Gravity.CENTER; setTextColor(0xFF14294D.toInt()); background = rounded(Color.WHITE, 30); setPadding(12, 7, 12, 7); elevation = 2f
            setOnClickListener { prefs.edit().putBoolean("home_dark", !dark).apply(); buildUi() }
        }
        hero.addView(theme, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36), Gravity.TOP or Gravity.END).apply { rightMargin = dp(8); topMargin = dp(8) })
        content.addView(hero, LinearLayout.LayoutParams(-1, dp(heroHeightDp)).apply { bottomMargin = dp(6) })

        // Two-column colorful feature cards, each with its own illustration.
        fun featureRow(left: View, right: View) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(left, LinearLayout.LayoutParams(0, dp(cardHeightDp), 1f).apply { setMargins(0, 0, dp(3), dp(if (tiny) 3 else 5)) })
            row.addView(right, LinearLayout.LayoutParams(0, dp(cardHeightDp), 1f).apply { setMargins(dp(3), 0, 0, dp(if (tiny) 3 else 5)) })
            content.addView(row)
        }
        featureRow(homeCard(R.drawable.books_icon, "تعلم الكلمات", "البطاقات التعليمية", 0xFF00A66A.toInt()) { startFlashcards() },
            homeCard(R.drawable.target_icon, "اختبار الكلمات", "اختر مستواك", 0xFF6425E8.toInt()) { startQuiz() })
        featureRow(homeCard(R.drawable.running_icon, "تصريف الأفعال", "جميع الأزمنة", 0xFFFF8A00.toInt()) { showConjugations() },
            homeCard(R.drawable.excel_icon, "استيراد كلمات", "Excel", 0xFF087AF0.toInt()) { importWords() })
        featureRow(homeCard(R.drawable.portuguese_numbers_icon, "الأرقام البرتغالية", "تعلم الأرقام ونطقها", 0xFFE91E78.toInt()) { showNumbers() },
            homeCard(R.drawable.search_icon, "كلماتي", "البحث والتصنيف", 0xFF00A9A5.toInt()) { showMyWords() })
        featureRow(homeCard(R.drawable.time_vocabulary_icon, "مفردات الزمن", "أيام • شهور • فصول", 0xFF2876E8.toInt()) { showTimeVocabulary() },
            homeCard(R.drawable.speaker_icon, "التذكيرات", "تشغيل التذكير", 0xFF168B55.toInt()) { requestExactAlarmThenSchedule() })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(4, 5, 4, 5); background = rounded(if (dark) 0xFF202B3C.toInt() else Color.WHITE, 20); elevation = 5f }
        fun navItem(label: String, iconRes: Int, action: () -> Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(2, 3, 2, 3); isClickable = true; setOnClickListener { action() }
            addView(ImageView(this@MainActivity).apply { setImageResource(iconRes); scaleType = ImageView.ScaleType.FIT_CENTER; contentDescription = label }, LinearLayout.LayoutParams((34 * resources.displayMetrics.density).toInt(), (34 * resources.displayMetrics.density).toInt()))
            addView(TextView(this@MainActivity).apply { text = label; textSize = 12f; gravity = Gravity.CENTER; setTextColor(if (label == "الرئيسية") 0xFF087AF0.toInt() else if (dark) 0xFFD8E2F0.toInt() else 0xFF64748B.toInt()) })
        }
        nav.addView(navItem("الرئيسية", R.drawable.home_nav_icon) { buildUi() }, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(navItem("كلماتي", R.drawable.mywords_nav_icon) { showMyWords() }, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(navItem("إضافة", R.drawable.add_nav_icon) { editWord(null) }, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(navItem("الإحصائيات", R.drawable.stats_nav_icon) { showStats() }, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(navItem("الإعدادات", R.drawable.settings_nav_icon) { showSettingsDialog() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(nav, LinearLayout.LayoutParams(-1, -2).apply { setMargins(10, 4, 10, 5) })
        setContentView(root)
        // The home screen no longer contains the saved-words list.
        // Do not call renderWords() here: its list view is initialized only on the My Words screen.
    }

    private fun homeCard(iconRes: Int, title: String, subtitle: String, color: Int, action: () -> Unit): View {
        val compactCard = resources.configuration.screenHeightDp < 820
        val tinyCard = resources.configuration.screenHeightDp < 740
        val iconSize = dp(if (tinyCard) 62 else if (compactCard) 76 else 96)
        val iconHeight = dp(if (tinyCard) 58 else if (compactCard) 68 else 82)
        val card = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(lighten(color, 0.18f), color)).apply { cornerRadius = 24 * resources.displayMetrics.density }
            elevation = 3f; isClickable = true; isFocusable = true; setOnClickListener { action() }
        }
        if (iconRes == 0) {
            card.addView(TextView(this).apply { text = "🔢"; textSize = 62f; gravity = Gravity.CENTER; contentDescription = title },
                FrameLayout.LayoutParams((112 * resources.displayMetrics.density).toInt(), (98 * resources.displayMetrics.density).toInt(), Gravity.TOP or Gravity.START).apply { leftMargin = (10 * resources.displayMetrics.density).toInt(); topMargin = (7 * resources.displayMetrics.density).toInt() })
        } else {
            val icon = ImageView(this).apply { setImageResource(iconRes); scaleType = ImageView.ScaleType.FIT_CENTER; adjustViewBounds = true; setBackgroundColor(Color.TRANSPARENT); contentDescription = title }
            card.addView(icon, FrameLayout.LayoutParams(iconSize, iconHeight, Gravity.TOP or Gravity.START).apply { leftMargin = dp(if (tinyCard) 5 else 9); topMargin = dp(5) })
        }
        card.addView(TextView(this).apply { text = "›"; textSize = 29f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = rounded(0x55FFFFFF, 50) }, FrameLayout.LayoutParams((38 * resources.displayMetrics.density).toInt(), (38 * resources.displayMetrics.density).toInt(), Gravity.TOP or Gravity.END).apply { rightMargin = (12 * resources.displayMetrics.density).toInt(); topMargin = (18 * resources.displayMetrics.density).toInt() })
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 0, 8, 0) }
        labels.addView(TextView(this).apply { text = title; textSize = 17f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) })
        labels.addView(TextView(this).apply { text = subtitle; textSize = 14f; setTextColor(0xFFF4F8FF.toInt()) })
        card.addView(labels, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = (13 * resources.displayMetrics.density).toInt() })
        return card
    }

    private fun showTimeVocabulary() {
        showingMyWords = false
        showingConjugations = false
        showingTimeVocabulary = true
        showingTimeWordList = false
        val dark = prefs.getBoolean("home_dark", false)
        val bg = if (dark) 0xFF101827.toInt() else 0xFFF1F8FF.toInt()
        val ink = if (dark) Color.WHITE else 0xFF14294D.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val density = resources.displayMetrics.density
            val side = (12 * density).toInt()
            val topGap = (10 * density).toInt()
            val bottomGap = (8 * density).toInt()
            setPadding(side, topGap, side, bottomGap)
            setBackgroundColor(bg)
            // Keep the title and back button below Android's status bar, and content above navigation bar.
            setOnApplyWindowInsetsListener { view, insets ->
                val topInset: Int
                val bottomInset: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    topInset = bars.top
                    bottomInset = bars.bottom
                } else {
                    @Suppress("DEPRECATION")
                    run { topInset = insets.systemWindowInsetTop; bottomInset = insets.systemWindowInsetBottom }
                }
                view.setPadding(side, topInset + topGap, side, bottomInset + bottomGap)
                insets
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 14, 12, 14)
            background = rounded(0xFF1769E8.toInt(), 20)
        }
        header.addView(makeTile("← رجوع", 0xFF0D47A1.toInt()) {
            showingTimeVocabulary = false
            showingTimeWordList = false
            buildUi()
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(TextView(this).apply {
            text = "مفردات الزمن والألوان"
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "🇵🇹"
            textSize = 25f
            gravity = Gravity.CENTER
        })
        root.addView(header, marginParams())
        root.addView(TextView(this).apply {
            text = "تعلّم الأيام والشهور والفصول مع النطق البرتغالي الأوروبي"
            textSize = 15f
            setTextColor(if (dark) 0xFFD5E1F1.toInt() else 0xFF52647D.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 10, 8, 12)
        })
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun category(icon: Int, title: String, subtitle: String, color: Int, action: () -> Unit) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(12, 10, 12, 10)
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    intArrayOf(lighten(color, 0.18f), color)).apply { cornerRadius = 24 * resources.displayMetrics.density }
                elevation = 3f
                isClickable = true
                isFocusable = true
                setOnClickListener { action() }
            }
            if (icon == 0) {
                card.addView(TextView(this@MainActivity).apply {
                    text = when (title) { "الألوان" -> "🎨"; "الخضر" -> "🥦"; "الفواكه" -> "🍎"; else -> "📚" }; textSize = 66f; gravity = Gravity.CENTER; contentDescription = title
                }, LinearLayout.LayoutParams((112 * resources.displayMetrics.density).toInt(), (112 * resources.displayMetrics.density).toInt()))
            } else {
                card.addView(ImageView(this@MainActivity).apply {
                    setImageResource(icon)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    contentDescription = title
                }, LinearLayout.LayoutParams((112 * resources.displayMetrics.density).toInt(), (112 * resources.displayMetrics.density).toInt()))
            }
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 0, 4, 0) }
            labels.addView(TextView(this).apply { text = title; textSize = 23f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) })
            labels.addView(TextView(this).apply { text = subtitle; textSize = 16f; setTextColor(0xFFF5F8FF.toInt()); setPadding(0, 4, 0, 0) })
            card.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(TextView(this).apply { text = "›"; textSize = 35f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(32, -2))
            body.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = (12 * resources.displayMetrics.density).toInt() })
        }
        category(R.drawable.weekdays_icon, "أيام الأسبوع", "7 أيام • مع النطق والأمثلة", 0xFFFFA51E.toInt()) { showTimeWordList("days") }
        category(R.drawable.months_icon, "شهور السنة", "12 شهرًا • مع النطق", 0xFF087AF0.toInt()) { showTimeWordList("months") }
        category(R.drawable.seasons_icon, "فصول السنة", "4 فصول • مع النطق", 0xFF17A84A.toInt()) { showTimeWordList("seasons") }
        category(0, "الألوان", "تعلّم أسماء الألوان مع النطق", 0xFFB02BEF.toInt()) { showTimeWordList("colors") }
        category(0, "الخضر", "تعلّم أسماء الخضر مع الصور والنطق", 0xFF12B84A.toInt()) { showTimeWordList("vegetables") }
        category(0, "الفواكه", "تعلّم أسماء الفواكه مع الصور والنطق", 0xFFFF2878.toInt()) { showTimeWordList("fruits") }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showTimeWordList(kind: String) {
        showingMyWords = false
        showingConjugations = false
        showingTimeVocabulary = false
        showingTimeWordList = true
        val entries: List<Pair<String, String>> = when (kind) {
            "days" -> listOf(
                "segunda-feira" to "الاثنين", "terça-feira" to "الثلاثاء",
                "quarta-feira" to "الأربعاء", "quinta-feira" to "الخميس",
                "sexta-feira" to "الجمعة", "sábado" to "السبت", "domingo" to "الأحد"
            )
            "months" -> listOf(
                "janeiro" to "يناير", "fevereiro" to "فبراير", "março" to "مارس",
                "abril" to "أبريل", "maio" to "مايو", "junho" to "يونيو",
                "julho" to "يوليو", "agosto" to "أغسطس", "setembro" to "سبتمبر",
                "outubro" to "أكتوبر", "novembro" to "نوفمبر", "dezembro" to "ديسمبر"
            )
            "seasons" -> listOf("Primavera" to "الربيع", "Verão" to "الصيف", "Outono" to "الخريف", "Inverno" to "الشتاء")
            "vegetables" -> listOf(
                "tomate" to "طماطم", "cenoura" to "جزر", "cebola" to "بصل", "batata" to "بطاطا",
                "alface" to "خس", "pepino" to "خيار", "pimento" to "فلفل حلو", "brócolos" to "بروكلي",
                "couve" to "ملفوف", "couve-flor" to "قرنبيط", "alho" to "ثوم", "beringela" to "باذنجان",
                "curgete" to "كوسا", "ervilhas" to "بازلاء", "feijão-verde" to "فاصوليا خضراء",
                "milho" to "ذرة", "abóbora" to "قرع", "espinafres" to "سبانخ", "rabanete" to "فجل", "nabo" to "لفت"
            )
            "fruits" -> listOf(
                "maçã" to "تفاح", "banana" to "موز", "laranja" to "برتقال", "morango" to "فراولة",
                "uva" to "عنب", "pera" to "كمثرى", "pêssego" to "خوخ", "ameixa" to "برقوق",
                "cereja" to "كرز", "melancia" to "بطيخ أحمر", "melão" to "شمام", "ananás" to "أناناس",
                "manga" to "مانجو", "kiwi" to "كيوي", "limão" to "ليمون", "tangerina" to "يوسفي",
                "romã" to "رمان", "figo" to "تين", "damasco" to "مشمش", "abacate" to "أفوكادو",
                "framboesa" to "توت العليق", "mirtilo" to "توت أزرق", "coco" to "جوز الهند", "maracujá" to "باشن فروت"
            )
            else -> listOf(
                "branco" to "أبيض", "preto" to "أسود", "vermelho" to "أحمر", "azul" to "أزرق",
                "verde" to "أخضر", "amarelo" to "أصفر", "laranja" to "برتقالي", "cor-de-rosa" to "وردي",
                "roxo" to "بنفسجي", "castanho" to "بني", "cinzento" to "رمادي", "bege" to "بيج",
                "azul-claro" to "أزرق فاتح", "azul-escuro" to "أزرق داكن", "verde-claro" to "أخضر فاتح",
                "verde-escuro" to "أخضر داكن", "dourado" to "ذهبي", "prateado" to "فضي"
            )
        }
        val title = when (kind) { "days" -> "أيام الأسبوع"; "months" -> "شهور السنة"; "seasons" -> "فصول السنة"; "vegetables" -> "الخضر"; "fruits" -> "الفواكه"; else -> "الألوان" }
        val dark = prefs.getBoolean("home_dark", false)
        val bg = if (dark) 0xFF101827.toInt() else 0xFFF1F8FF.toInt()
        val ink = if (dark) Color.WHITE else 0xFF14294D.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val density = resources.displayMetrics.density
            val side = (12 * density).toInt()
            val topGap = (10 * density).toInt()
            val bottomGap = (8 * density).toInt()
            setPadding(side, topGap, side, bottomGap)
            setBackgroundColor(bg)
            // Apply system-bar insets so the back button is never hidden by the clock/status icons.
            setOnApplyWindowInsetsListener { view, insets ->
                val topInset: Int
                val bottomInset: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    topInset = bars.top
                    bottomInset = bars.bottom
                } else {
                    @Suppress("DEPRECATION")
                    run { topInset = insets.systemWindowInsetTop; bottomInset = insets.systemWindowInsetBottom }
                }
                view.setPadding(side, topInset + topGap, side, bottomInset + bottomGap)
                insets
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 14, 12, 14)
            background = rounded(0xFF1769E8.toInt(), 20)
        }
        header.addView(makeTile("← رجوع", 0xFF0D47A1.toInt()) {
            showingTimeWordList = false
            showTimeVocabulary()
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(TextView(this).apply {
            text = title
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply { text = "🇵🇹"; textSize = 25f; gravity = Gravity.CENTER })
        root.addView(header, marginParams())
        root.addView(TextView(this).apply {
            text = "اضغط على أيقونة الصوت لسماع النطق بالبرتغالية الأوروبية 🔊"
            textSize = 15f; setTextColor(if (dark) 0xFFD5E1F1.toInt() else 0xFF52647D.toInt()); gravity = Gravity.CENTER; setPadding(8, 10, 8, 12)
        })
        val scroll = ScrollView(this)
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        entries.forEachIndexed { index, entry ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(14, 10, 12, 10)
                background = rounded(if (dark) if (index % 2 == 0) 0xFF202E43.toInt() else 0xFF26364D.toInt() else Color.WHITE, 20)
                elevation = 2f
            }
            if (kind == "vegetables" || kind == "fruits") {
                val foodIcons = if (kind == "vegetables") listOf("🍅", "🥕", "🧅", "🥔", "🥬", "🥒", "🫑", "🥦", "🥬", "🥦", "🧄", "🍆", "🥒", "🟢", "🫛", "🌽", "🎃", "🥬", "🌱", "🥔") else listOf("🍎", "🍌", "🍊", "🍓", "🍇", "🍐", "🍑", "🟣", "🍒", "🍉", "🍈", "🍍", "🥭", "🥝", "🍋", "🍊", "🔴", "🟣", "🍑", "🥑", "🍓", "🫐", "🥥", "🥭")
                row.addView(TextView(this).apply {
                    text = foodIcons.getOrElse(index) { if (kind == "fruits") "🍎" else "🥕" }
                    textSize = 36f; gravity = Gravity.CENTER; contentDescription = entry.second
                }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { rightMargin = dp(8) })
            }
            if (kind == "colors") {
                val swatchColors = listOf(0xFFFFFFFF.toInt(), 0xFF111111.toInt(), 0xFFE53935.toInt(), 0xFF1976D2.toInt(), 0xFF2EAD62.toInt(), 0xFFFFD600.toInt(), 0xFFFF8A00.toInt(), 0xFFFF80AB.toInt(), 0xFF8E24AA.toInt(), 0xFF795548.toInt(), 0xFF9E9E9E.toInt(), 0xFFD7CCC8.toInt(), 0xFF81D4FA.toInt(), 0xFF0D47A1.toInt(), 0xFFA5D6A7.toInt(), 0xFF1B5E20.toInt(), 0xFFFFC107.toInt(), 0xFFC0C0C0.toInt())
                row.addView(View(this).apply {
                    background = GradientDrawable().apply { shape = GradientDrawable.RECTANGLE; setColor(swatchColors[index % swatchColors.size]); cornerRadius = 14 * resources.displayMetrics.density; setStroke(dp(1), if (index == 0) 0xFF9AA8B8.toInt() else Color.TRANSPARENT) }
                }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { rightMargin = dp(10) })
            }
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(4, 0, 8, 0) }
            labels.addView(TextView(this).apply { text = entry.first; textSize = 22f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD) })
            labels.addView(TextView(this).apply { text = entry.second; textSize = 19f; setTextColor(if (dark) 0xFFD5E1F1.toInt() else 0xFF52647D.toInt()); gravity = Gravity.END; setPadding(0, 3, 0, 0) })
            row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            val speaker = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF3285FF.toInt(), 0xFF0758D8.toInt())).apply { cornerRadius = 22 * resources.displayMetrics.density }
                elevation = 3f; isClickable = true; isFocusable = true
                setOnClickListener { speak(entry.first) }
            }
            speaker.addView(ImageView(this).apply { setImageResource(R.drawable.speaker_icon); scaleType = ImageView.ScaleType.FIT_CENTER; contentDescription = "استمع إلى ${entry.first}" }, LinearLayout.LayoutParams((62 * resources.displayMetrics.density).toInt(), (58 * resources.displayMetrics.density).toInt()))
            speaker.addView(TextView(this).apply { text = "استمع"; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
            row.addView(speaker, LinearLayout.LayoutParams((88 * resources.displayMetrics.density).toInt(), (88 * resources.displayMetrics.density).toInt()))
            rows.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = (10 * resources.displayMetrics.density).toInt() })
        }
        scroll.addView(rows)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showStats() {
        val dark = prefs.getBoolean("home_dark", false)
        val cardBg = if (dark) 0xFF172334.toInt() else Color.WHITE
        val panelBg = if (dark) 0xFF202B3C.toInt() else 0xFFF1F6FC.toInt()
        val ink = if (dark) Color.WHITE else 0xFF102A43.toInt()
        val muted = if (dark) 0xFFD5E1F1.toInt() else 0xFF64748B.toInt()
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        val nouns = words.count { wordCategory(it) == "الأسماء" }
        val verbs = words.count { wordCategory(it) == "الأفعال" }
        val adjectives = words.count { wordCategory(it) == "الصفات" }
        val knownCount = prefs.getStringSet("flashcards_known_v1", emptySet())?.size ?: 0
        val difficultCount = prefs.getStringSet("flashcards_difficult_v1", emptySet())?.size ?: 0

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(cardBg, 24)
        }
        container.addView(TextView(this).apply {
            text = "📊 الإحصائيات"
            textSize = 22f
            setTextColor(ink)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        })
        container.addView(TextView(this).apply {
            text = "ملخص تقدمك في تعلم البرتغالية"
            textSize = 14f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(14))
        })

        fun showRatedWords(title: String, initialKeys: Set<String>, preferenceKey: String) {
            val ratedKeys = initialKeys.toMutableSet()
            val dialogPanel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setBackgroundColor(cardBg)
            }
            val countLabel = TextView(this).apply {
                textSize = 14f; setTextColor(muted); gravity = Gravity.CENTER
                setPadding(0, dp(2), 0, dp(8))
            }
            val scroll = ScrollView(this)
            val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            scroll.addView(rows)
            dialogPanel.addView(countLabel)
            dialogPanel.addView(scroll, LinearLayout.LayoutParams(-1, dp(360)))
            lateinit var dialog: AlertDialog
            fun redraw() {
                rows.removeAllViews()
                val ratedWords = words.filter { notificationWordKey(it.pt, it.ar) in ratedKeys }
                countLabel.text = "${ratedWords.size} كلمة محفوظة"
                if (ratedWords.isEmpty()) {
                    rows.addView(TextView(this).apply {
                        text = "لا توجد كلمات في هذه القائمة بعد."
                        textSize = 16f; setTextColor(ink); gravity = Gravity.CENTER
                        setPadding(dp(12), dp(28), dp(12), dp(28))
                    })
                }
                ratedWords.forEach { word ->
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(dp(12), dp(8), dp(8), dp(8))
                        background = rounded(panelBg, 14)
                    }
                    val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
                    labels.addView(TextView(this).apply {
                        text = word.pt; textSize = 17f
                        setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(ink)
                    })
                    labels.addView(TextView(this).apply {
                        text = word.ar; textSize = 15f; setTextColor(muted)
                        setPadding(0, dp(3), 0, 0)
                    })
                    row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
                    val delete = TextView(this).apply {
                        text = "🗑️"; textSize = 19f; gravity = Gravity.CENTER
                        contentDescription = "حذف ${word.pt} من القائمة"
                        setPadding(dp(10), dp(8), dp(10), dp(8))
                        background = rounded(if (dark) 0xFF512B38.toInt() else 0xFFFFE4E8.toInt(), 10)
                        isClickable = true; isFocusable = true
                        setOnClickListener {
                            AlertDialog.Builder(this@MainActivity)
                                .setMessage("حذف «${word.pt}» من هذه القائمة؟")
                                .setNegativeButton("إلغاء", null)
                                .setPositiveButton("حذف") { _, _ ->
                                    ratedKeys.remove(notificationWordKey(word.pt, word.ar))
                                    prefs.edit().putStringSet(preferenceKey, ratedKeys.toSet()).apply()
                                    redraw()
                                }.show().apply {
                                    getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(if (dark) 0xFFFF7185.toInt() else 0xFFB4233A.toInt())
                                    getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(if (dark) Color.WHITE else 0xFF102A43.toInt())
                                }
                        }
                    }
                    row.addView(delete, LinearLayout.LayoutParams(dp(48), dp(44)))
                    rows.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
                }
            }
            redraw()
            val dialogTitle = TextView(this).apply {
                text = "$title (${ratedKeys.size})"
                textSize = 22f
                setTextColor(ink)
                setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(18), dp(20), dp(10))
                setBackgroundColor(cardBg)
            }
            dialog = AlertDialog.Builder(this).setCustomTitle(dialogTitle)
                .setView(dialogPanel).setPositiveButton("إغلاق", null).create()
            dialog.setOnShowListener {
                dialog.window?.setBackgroundDrawable(rounded(cardBg, 20))
                dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(if (dark) Color.WHITE else 0xFF087F70.toInt())
            }
            dialog.show()
        }

        fun statRow(icon: String, label: String, value: String, color: Int, onClick: (() -> Unit)? = null) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(11), dp(12), dp(11))
                background = rounded(panelBg, 16)
                if (onClick != null) {
                    isClickable = true
                    isFocusable = true
                    setOnClickListener { onClick() }
                }
            }
            val iconBox = TextView(this).apply {
                text = icon
                textSize = 22f
                gravity = Gravity.CENTER
                background = rounded(color, 12)
                setPadding(dp(7), dp(5), dp(7), dp(5))
            }
            row.addView(iconBox, LinearLayout.LayoutParams(dp(48), dp(46)))
            row.addView(TextView(this).apply {
                text = label
                textSize = 15f
                setTextColor(ink)
                setPadding(dp(10), 0, dp(4), 0)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply {
                text = value
                textSize = 20f
                setTextColor(ink)
                setTypeface(null, android.graphics.Typeface.BOLD)
            })
            container.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
        statRow("📚", "عدد الكلمات المحفوظة", words.size.toString(), 0xFF2876E8.toInt())
        statRow("📖", "الأسماء", nouns.toString(), 0xFF7C3AED.toInt())
        statRow("🏃", "الأفعال", verbs.toString(), 0xFFFF8A00.toInt())
        statRow("⭐", "الصفات", adjectives.toString(), 0xFFDB2777.toInt())
        statRow("✅", "كلمات أعرفها", knownCount.toString(), 0xFF159B68.toInt()) {
            showRatedWords("كلمات أعرفها", prefs.getStringSet("flashcards_known_v1", emptySet())?.toSet() ?: emptySet(), "flashcards_known_v1")
        }
        statRow("🔁", "كلمات صعبة", difficultCount.toString(), 0xFFDC4555.toInt()) {
            showRatedWords("كلمات صعبة", prefs.getStringSet("flashcards_difficult_v1", emptySet())?.toSet() ?: emptySet(), "flashcards_difficult_v1")
        }
        container.addView(TextView(this).apply {
            text = "🎯 تعلّم بلا حدود\nاستمر في التعلّم يوميًا!"
            textSize = 15f
            setTextColor(ink)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(10))
        })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        val dialog = AlertDialog.Builder(this).setView(container).create()
        fun makeAction(label: String, colors: IntArray, click: () -> Unit): TextView = TextView(this).apply {
            text = label; textSize = 15f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER; setPadding(dp(14), dp(13), dp(14), dp(13))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = dp(16).toFloat() }
            isClickable = true; isFocusable = true; setOnClickListener { click() }
        }
        actions.addView(makeAction("✓  حسنًا", intArrayOf(0xFF20A878.toInt(), 0xFF087F5B.toInt())) { dialog.dismiss() }, LinearLayout.LayoutParams(-1, -2))
        container.addView(actions)
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun showSettingsDialog() {
        val dark = prefs.getBoolean("home_dark", false)
        val cardBg = if (dark) 0xFF172334.toInt() else Color.WHITE
        val rowBg = if (dark) 0xFF202B3C.toInt() else 0xFFF1F6FC.toInt()
        val ink = if (dark) Color.WHITE else 0xFF102A43.toInt()
        val muted = if (dark) 0xFFD5E1F1.toInt() else 0xFF64748B.toInt()
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(14))
            background = rounded(cardBg, 24)
        }
        container.addView(TextView(this).apply {
            text = "⚙️ الإعدادات والمزيد"
            textSize = 21f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER
        })
        container.addView(TextView(this).apply {
            text = "خصص مظهر التطبيق والتذكيرات"
            textSize = 14f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, dp(5), 0, dp(14))
        })
        val dialog = AlertDialog.Builder(this).setView(container).create()
        data class SettingItem(val icon: String, val title: String, val subtitle: String, val color: Int, val action: () -> Unit)
        val options = listOf(
            SettingItem(if (dark) "☀️" else "🌙", "تبديل الوضع النهاري / الليلي", "تغيير ألوان التطبيق", 0xFF2876E8.toInt()) {
                prefs.edit().putBoolean("home_dark", !dark).apply(); dialog.dismiss(); buildUi()
            },
            SettingItem("⏱️", "تغيير مدة الإشعار", "${if (prefs.getInt("interval_minutes", 5) == -10) "كل 10 ثوانٍ" else "كل ${prefs.getInt("interval_minutes", 5)} دقيقة"}", 0xFF7C3AED.toInt()) {
                dialog.dismiss(); showReminderIntervalDialog()
            },
            SettingItem("🔔", "تشغيل التذكير", "تفعيل الإشعارات الدورية", 0xFF159B68.toInt()) {
                dialog.dismiss(); requestExactAlarmThenSchedule()
            },
            SettingItem("🔕", "إيقاف التذكير", "إيقاف الإشعارات الدورية", 0xFFDC4555.toInt()) {
                prefs.edit().putBoolean("reminders_enabled", false).apply(); ReminderScheduler.cancel(this); updateStatus("تم إيقاف التذكيرات"); dialog.dismiss(); toast("تم إيقاف التذكيرات")
            },
            SettingItem("📊", "تحكم في كلمات الإشعارات", "اختر الكلمات التي تريد سماعها", 0xFF0D9488.toInt()) {
                dialog.dismiss(); showNotificationWordsDialog()
            },
            SettingItem("📤", "تصدير الكلمات إلى Excel", "حفظ نسخة من كلماتك", 0xFFEA8A12.toInt()) {
                dialog.dismiss(); exportWords()
            }
        )
        options.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = rounded(rowBg, 16); isClickable = true; isFocusable = true
                setOnClickListener { item.action() }
            }
            row.addView(TextView(this).apply {
                text = item.icon; textSize = 22f; gravity = Gravity.CENTER
                background = rounded(item.color, 13); setPadding(dp(8), dp(7), dp(8), dp(7))
            }, LinearLayout.LayoutParams(dp(48), dp(48)))
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(11), 0, dp(4), 0) }
            labels.addView(TextView(this).apply { text = item.title; textSize = 15f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD) })
            labels.addView(TextView(this).apply { text = item.subtitle; textSize = 12f; setTextColor(muted); setPadding(0, dp(2), 0, 0) })
            row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply { text = "›"; textSize = 25f; setTextColor(muted); gravity = Gravity.CENTER })
            container.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        val close = TextView(this).apply {
            text = "✖  إغلاق"; textSize = 15f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER; setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFE94B5B.toInt(), 0xFFB91C35.toInt())).apply { cornerRadius = dp(16).toFloat() }
            isClickable = true; isFocusable = true; setOnClickListener { dialog.dismiss() }
        }
        container.addView(close, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun showReminderIntervalDialog() {
        val dark = prefs.getBoolean("home_dark", false)
        val cardBg = if (dark) 0xFF172334.toInt() else Color.WHITE
        val panelBg = if (dark) 0xFF202B3C.toInt() else 0xFFF1F6FC.toInt()
        val ink = if (dark) Color.WHITE else 0xFF102A43.toInt()
        val muted = if (dark) 0xFFD5E1F1.toInt() else 0xFF64748B.toInt()
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()
        val intervals = intArrayOf(-10, 1, 2, 5, 10, 15, 30, 45, 60)
        val labels = intervals.map { if (it == -10) "كل 10 ثوانٍ" else if (it == 1) "كل دقيقة" else "كل $it دقيقة" }
        val current = prefs.getInt("interval_minutes", 5)
        var selectedMinutes = if (current == -10) -10 else intervals.filter { it > 0 }.minByOrNull { kotlin.math.abs(it - current.coerceIn(1, 60)) } ?: 5

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(14)); background = rounded(cardBg, 24)
        }
        container.addView(TextView(this).apply {
            text = "⏱️ مدة التذكير"; textSize = 21f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER
        })
        container.addView(TextView(this).apply {
            text = "اختر المدة بين كل إشعار وآخر"; textSize = 14f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, dp(5), 0, dp(12))
        })
        val listPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(5), dp(8), dp(5)); background = rounded(panelBg, 18) }
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val radioIds = mutableMapOf<Int, Int>()
        intervals.forEachIndexed { index, minutes ->
            val radio = RadioButton(this).apply {
                id = View.generateViewId(); text = "${if (minutes == 1) "⏱️" else "🔔"}  ${labels[index]}"; textSize = 16f
                setTextColor(ink); buttonTintList = android.content.res.ColorStateList.valueOf(if (dark) 0xFF55B7FF.toInt() else 0xFF168BFF.toInt())
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            radioIds[minutes] = radio.id
            group.addView(radio)
        }
        group.check(radioIds[selectedMinutes] ?: radioIds[5]!!)
        group.setOnCheckedChangeListener { _, checkedId ->
            selectedMinutes = radioIds.entries.firstOrNull { it.value == checkedId }?.key ?: selectedMinutes
        }
        listPanel.addView(group)
        container.addView(listPanel)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) }
        val dialog = AlertDialog.Builder(this).setView(container).create()
        fun action(label: String, colors: IntArray, click: () -> Unit) = TextView(this).apply {
            text = label; textSize = 14f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER; setPadding(dp(10), dp(13), dp(10), dp(13))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = dp(16).toFloat() }
            isClickable = true; isFocusable = true; setOnClickListener { click() }
        }
        actions.addView(action("✖  إلغاء", intArrayOf(0xFFE94B5B.toInt(), 0xFFB91C35.toInt())) { dialog.dismiss() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(5) })
        actions.addView(action("✓  حفظ المدة", intArrayOf(0xFF168BFF.toInt(), 0xFF0758D8.toInt())) {
            prefs.edit().putInt("interval_minutes", selectedMinutes).apply()
            if (prefs.getBoolean("reminders_enabled", false)) {
                ReminderScheduler.cancel(this); ReminderScheduler.scheduleNext(this)
            }
            updateStatus("تم ضبط التذكير ${if (selectedMinutes == -10) "كل 10 ثوانٍ" else if (selectedMinutes == 1) "كل دقيقة" else "كل $selectedMinutes دقيقة"}")
            dialog.dismiss()
            toast("مدة التذكير: ${if (selectedMinutes == -10) "10 ثوانٍ" else if (selectedMinutes == 1) "دقيقة واحدة" else "$selectedMinutes دقيقة"}")
            if (showingMyWords) showMyWords() else buildUi()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(5) })
        container.addView(actions)
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun showMyWords() {
        showingMyWords = true
        showingConjugations = false
        showingTimeVocabulary = false
        showingTimeWordList = false
        val dark = prefs.getBoolean("home_dark", false)
        val pageBg = if (dark) 0xFF101827.toInt() else 0xFFF4F7FC.toInt()
        val cardBg = if (dark) 0xFF202B3C.toInt() else Color.WHITE
        val ink = if (dark) Color.WHITE else 0xFF102A43.toInt()
        val mutedInk = if (dark) 0xFFD8E2F0.toInt() else 0xFF64748B.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 8)
            setBackgroundColor(pageBg)
            setOnApplyWindowInsetsListener { view, insets ->
                val top: Int
                val bottom: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    top = bars.top; bottom = bars.bottom
                } else {
                    @Suppress("DEPRECATION")
                    run { top = insets.systemWindowInsetTop; bottom = insets.systemWindowInsetBottom }
                }
                view.setPadding((16 * resources.displayMetrics.density).toInt(), top + (8 * resources.displayMetrics.density).toInt(), (16 * resources.displayMetrics.density).toInt(), bottom + (8 * resources.displayMetrics.density).toInt())
                insets
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(16, 16, 16, 16)
            background = rounded(0xFF1769E8.toInt(), 24)
        }
        header.addView(TextView(this).apply { text = "🇵🇹 كلمات البرتغالية"; textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD) })
        header.addView(TextView(this).apply { text = "قائمة كلماتك المحفوظة"; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 4, 0, 0) })
        root.addView(header, marginParams())

        val summary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12); background = rounded(cardBg, 18) }
        val count = TextView(this).apply { text = "📘 ${words.size} كلمة محفوظة"; textSize = 20f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD) }
        summary.addView(count)
        val search = EditText(this).apply {
            hint = "🔎 ابحث عن كلمة أو ترجمة..."; textSize = 16f; isSingleLine = true; setPadding(14, 10, 14, 10)
            background = rounded(if (dark) 0xFF344256.toInt() else 0xFFF0F4FA.toInt(), 16)
            setTextColor(ink); setHintTextColor(mutedInk)
        }
        val searchParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 10 }
        summary.addView(search, searchParams)
        root.addView(summary, marginParams())

        val notificationControl = makeTile("🔔 تحكم في كلمات الإشعارات", 0xFF7C3AED.toInt()) { showNotificationWordsDialog() }
        root.addView(notificationControl, marginParams())
        val savedNotificationMode = prefs.getString("notification_word_mode", "all") ?: "all"
        val notificationMode = if (savedNotificationMode == "unknown") "difficult" else savedNotificationMode
        val notificationModeText = when (notificationMode) {
            "known" -> "الإشعارات: الكلمات التي أعرفها"
            "difficult" -> "الإشعارات: الكلمات الصعبة فقط"
            "selected" -> "الإشعارات: الكلمات التي اخترتها"
            else -> "الإشعارات: كل الكلمات"
        }
        root.addView(TextView(this).apply { text = notificationModeText; textSize = 13f; gravity = Gravity.CENTER; setTextColor(mutedInk); setPadding(4, 0, 4, 6) })

        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val filters = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 2, 0, 2) }
        val categories = listOf("الكل", "الأسماء", "الأفعال", "الصفات")
        var activeCategory = "الكل"
        val categoryButtons = mutableMapOf<String, Button>()
        categories.forEach { category ->
            val b = Button(this).apply {
                text = category; textSize = 12f; isAllCaps = false; setPadding(2, 2, 2, 2)
                setTextColor(if (category == activeCategory) Color.WHITE else mutedInk)
                background = rounded(if (category == activeCategory) 0xFF1769E8.toInt() else cardBg, 14)
            }
            b.setOnClickListener {
                activeCategory = category
                categoryButtons.forEach { (name, button) ->
                    button.setTextColor(if (name == activeCategory) Color.WHITE else mutedInk)
                    button.background = rounded(if (name == activeCategory) 0xFF1769E8.toInt() else cardBg, 14)
                }
                renderMyWordRows(search.text.toString(), activeCategory, rows, count)
            }
            categoryButtons[category] = b
            filters.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 2, 2, 2) })
        }
        root.addView(filters, marginParams())
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(rows) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 5, 0, 0) }
        bottom.addView(makeTile("الرئيسية", 0xFF64748B.toInt()) { showingMyWords = false; buildUi() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(makeTile("إضافة", 0xFF168B55.toInt()) { editWord(null); renderMyWordRows(search.text.toString(), activeCategory, rows, count) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(makeTile("🃏 البطاقات", 0xFF7C3AED.toInt()) { startFlashcards() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(makeTile("🎯 الاختبار", 0xFFDB2777.toInt()) { startQuiz() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(bottom)
        setContentView(root)
        renderMyWordRows("", activeCategory, rows, count)
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, countChanged: Int) { renderMyWordRows(s?.toString().orEmpty(), activeCategory, rows, count) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun guessWordCategory(portuguese: String): String {
        val w = portuguese.trim().lowercase(Locale.ROOT)
        if (w.isBlank()) return "الأسماء"

        // A Portuguese article is a strong signal that this is a noun/noun phrase.
        // Keep this check first so phrases such as "o correio eletrónico" are not
        // classified as adjectives because the last word ends in -ico.
        if (Regex("^(a|o|as|os)\\s+.+").containsMatchIn(w)) return "الأسماء"

        val normalized = w.removeSuffix("-se")
        val verbs = setOf(
            "ser", "estar", "ter", "fazer", "ir", "vir", "ver", "dizer", "poder", "querer", "saber", "dar", "ficar",
            "trabalhar", "comer", "beber", "falar", "morar", "estudar", "aprender", "soletrar", "chamar-se", "chamar",
            "gostar", "precisar", "abrir", "fechar", "ler", "escrever", "ouvir", "andar", "comprar", "vender", "viver",
            "sentir", "dormir", "sair", "entrar", "conhecer", "compreender", "pôr", "preferir", "adorar", "detestar",
            "desculpar", "ajudar", "trabalhar", "procurar", "encontrar", "perguntar", "responder", "esperar", "chegar",
            "levar", "deixar", "tomar", "usar", "viajar", "pagar", "começar", "acabar", "continuar", "explicar", "ensinar",
            "estudar", "necessitar", "receber", "vender", "perder", "aprender", "escolher", "esquecer", "prometer", "cometer",
            "decidir", "partir", "assistir", "existir", "permitir", "conseguir", "seguir", "subir", "cair", "correr", "esquiar",
            "cozinhar", "limpar", "lavar", "molhar", "passear", "brincar", "jogar", "dançar", "cantar", "telefonar", "enviar",
            "mostrar", "mostrar-se", "lembrar", "lembrar-se", "sentar", "sentar-se", "levantar", "levantar-se", "vestir", "vestir-se",
            "acordar", "deitar", "deitar-se", "dizer", "trazer", "manter", "construir", "destruir", "preferir", "repetir",
            "traduzir", "produzir", "conduzir", "reduzir", "sorrir", "rir", "fugir", "decidir", "dividir", "permitir", "existir"
        )
        val adjectives = setOf(
            "bom", "boa", "bons", "boas", "mau", "má", "maus", "más", "grande", "grandes", "pequeno", "pequena", "pequenos", "pequenas",
            "simpático", "simpática", "simpáticos", "simpáticas", "bonito", "bonita", "bonitos", "bonitas", "feio", "feia", "feios", "feias",
            "feliz", "triste", "fácil", "difícil", "novo", "nova", "velho", "velha", "alto", "alta", "baixo", "baixa", "caro", "cara",
            "barato", "barata", "quente", "frio", "fria", "rápido", "rápida", "lento", "lenta", "importante", "interessante", "diferente",
            "amável", "agradável", "responsável", "possível", "impossível", "inteligente", "forte", "fraco", "fraca", "melhor", "pior",
            "muito", "muita", "muitos", "muitas", "eletrónico", "eletrónica", "eletrónicos", "eletrónicas",
            "popular", "populares", "familiar", "familiares", "regular", "regulares", "irregular", "irregulares",
            "particular", "particulares", "singular", "singulares", "similar", "similares", "escolar", "escolares",
            "solar", "solares", "circular", "circulares", "vulgar", "vulgares", "celular", "celulares",
            "exemplar", "exemplares", "nuclear", "nucleares", "muscular", "musculares", "auxiliar", "auxiliares",
            "militar", "militares", "maior", "menor", "melhor", "pior"
        )
        // Some common words ending in an infinitive-looking suffix are nouns or ambiguous.
        // These exceptions avoid treating "mulher" as a verb just because it ends in -er.
        val nounExceptions = setOf("mulher", "mulheres", "prazer", "lazer", "colher", "colheres", "mar", "lugar", "lugares", "açúcar", "jantar")

        if (normalized in verbs || w in verbs) return "الأفعال"
        if (w in adjectives || w.endsWith("oso") || w.endsWith("osa") || w.endsWith("osos") || w.endsWith("osas") ||
            w.endsWith("ico") || w.endsWith("ica") || w.endsWith("icos") || w.endsWith("icas") ||
            w.endsWith("ável") || w.endsWith("áveis") || w.endsWith("ível") || w.endsWith("íveis") ||
            w.endsWith("ente") || w.endsWith("entes")) return "الصفات"

        // Most bare Portuguese infinitives end in -ar, -er or -ir. Use this as a
        // fallback for new verbs, but not for common noun exceptions above.
        if (normalized !in nounExceptions && (normalized.endsWith("ar") || normalized.endsWith("er") || normalized.endsWith("ir"))) {
            return "الأفعال"
        }
        return "الأسماء"
    }

    private fun wordCategory(word: Word): String {
        // If the user explicitly selected a type in the editor (or in an import file),
        // respect that choice. Older records have no categoryManual flag and are
        // reclassified with the improved rules below.
        if (word.categoryManual && word.category in setOf("الأسماء", "الأفعال", "الصفات")) return word.category
        return guessWordCategory(word.pt)
    }

    private fun showNotificationWordsDialog() {
        val dark = prefs.getBoolean("home_dark", false)
        val cardBg = if (dark) 0xFF172334.toInt() else Color.WHITE
        val panelBg = if (dark) 0xFF202B3C.toInt() else 0xFFF8FAFC.toInt()
        val ink = if (dark) Color.WHITE else 0xFF102A43.toInt()
        val muted = if (dark) 0xFFD8E2F0.toInt() else 0xFF64748B.toInt()
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(cardBg, 22)
        }
        container.addView(TextView(this).apply {
            text = "🔔 تحكم في كلمات الإشعارات"
            textSize = 20f
            setTextColor(ink)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        })
        container.addView(TextView(this).apply {
            text = "اختر نوع الكلمات التي تريد ظهورها، وحدد كلمات بعينها عند اختيار الوضع المخصص. ستتكرر حسب مدة التذكير التي ضبطتها."
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(8), 0, dp(10))
        })

        val storedMode = prefs.getString("notification_word_mode", "all") ?: "all"
        val currentMode = if (storedMode == "unknown") "difficult" else storedMode
        val modeGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val modes = listOf(
            "known" to "✅ الكلمات التي أعرفها",
            "difficult" to "🔴 الكلمات الصعبة فقط",
            "all" to "📚 كل الكلمات",
            "selected" to "🎯 الكلمات التي أحددها بنفسي"
        )
        var selectedModeButtonId = View.NO_ID
        modes.forEach { (value, label) ->
            val radio = RadioButton(this).apply {
                id = View.generateViewId()
                text = label
                tag = value
                textSize = 14f
                setTextColor(ink)
                buttonTintList = android.content.res.ColorStateList.valueOf(0xFF2680FF.toInt())
                setPadding(dp(2), dp(3), dp(2), dp(3))
            }
            modeGroup.addView(radio)
            if (value == currentMode) selectedModeButtonId = radio.id
        }
        if (selectedModeButtonId != View.NO_ID) modeGroup.check(selectedModeButtonId)
        container.addView(modeGroup)

        val customListTitle = TextView(this).apply {
            text = "قائمة الكلمات — ضع علامة على الكلمات التي تريد إدراجها في الوضع المخصص:"
            textSize = 14f
            setTextColor(ink)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(5))
        }
        container.addView(customListTitle)

        val selectedKeys = prefs.getStringSet("notification_selected_word_keys", emptySet())!!.toMutableSet()
        val knownKeys = prefs.getStringSet("flashcards_known_v1", emptySet())!!.toSet()
        val difficultKeys = prefs.getStringSet("flashcards_difficult_v1", emptySet())!!.toSet()
        val wordList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(2))
            background = rounded(panelBg, 16)
        }
        words.forEach { word ->
            val key = notificationWordKey(word.pt, word.ar)
            val stateLabel = when { key in knownKeys -> " • أعرفها"; key in difficultKeys -> " • صعبة"; else -> " • لم أقيّمها" }
            val check = CheckBox(this).apply {
                text = "${word.pt} — ${word.ar}$stateLabel"
                textSize = 14f
                setTextColor(ink)
                isChecked = key in selectedKeys
                buttonTintList = android.content.res.ColorStateList.valueOf(0xFF2680FF.toInt())
                setPadding(dp(4), dp(5), dp(4), dp(5))
            }
            check.setOnCheckedChangeListener { _, checked -> if (checked) selectedKeys.add(key) else selectedKeys.remove(key) }
            wordList.addView(check)
        }
        if (words.isEmpty()) wordList.addView(TextView(this).apply {
            text = "لا توجد كلمات محفوظة بعد."
            setTextColor(muted)
            setPadding(dp(8), dp(10), dp(8), dp(10))
        })
        val wordScroll = ScrollView(this).apply {
            addView(wordList)
            isFillViewport = false
            background = rounded(panelBg, 16)
        }
        container.addView(wordScroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(230)
        ))

        fun updateCustomListEnabled() {
            val customModeActive = modeGroup.findViewById<RadioButton>(modeGroup.checkedRadioButtonId)?.tag == "selected"
            customListTitle.alpha = if (customModeActive) 1f else 0.62f
            wordList.alpha = if (customModeActive) 1f else 0.62f
            for (i in 0 until wordList.childCount) wordList.getChildAt(i).isEnabled = customModeActive
            wordScroll.isEnabled = customModeActive
            wordScroll.descendantFocusability = if (customModeActive) ViewGroup.FOCUS_AFTER_DESCENDANTS else ViewGroup.FOCUS_BLOCK_DESCENDANTS
        }
        modeGroup.setOnCheckedChangeListener { _, _ -> updateCustomListEnabled() }
        updateCustomListEnabled()

        // Custom action buttons live inside the themed panel so the system's default
        // white AlertDialog button footer cannot break dark mode.
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }
        fun actionButton(icon: String, label: String, colors: IntArray, onClick: () -> Unit): LinearLayout {
            val button = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(8), dp(12), dp(8), dp(12))
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
                    cornerRadius = dp(18).toFloat()
                    setStroke(dp(1), if (dark) 0x553F5A6B else 0x22000000)
                }
                isClickable = true
                isFocusable = true
                contentDescription = label
            }
            button.addView(TextView(this).apply {
                text = icon
                textSize = 20f
                gravity = Gravity.CENTER
                setPadding(0, 0, dp(7), 0)
            })
            button.addView(TextView(this).apply {
                text = label
                textSize = 14f
                setTextColor(Color.WHITE)
                setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
            })
            button.setOnClickListener { onClick() }
            return button
        }
        val cancelButton = actionButton("✖", "إلغاء", intArrayOf(0xFFE94B5B.toInt(), 0xFFB91C35.toInt())) { }
        val saveButton = actionButton("💾", "حفظ الاختيارات", intArrayOf(0xFF168BFF.toInt(), 0xFF0758D8.toInt())) {
            // Click action is assigned after dialog creation below.
        }
        actions.addView(cancelButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { rightMargin = dp(5) })
        actions.addView(saveButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(5) })
        container.addView(actions)

        val dialog = AlertDialog.Builder(this).setView(container).create()
        cancelButton.setOnClickListener { dialog.dismiss() }
        saveButton.setOnClickListener {
            val checked = modeGroup.checkedRadioButtonId
            val selectedMode = modeGroup.findViewById<RadioButton>(checked)?.tag as? String ?: "all"
            if (selectedMode == "selected" && selectedKeys.isEmpty()) {
                toast("حدد كلمة واحدة على الأقل للوضع المخصص")
                return@setOnClickListener
            }
            prefs.edit()
                .putString("notification_word_mode", if (selectedMode == "unknown") "difficult" else selectedMode)
                .putStringSet("notification_selected_word_keys", selectedKeys.toSet())
                .putInt("next_index", 0)
                .apply()
            if (prefs.getBoolean("reminders_enabled", false)) {
                ReminderScheduler.cancel(this)
                ReminderScheduler.scheduleNext(this)
            }
            dialog.dismiss()
            toast("تم حفظ إعدادات كلمات الإشعارات")
            showMyWords()
        }
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window?.setLayout(
                (resources.displayMetrics.widthPixels * 0.94f).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94f).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun renderMyWordRows(query: String, category: String, rows: LinearLayout, count: TextView) {
        val dark = prefs.getBoolean("home_dark", false)
        val cardBg = if (dark) 0xFF202B3C.toInt() else Color.WHITE
        val ink = if (dark) Color.WHITE else 0xFF102A43.toInt()
        val muted = if (dark) 0xFFD8E2F0.toInt() else 0xFF52677F.toInt()
        val insetBg = if (dark) 0xFF344256.toInt() else 0xFFF1F5F9.toInt()
        rows.setBackgroundColor(if (dark) 0xFF101827.toInt() else 0xFFF4F7FC.toInt())
        rows.removeAllViews()
        val filtered = words.withIndex().filter { (_, word) ->
            val matchesText = query.isBlank() || word.pt.contains(query, true) || word.ar.contains(query, true) || word.examplePt.contains(query, true) || word.exampleAr.contains(query, true)
            val matchesCategory = category == "الكل" || wordCategory(word) == category
            matchesText && matchesCategory
        }
        count.text = "📘 ${words.size} كلمة محفوظة • النتائج: ${filtered.size}"
        if (filtered.isEmpty()) {
            rows.addView(TextView(this).apply { text = "لا توجد كلمات مطابقة. جرّب بحثًا آخر أو أضف كلمة جديدة."; textSize = 16f; setTextColor(if (dark) 0xFFD8E2F0.toInt() else 0xFF64748B.toInt()); setPadding(16, 24, 16, 24); background = rounded(cardBg, 18) }, marginParams())
            return
        }
        filtered.forEach { indexed ->
            val i = indexed.index; val w = indexed.value
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 12); background = rounded(cardBg, 18) }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val wordsText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            wordsText.addView(TextView(this).apply { text = w.pt; textSize = 22f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD) })
            wordsText.addView(TextView(this).apply { text = w.ar; textSize = 18f; setTextColor(muted); setPadding(0, 3, 0, 0) })
            top.addView(wordsText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val categoryColor = when (wordCategory(w)) { "الأفعال" -> 0xFFFFE7A3.toInt(); "الصفات" -> 0xFFFCE0F0.toInt(); else -> 0xFFD8F8E5.toInt() }
            top.addView(TextView(this).apply { text = when (wordCategory(w)) { "الأفعال" -> "🏃 فعل"; "الصفات" -> "★ صفة"; else -> "⌂ اسم" }; textSize = 12f; setTextColor(0xFF334155.toInt()); setPadding(9, 7, 9, 7); background = rounded(categoryColor, 18) })
            card.addView(top)
            if (w.examplePt.isNotBlank()) card.addView(TextView(this).apply { text = "${w.examplePt}\n${w.exampleAr}"; textSize = 14f; setTextColor(muted); setPadding(10, 8, 10, 8); background = rounded(insetBg, 12) }, marginParams())
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            actions.addView(makeTile("نطق", 0xFF1769E8.toInt()) { speak(w.pt) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 5, 3, 0) })
            actions.addView(makeTile("✎ تعديل", 0xFF64748B.toInt()) { editWord(i); rows.post { renderMyWordRows(query, category, rows, count) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 5, 3, 0) })
            actions.addView(makeTile("▤ حذف", 0xFFDC2626.toInt()) { confirmDelete(i); rows.post { renderMyWordRows(query, category, rows, count) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 5, 0, 0) })
            card.addView(actions)
            rows.addView(card, marginParams())
        }
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with this Activity")
    override fun onBackPressed() {
        when {
            learningGameShowing -> returnToLearningHub()
            learningHubShowing -> closeLearningHub()
            showingTimeWordList -> showTimeVocabulary()
            showingTimeVocabulary -> buildUi()
            showingMyWords || showingConjugations -> buildUi()
            else -> super.onBackPressed()
        }
    }

    private fun showConjugations() {
        val dark = prefs.getBoolean("home_dark", false)
        val pageBg = if (dark) 0xFF101827.toInt() else 0xFFF4F7FC.toInt()
        val cardBg = if (dark) 0xFF202B3C.toInt() else Color.WHITE
        val tableBg = if (dark) 0xFF263449.toInt() else 0xFFEAF1FA.toInt()
        val ink = if (dark) Color.WHITE else 0xFF102A43.toInt()
        val muted = if (dark) 0xFFD8E2F0.toInt() else 0xFF52677F.toInt()
        showingConjugations = true
        showingMyWords = false
        showingTimeVocabulary = false
        showingTimeWordList = false
        val verbs = words.filter { wordCategory(it) == "الأفعال" }
            .distinctBy { it.pt.lowercase(Locale.ROOT) }
            .sortedBy { it.pt.lowercase(Locale.ROOT) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 8)
            setBackgroundColor(pageBg)
            setOnApplyWindowInsetsListener { view, insets ->
                val top: Int
                val bottom: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    top = bars.top; bottom = bars.bottom
                } else {
                    @Suppress("DEPRECATION")
                    run { top = insets.systemWindowInsetTop; bottom = insets.systemWindowInsetBottom }
                }
                view.setPadding((14 * resources.displayMetrics.density).toInt(), top + (8 * resources.displayMetrics.density).toInt(), (14 * resources.displayMetrics.density).toInt(), bottom + (8 * resources.displayMetrics.density).toInt())
                insets
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 14, 12, 14)
            background = rounded(0xFF1769E8.toInt(), 20)
        }
        header.addView(makeTile("← رجوع", 0xFF0D47A1.toInt()) {
            showingConjugations = false
            buildUi()
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(TextView(this).apply {
            text = "تصريف الأفعال"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "🇵🇹"
            textSize = 25f
            gravity = Gravity.CENTER
        })
        root.addView(header, marginParams())

        val search = EditText(this).apply {
            hint = "🔎 ابحث عن فعل..."
            textSize = 16f
            isSingleLine = true
            setPadding(12, 8, 12, 8)
            background = rounded(if (dark) 0xFF344256.toInt() else Color.WHITE, 16)
            setTextColor(ink); setHintTextColor(muted)
        }
        root.addView(search, marginParams())

        val verbScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val verbButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        verbScroll.addView(verbButtons)
        root.addView(verbScroll, marginParams())

        val tenseRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val detailScroll = ScrollView(this).apply { isFillViewport = true }
        val detail = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 4, 4, 12) }
        detailScroll.addView(detail)
        tenseRow.visibility = View.GONE
        root.addView(tenseRow, marginParams())
        root.addView(detailScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(makeTile("＋ إضافة فعل جديد", 0xFF168B55.toInt()) {
            editWord(null)
        }, marginParams())

        root.addView(makeTile("⌂ الرئيسية", 0xFF64748B.toInt()) {
            showingConjugations = false
            buildUi()
        }, marginParams())

        setContentView(root)

        var selectedVerb = verbs.firstOrNull()
        var selectedTense = "المضارع"
        val tenseColors = mapOf("المضارع" to 0xFF059669.toInt(), "الماضي" to 0xFFF59E0B.toInt(), "المستقبل" to 0xFF7C3AED.toInt())

        fun renderDetail() {
            detail.removeAllViews()
            val verb = selectedVerb
            if (verb == null) {
                detail.addView(TextView(this).apply {
                    text = "لم تضف أفعالًا بعد.\nأضف فعلًا مثل ser أو trabalhar، وسيظهر هنا تلقائيًا."
                    textSize = 17f; setTextColor(0xFF475569.toInt()); gravity = Gravity.CENTER; setPadding(20, 30, 20, 30)
                    background = rounded(cardBg, 18); setTextColor(muted)
                }, marginParams())
                return
            }
            val titleCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 14); background = rounded(cardBg, 18) }
            val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            titleRow.addView(TextView(this).apply { text = verb.pt; textSize = 28f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            titleRow.addView(makeTile("🔊", 0xFF1769E8.toInt()) { speak(verb.pt) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            titleCard.addView(titleRow)
            titleCard.addView(TextView(this).apply { text = verb.ar; textSize = 19f; setTextColor(muted); setPadding(0, 3, 0, 0) })
            detail.addView(titleCard, marginParams())

            val pronouns = listOf("eu", "tu", "ele / ela", "nós", "vocês", "eles / elas")
            val arabicPronouns = listOf("أنا", "أنتَ / أنتِ", "هو / هي", "نحن", "أنتم", "هم / هن")
            listOf("المضارع", "الماضي", "المستقبل").forEach { tense ->
                val section = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(9, 8, 9, 9)
                    background = rounded(cardBg, 16)
                }
                section.addView(TextView(this).apply {
                    text = when (tense) {
                        "الماضي" -> "🕘 الماضي — Pretérito perfeito"
                        "المستقبل" -> "📅 المستقبل — Futuro simples"
                        else -> "☀️ المضارع — Presente"
                    }
                    textSize = 17f
                    setTextColor(tenseColors[tense] ?: 0xFF1769E8.toInt())
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setPadding(5, 6, 5, 8)
                })
                val forms = conjugationForms(verb.pt, tense)
                val table = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(tableBg, 12); setPadding(5, 4, 5, 4) }
                pronouns.forEachIndexed { index, pronoun ->
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(5, 4, 5, 4)
                        if (index % 2 == 0) background = rounded(cardBg, 9)
                    }
                    row.addView(TextView(this).apply {
                        text = pronoun
                        textSize = 12f
                        setTextColor(muted)
                    }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.85f))
                    row.addView(makeTile("🔊", 0xFF1769E8.toInt()) {
                        val form = forms.getOrElse(index) { "" }
                        if (form.isNotBlank() && form != "—") speak(form)
                    }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(2, 0, 5, 0) })
                    row.addView(TextView(this).apply {
                        text = forms.getOrElse(index) { "—" }
                        textSize = 15f
                        setTextColor(ink)
                        setTypeface(null, android.graphics.Typeface.BOLD)
                        gravity = Gravity.CENTER
                    }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.15f))
                    row.addView(TextView(this).apply {
                        text = arabicPronouns[index]
                        textSize = 12f
                        setTextColor(muted)
                        gravity = Gravity.END
                    }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    table.addView(row)
                }
                section.addView(table)
                detail.addView(section, marginParams())
            }
            detail.addView(makeTile("🔊 سماع الفعل", 0xFF1769E8.toInt()) { speak(verb.pt) }, marginParams())
            detail.addView(TextView(this).apply {
                text = "اضغط على زر 🔊 بجانب أي تصريف لسماع نطقه بالبرتغالية الأوروبية.\nملاحظة: الأفعال غير المنتظمة الشائعة لها تصريفات خاصة؛ الأفعال الأخرى تُصرّف وفق القاعدة العامة."
                textSize = 12f; setTextColor(0xFF64748B.toInt()); setPadding(4, 8, 4, 8)
            })
        }

        fun renderTenses() {
            tenseRow.removeAllViews()
            listOf("المضارع", "الماضي", "المستقبل").forEach { tense ->
                val button = makeTile(
                    when (tense) { "الماضي" -> "🕘 الماضي"; "المستقبل" -> "📅 المستقبل"; else -> "☀️ المضارع" },
                    if (selectedTense == tense) tenseColors[tense]!! else 0xFFE2E8F0.toInt()
                ) { selectedTense = tense; renderTenses(); renderDetail() }
                if (selectedTense != tense) button.setTextColor(0xFF334155.toInt())
                tenseRow.addView(button, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 2, 2, 2) })
            }
        }

        fun renderVerbButtons(query: String = "") {
            verbButtons.removeAllViews()
            val matching = verbs.filter { it.pt.contains(query, true) || it.ar.contains(query, true) }
            if (matching.isEmpty()) {
                verbButtons.addView(TextView(this).apply { text = "لا توجد أفعال مطابقة"; textSize = 14f; setTextColor(0xFF64748B.toInt()); setPadding(10, 12, 10, 12) })
            }
            matching.forEach { verb ->
                val button = makeTile(verb.pt, if (selectedVerb?.pt == verb.pt) 0xFF1769E8.toInt() else cardBg) {
                    selectedVerb = verb
                    renderVerbButtons(search.text.toString())
                    renderDetail()
                }
                if (selectedVerb?.pt != verb.pt) button.setTextColor(ink)
                verbButtons.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(3, 2, 3, 2) })
            }
        }

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderVerbButtons(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        renderVerbButtons()
        renderDetail()
    }

    private fun conjugationForms(rawVerb: String, tense: String): List<String> {
        val verb = rawVerb.trim().lowercase(Locale.ROOT).removeSuffix("-se")
        val irregular = mapOf(
            "ser" to mapOf(
                "المضارع" to listOf("sou", "és", "é", "somos", "são", "são"),
                "الماضي" to listOf("fui", "foste", "foi", "fomos", "foram", "foram"),
                "المستقبل" to listOf("serei", "serás", "será", "seremos", "serão", "serão")
            ),
            "estar" to mapOf(
                "المضارع" to listOf("estou", "estás", "está", "estamos", "estão", "estão"),
                "الماضي" to listOf("estive", "estiveste", "esteve", "estivemos", "estiveram", "estiveram"),
                "المستقبل" to listOf("estarei", "estarás", "estará", "estaremos", "estarão", "estarão")
            ),
            "ter" to mapOf(
                "المضارع" to listOf("tenho", "tens", "tem", "temos", "têm", "têm"),
                "الماضي" to listOf("tive", "tiveste", "teve", "tivemos", "tiveram", "tiveram"),
                "المستقبل" to listOf("terei", "terás", "terá", "teremos", "terão", "terão")
            ),
            "ir" to mapOf(
                "المضارع" to listOf("vou", "vais", "vai", "vamos", "vão", "vão"),
                "الماضي" to listOf("fui", "foste", "foi", "fomos", "foram", "foram"),
                "المستقبل" to listOf("irei", "irás", "irá", "iremos", "irão", "irão")
            ),
            "fazer" to mapOf(
                "المضارع" to listOf("faço", "fazes", "faz", "fazemos", "fazem", "fazem"),
                "الماضي" to listOf("fiz", "fizeste", "fez", "fizemos", "fizeram", "fizeram"),
                "المستقبل" to listOf("farei", "farás", "fará", "faremos", "farão", "farão")
            ),
            "poder" to mapOf(
                "المضارع" to listOf("posso", "podes", "pode", "podemos", "podem", "podem"),
                "الماضي" to listOf("pude", "pudeste", "pôde", "pudemos", "puderam", "puderam"),
                "المستقبل" to listOf("poderei", "poderás", "poderá", "poderemos", "poderão", "poderão")
            ),
            "querer" to mapOf(
                "المضارع" to listOf("quero", "queres", "quer", "queremos", "querem", "querem"),
                "الماضي" to listOf("quis", "quiseste", "quis", "quisemos", "quiseram", "quiseram"),
                "المستقبل" to listOf("quererei", "quererás", "quererá", "quereremos", "quererão", "quererão")
            ),
            "dizer" to mapOf(
                "المضارع" to listOf("digo", "dizes", "diz", "dizemos", "dizem", "dizem"),
                "الماضي" to listOf("disse", "disseste", "disse", "dissemos", "disseram", "disseram"),
                "المستقبل" to listOf("direi", "dirás", "dirá", "diremos", "dirão", "dirão")
            ),
            "vir" to mapOf(
                "المضارع" to listOf("venho", "vens", "vem", "vimos", "vêm", "vêm"),
                "الماضي" to listOf("vim", "vieste", "veio", "viemos", "vieram", "vieram"),
                "المستقبل" to listOf("virei", "virás", "virá", "viremos", "virão", "virão")
            ),
            "ver" to mapOf(
                "المضارع" to listOf("vejo", "vês", "vê", "vemos", "veem", "veem"),
                "الماضي" to listOf("vi", "viste", "viu", "vimos", "viram", "viram"),
                "المستقبل" to listOf("verei", "verás", "verá", "veremos", "verão", "verão")
            ),
            "saber" to mapOf(
                "المضارع" to listOf("sei", "sabes", "sabe", "sabemos", "sabem", "sabem"),
                "الماضي" to listOf("soube", "soubeste", "soube", "soubemos", "souberam", "souberam"),
                "المستقبل" to listOf("saberei", "saberás", "saberá", "saberemos", "saberão", "saberão")
            ),
            "dar" to mapOf(
                "المضارع" to listOf("dou", "dás", "dá", "damos", "dão", "dão"),
                "الماضي" to listOf("dei", "deste", "deu", "demos", "deram", "deram"),
                "المستقبل" to listOf("darei", "darás", "dará", "daremos", "darão", "darão")
            )
        )
        irregular[verb]?.get(tense)?.let { return it }
        val infinitive = rawVerb.trim().lowercase(Locale.ROOT)
        val base = if (infinitive.endsWith("-se")) infinitive.dropLast(3) else infinitive
        if (tense == "المستقبل") {
            val endings = listOf("ei", "ás", "á", "emos", "ão", "ão")
            return endings.map { base + it }
        }
        val ending = when {
            base.endsWith("ar") -> "ar"
            base.endsWith("er") -> "er"
            base.endsWith("ir") -> "ir"
            else -> return listOf("—", "—", "—", "—", "—", "—")
        }
        val stem = base.dropLast(2)
        val endings = if (tense == "الماضي") {
            if (ending == "ar") listOf("ei", "aste", "ou", "ámos", "aram", "aram")
            else listOf("i", "este", "eu", "emos", "eram", "eram")
        } else {
            when (ending) {
                "ar" -> listOf("o", "as", "a", "amos", "am", "am")
                "er" -> listOf("o", "es", "e", "emos", "em", "em")
                else -> listOf("o", "es", "e", "imos", "em", "em")
            }
        }
        return endings.map { stem + it }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radiusDp * resources.displayMetrics.density
    }

    private fun marginParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        setMargins(0, 4, 0, 4)
    }

    private fun makeTile(label: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 14f; setTextColor(Color.WHITE); isAllCaps = false; setPadding(8, 9, 8, 9)
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(lighten(color, 0.13f), color)).apply {
            cornerRadius = 18 * resources.displayMetrics.density
        }
        // Custom glossy 3D icons matching the app's visual design.
        val iconRes = when {
            label.contains("الرئيسية") -> R.drawable.home_nav_icon
            label == "إضافة" || label.contains("إضافة كلمة") -> R.drawable.add_nav_icon
            label.contains("البطاقات") || label.contains("كلماتي") -> R.drawable.books_icon
            label.contains("اختبار") -> R.drawable.target_icon
            label.contains("تصريف") -> R.drawable.running_icon
            label.contains("Excel") || label.contains("استيراد") -> R.drawable.excel_icon
            label.contains("الأرقام") -> R.drawable.target_icon
            label.contains("الجمل") || label.contains("الأمثلة") -> R.drawable.open_book_icon
            label.contains("البحث") || label.contains("التصنيف") -> R.drawable.search_icon
            label.contains("Português") || label.contains("البرتغالية") -> R.drawable.portugal_book_icon
            label.contains("نطق") || label.contains("الصوت") || label.contains("تذكير") -> R.drawable.speaker_icon
            label.contains("تعديل") -> R.drawable.pencil_icon
            label.contains("حذف") -> R.drawable.trash_icon
            label.contains("مفضلة") -> R.drawable.favorite_icon
            label.contains("الوضع") || label.contains("إعدادات") -> R.drawable.theme_icon
            else -> 0
        }
        if (iconRes != 0) {
            val icon = getDrawable(iconRes)?.mutate()
            val size = (42 * resources.displayMetrics.density).toInt()
            icon?.setBounds(0, 0, size, size)
            setCompoundDrawables(null, icon, null, null)
            compoundDrawablePadding = (3 * resources.displayMetrics.density).toInt()
        }
        elevation = 3f
        stateListAnimator = null
        setOnClickListener { action() }
    }

    private fun lighten(color: Int, amount: Float): Int {
        val r = (Color.red(color) + (255 - Color.red(color)) * amount).toInt()
        val g = (Color.green(color) + (255 - Color.green(color)) * amount).toInt()
        val b = (Color.blue(color) + (255 - Color.blue(color)) * amount).toInt()
        return Color.rgb(r, g, b)
    }

    private fun editWord(existing: Int?) {
        val current = existing?.let { words[it] }
        val dark = prefs.getBoolean("home_dark", false)
        val pageBg = if (dark) 0xFF172334.toInt() else Color.WHITE
        val fieldBg = if (dark) 0xFF26364D.toInt() else 0xFFF1F5F9.toInt()
        val ink = if (dark) Color.WHITE else 0xFF102A43.toInt()
        val muted = if (dark) 0xFFD8E2F0.toInt() else 0xFF64748B.toInt()
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        fun styledField(hintText: String, size: Float, singleLine: Boolean = true, initial: String = "") = EditText(this).apply {
            hint = hintText
            textSize = size
            setSingleLine(singleLine)
            setTextColor(ink)
            setHintTextColor(muted)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(fieldBg, 14)
            backgroundTintList = android.content.res.ColorStateList.valueOf(if (dark) 0xFF52677F.toInt() else 0xFFCBD5E1.toInt())
            if (initial.isNotEmpty()) setText(initial)
        }

        val pt = styledField("🇵🇹 الكلمة بالبرتغالية", 17f, true, current?.pt.orEmpty())
        val ar = styledField("🇸🇦 الترجمة بالعربية", 17f, true, current?.ar.orEmpty())
        val exPt = styledField("مثال بالبرتغالية (اختياري)", 16f, false, current?.examplePt.orEmpty())
        val exAr = styledField("ترجمة المثال (اختياري)", 16f, false, current?.exampleAr.orEmpty())

        val categoryNames = arrayOf("الأسماء", "الأفعال", "الصفات")
        val categorySpinner = Spinner(this).apply {
            adapter = object : ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_spinner_item, categoryNames) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val view = (convertView as? TextView) ?: TextView(this@MainActivity)
                    view.text = categoryNames[position]
                    view.textSize = 16f
                    view.setTextColor(ink)
                    view.setPadding(dp(14), dp(12), dp(14), dp(12))
                    view.background = rounded(fieldBg, 14)
                    return view
                }
                override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val view = (convertView as? TextView) ?: TextView(this@MainActivity)
                    view.text = categoryNames[position]
                    view.textSize = 16f
                    view.setTextColor(ink)
                    view.setPadding(dp(16), dp(12), dp(16), dp(12))
                    view.setBackgroundColor(fieldBg)
                    return view
                }
            }.also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            background = rounded(fieldBg, 14)
            val initialCategory = current?.let { wordCategory(it) } ?: guessWordCategory(pt.text.toString())
            setSelection(categoryNames.indexOf(initialCategory).coerceAtLeast(0))
        }
        pt.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                categorySpinner.setSelection(categoryNames.indexOf(guessWordCategory(s?.toString().orEmpty())).coerceAtLeast(0))
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(16))
            background = rounded(pageBg, 24)
        }
        container.addView(TextView(this).apply {
            text = if (existing == null) "✏️ إضافة كلمة جديدة" else "📝 تعديل الكلمة"
            textSize = 22f; setTypeface(null, android.graphics.Typeface.BOLD); setTextColor(ink)
            gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(16))
        })
        fun addField(view: View, top: Int = 8) {
            container.addView(view, LinearLayout.LayoutParams(-1, if (view === exPt || view === exAr) dp(58) else dp(54)).apply { topMargin = dp(top) })
        }
        addField(pt, 0)
        addField(ar, 10)
        container.addView(TextView(this).apply {
            text = "نوع الكلمة"; textSize = 14f; setTextColor(muted); setPadding(dp(4), dp(12), dp(4), dp(4))
        })
        container.addView(categorySpinner, LinearLayout.LayoutParams(-1, dp(52)))
        addField(exPt, 10)
        addField(exAr, 10)

        val dialog = AlertDialog.Builder(this).setView(container).create()
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(16), 0, 0)
        }
        fun actionButton(label: String, colors: IntArray, click: () -> Unit) = TextView(this).apply {
            text = label; textSize = 15f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER; setPadding(dp(10), dp(14), dp(10), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = dp(16).toFloat() }
            isClickable = true; isFocusable = true; elevation = dp(2).toFloat()
            setOnClickListener { click() }
        }
        actions.addView(actionButton("✖  إلغاء", intArrayOf(0xFFE94B5B.toInt(), 0xFFB91C35.toInt())) {
            dialog.dismiss()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(5) })
        actions.addView(actionButton("💾  حفظ الكلمة", intArrayOf(0xFF168BFF.toInt(), 0xFF0758D8.toInt())) {
            val p = pt.text.toString().trim(); val a = ar.text.toString().trim()
            if (p.isNotEmpty() && a.isNotEmpty()) {
                val w = Word(p, a, exPt.text.toString().trim(), exAr.text.toString().trim(), categoryNames[categorySpinner.selectedItemPosition], true)
                if (existing == null) words.add(w) else if (existing in words.indices) words[existing] = w
                saveWords()
                dialog.dismiss()
                when {
                    showingMyWords -> showMyWords()
                    showingConjugations -> showConjugations()
                    else -> buildUi()
                }
                updateStatus()
            } else {
                toast("اكتب الكلمة والترجمة")
            }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(5) })
        container.addView(actions)

        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun renderWords() {
        val dark = prefs.getBoolean("home_dark", false)
        val cardBg = if (dark) 0xFF202B3C.toInt() else Color.WHITE
        val ink = if (dark) Color.WHITE else 0xFF102A43.toInt()
        val muted = if (dark) 0xFFD8E2F0.toInt() else 0xFF334E68.toInt()
        val exampleBg = if (dark) 0xFF344256.toInt() else 0xFFF1F5F9.toInt()
        list.setBackgroundColor(if (dark) 0xFF101827.toInt() else 0xFFF4F7FC.toInt())
        list.removeAllViews()
        if (words.isEmpty()) {
            list.addView(TextView(this).apply { text = "لم تضف كلمات بعد. أضف كلمة أو استورد ملف Excel."; textSize = 16f; setTextColor(if (dark) 0xFFD8E2F0.toInt() else 0xFF64748B.toInt()); setPadding(12, 18, 12, 18); background = rounded(cardBg, 16) }, marginParams())
            return
        }
        words.forEachIndexed { i, w ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 12); background = rounded(cardBg, 20); elevation = 2f
            }
            card.addView(TextView(this).apply { text = w.pt; textSize = 22f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD) })
            card.addView(TextView(this).apply { text = w.ar; textSize = 18f; gravity = Gravity.END; setTextColor(muted); setPadding(0, 2, 0, 4) })
            if (w.examplePt.isNotBlank()) {
                card.addView(TextView(this).apply { text = "${w.examplePt}\n${w.exampleAr}"; textSize = 14f; setTextColor(muted); setPadding(8, 8, 8, 8); background = rounded(exampleBg, 10) })
            }
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            buttons.addView(makeTile("نطق", 0xFF1769E8.toInt()) { speak(w.pt) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 4, 3, 0) })
            buttons.addView(makeTile("تعديل", 0xFF64748B.toInt()) { editWord(i) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 4, 3, 0) })
            buttons.addView(makeTile("حذف", 0xFFDC2626.toInt()) { confirmDelete(i) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 4, 0, 0) })
            card.addView(buttons)
            list.addView(card, marginParams())
        }
    }

    private fun confirmDelete(i: Int) {
        if (i !in words.indices) return
        AlertDialog.Builder(this).setMessage("حذف ${words[i].pt}؟").setPositiveButton("حذف") { _, _ -> words.removeAt(i); saveWords(); if (showingMyWords) showMyWords() else buildUi(); updateStatus() }.setNegativeButton("إلغاء", null).show()
    }

    private data class NumberEntry(val value: Int, val pt: String, val ar: String)

    private fun numberEntries(): List<NumberEntry> = (0..10000).map { n ->
        NumberEntry(n, numberToPortuguese(n), numberToArabic(n))
    }

    private fun numberToPortuguese(n: Int): String {
        val units = listOf("zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove", "dez", "onze", "doze", "treze", "catorze", "quinze", "dezasseis", "dezassete", "dezoito", "dezanove")
        val tens = mapOf(20 to "vinte", 30 to "trinta", 40 to "quarenta", 50 to "cinquenta", 60 to "sessenta", 70 to "setenta", 80 to "oitenta", 90 to "noventa")
        val hundreds = mapOf(1 to "cento", 2 to "duzentos", 3 to "trezentos", 4 to "quatrocentos", 5 to "quinhentos", 6 to "seiscentos", 7 to "setecentos", 8 to "oitocentos", 9 to "novecentos")
        fun underThousand(x: Int): String {
            if (x < 20) return units[x]
            if (x < 100) return if (x % 10 == 0) tens[x]!! else "${tens[x / 10 * 10]} e ${units[x % 10]}"
            if (x == 100) return "cem"
            val h = x / 100
            val r = x % 100
            val head = hundreds[h]!!
            return if (r == 0) head else "$head e ${underThousand(r)}"
        }
        if (n < 1000) return underThousand(n)
        val thousands = n / 1000
        val remainder = n % 1000
        val head = if (thousands == 1) "mil" else "${underThousand(thousands)} mil"
        if (remainder == 0) return head
        val joiner = if (remainder < 100 || remainder % 100 == 0) " e " else " "
        return head + joiner + underThousand(remainder)
    }

    private fun numberToArabic(n: Int): String {
        val units = listOf("صفر", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة", "عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر")
        val tens = mapOf(20 to "عشرون", 30 to "ثلاثون", 40 to "أربعون", 50 to "خمسون", 60 to "ستون", 70 to "سبعون", 80 to "ثمانون", 90 to "تسعون")
        val hundreds = mapOf(1 to "مئة", 2 to "مئتان", 3 to "ثلاثمئة", 4 to "أربعمئة", 5 to "خمسمئة", 6 to "ستمئة", 7 to "سبعمئة", 8 to "ثمانمئة", 9 to "تسعمئة")
        fun underThousand(x: Int): String {
            if (x < 20) return units[x]
            if (x < 100) return if (x % 10 == 0) tens[x]!! else "${units[x % 10]} و${tens[x / 10 * 10]}"
            val h = x / 100
            val r = x % 100
            return if (r == 0) hundreds[h]!! else "${hundreds[h]} و${underThousand(r)}"
        }
        if (n < 1000) return underThousand(n)
        val thousands = n / 1000
        val thousandText = when (thousands) {
            1 -> "ألف"
            2 -> "ألفان"
            else -> "${underThousand(thousands)} آلاف"
        }
        val remainder = n % 1000
        return if (remainder == 0) thousandText else "$thousandText و${underThousand(remainder)}"
    }

    private fun showNumbers() {
        val dark = prefs.getBoolean("home_dark", false)
        val bg = if (dark) 0xFF101827.toInt() else 0xFFF1F7FF.toInt()
        val cardBg = if (dark) 0xFF202F45.toInt() else Color.WHITE
        val ink = if (dark) Color.WHITE else 0xFF102A72.toInt()
        val muted = if (dark) 0xFFD8E5F6.toInt() else 0xFF334E68.toInt()
        val entries = numberEntries()
        var selectedFilter = "الكل"
        var query = ""
        var displayedLimit = 100
        lateinit var dialog: AlertDialog
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 10); background = rounded(bg, 26) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(14, 12, 10, 12); background = rounded(0xFF087AF0.toInt(), 22) }
        val titleColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleColumn.addView(TextView(this).apply { text = "🇵🇹  الأرقام البرتغالية"; textSize = 22f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) })
        titleColumn.addView(TextView(this).apply { text = "Racha & Med  ♥  تعلّم الأرقام ونطقها"; textSize = 13f; setTextColor(0xFFEAF4FF.toInt()); setPadding(0, 3, 0, 0) })
        header.addView(titleColumn, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(makeTile("✕", 0xFF0756B7.toInt()) { dialog.dismiss() })
        panel.addView(header, marginParams())
        val search = EditText(this).apply {
            hint = "🔎  ابحث عن رقم أو كلمة..."; textSize = 16f; setSingleLine(true); setTextColor(ink); setHintTextColor(muted)
            background = rounded(if (dark) 0xFF26384F.toInt() else Color.WHITE, 18); setPadding(16, 10, 16, 10)
        }
        panel.addView(search, LinearLayout.LayoutParams(-1, (52 * resources.displayMetrics.density).toInt()).apply { setMargins(0, 7, 0, 7) })
        val filterRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val filters = listOf("الكل", "0–20", "العشرات", "المئات", "الآلاف")
        val filterButtons = mutableMapOf<String, Button>()
        filters.forEach { filter ->
            val b = makeTile(filter, if (filter == selectedFilter) 0xFF087AF0.toInt() else if (dark) 0xFF26384F.toInt() else 0xFFDCE8F7.toInt()) {
                selectedFilter = filter
                displayedLimit = 100
                filterButtons.forEach { (name, button) -> button.background = rounded(if (name == selectedFilter) 0xFF087AF0.toInt() else if (dark) 0xFF26384F.toInt() else 0xFFDCE8F7.toInt(), 15); button.setTextColor(if (name == selectedFilter || dark) Color.WHITE else 0xFF16345B.toInt()) }
                refreshNumbers()
            }
            b.textSize = 12f; b.setPadding(2, 7, 2, 7); b.setTextColor(if (filter == selectedFilter || dark) Color.WHITE else 0xFF16345B.toInt())
            filterButtons[filter] = b
            filterRow.addView(b, LinearLayout.LayoutParams(0, (43 * resources.displayMetrics.density).toInt(), 1f).apply { setMargins(2, 0, 2, 0) })
        }
        panel.addView(filterRow)
        val count = TextView(this).apply { textSize = 14f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, 8, 0, 4) }
        panel.addView(count)
        val numberScroll = ScrollView(this).apply { isFillViewport = false }
        val numberList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        numberScroll.addView(numberList)
        panel.addView(numberScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val loadMoreButton = makeTile("عرض المزيد من الأرقام ↓", 0xFF059669.toInt()) { displayedLimit += 100; refreshNumbers() }
        panel.addView(loadMoreButton, marginParams())
        panel.addView(makeTile("🔊  استمع إلى الأرقام من 0 إلى 20", 0xFF1769E8.toInt()) { speak((0..20).joinToString(", ") { entries[it].pt }) }, marginParams())
        fun matches(n: NumberEntry): Boolean {
            val filterOk = when (selectedFilter) {
                "0–20" -> n.value <= 20
                "العشرات" -> n.value in 20..90 && n.value % 10 == 0
                "المئات" -> n.value in 100..999
                "الآلاف" -> n.value in 1000..10000
                else -> true
            }
            return filterOk && (query.isBlank() || n.value.toString().contains(query) || n.pt.contains(query, true) || n.ar.contains(query))
        }
        fun drawNumbers() {
            val filtered = entries.filter { matches(it) }
            count.text = "${filtered.size} رقمًا • عرض ${minOf(filtered.size, displayedLimit)} • اضغط 🔊 لسماع النطق البرتغالي الأوروبي"
            loadMoreButton.visibility = if (filtered.size > displayedLimit) View.VISIBLE else View.GONE
            numberList.removeAllViews()
            if (filtered.isEmpty()) {
                numberList.addView(TextView(this).apply { text = "لا توجد نتائج"; textSize = 17f; gravity = Gravity.CENTER; setTextColor(muted); setPadding(12, 28, 12, 28) })
                return
            }
            filtered.take(displayedLimit).chunked(2).forEachIndexed { rowIndex, pair ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                pair.forEachIndexed { colIndex, item ->
                    val colors = intArrayOf(0xFFFFDCEB.toInt(), 0xFFD5FFE9.toInt(), 0xFFFFF0C5.toInt(), 0xFFD9EEFF.toInt(), 0xFFF0DFFF.toInt(), 0xFFFFE0D0.toInt(), 0xFFD0FAFF.toInt())
                    val tileBg = if (dark) 0xFF243650.toInt() else colors[(item.value + rowIndex) % colors.size]
                    val tile = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(9, 10, 7, 10); background = rounded(tileBg, 18); elevation = 1.5f }
                    val number = TextView(this).apply { text = item.value.toString(); textSize = if (item.value >= 100) 29f else 36f; setTextColor(when (item.value % 5) { 0 -> 0xFFE11D48.toInt(); 1 -> 0xFF059669.toInt(); 2 -> 0xFFD97706.toInt(); 3 -> 0xFF2563EB.toInt(); else -> 0xFF9333EA.toInt() }); setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER; minWidth = (48 * resources.displayMetrics.density).toInt() }
                    val wordCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(5, 0, 0, 0) }
                    wordCol.addView(TextView(this).apply { text = item.pt; textSize = 15f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD) })
                    wordCol.addView(TextView(this).apply { text = item.value.toString(); textSize = 12f; setTextColor(muted) })
                    wordCol.addView(TextView(this).apply { text = item.ar; textSize = 13f; setTextColor(muted) })
                    tile.addView(number)
                    tile.addView(wordCol, LinearLayout.LayoutParams(0, -2, 1f))
                    tile.addView(makeTile("🔊", 0xFF087AF0.toInt()) { speak(item.pt) }.apply { textSize = 13f; minWidth = (43 * resources.displayMetrics.density).toInt(); setPadding(0, 5, 0, 5) })
                    row.addView(tile, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(if (colIndex == 0) 0 else 4, 3, if (colIndex == 0) 4 else 0, 3) })
                }
                if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
                numberList.addView(row)
            }
        }
        // Local callback used by the filter buttons and search field.
        refreshNumbers = { drawNumbers() }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s?.toString().orEmpty().trim(); displayedLimit = 100; drawNumbers() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        drawNumbers()
        dialog = AlertDialog.Builder(this).setView(panel).create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    }

    private fun showExamples() {
        val examples = words.filter { it.examplePt.isNotBlank() }
        if (examples.isEmpty()) {
            AlertDialog.Builder(this).setTitle("الجمل والأمثلة")
                .setMessage("لا توجد أمثلة محفوظة بعد. أضف كلمة ثم اكتب المثال البرتغالي وترجمته، أو استورد ملف Excel بأربعة أعمدة: البرتغالية، العربية، المثال، ترجمة المثال.")
                .setPositiveButton("حسنًا", null).show()
            return
        }
        val body = examples.joinToString("\n\n──────────\n\n") { "${it.examplePt}\n${it.exampleAr}\n(${it.pt} = ${it.ar})" }
        val text = TextView(this).apply { this.text = body; textSize = 17f; setTextColor(0xFF243B53.toInt()); setPadding(22, 14, 22, 14) }
        AlertDialog.Builder(this).setTitle("الجمل والأمثلة (${examples.size})").setView(ScrollView(this).apply { addView(text) }).setPositiveButton("إغلاق", null).show()
    }

    private fun startFlashcards() {
        if (words.isEmpty()) { toast("أضف كلمات أولًا"); return }
        val dark = prefs.getBoolean("home_dark", false)
        val bg = if (dark) 0xFF0B1220.toInt() else 0xFFF1F7FF.toInt()
        val ink = if (dark) Color.WHITE else 0xFF14294D.toInt()
        val muted = if (dark) 0xFFB8C7DC.toInt() else 0xFF64748B.toInt()
        val known = prefs.getStringSet("flashcards_known_v1", emptySet())?.size ?: 0
        val difficult = prefs.getStringSet("flashcards_difficult_v1", emptySet())?.size ?: 0
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(java.util.Date())
        if (prefs.getString("flashcards_goal_date", "") != today) {
            prefs.edit().putString("flashcards_goal_date", today).putInt("flashcards_goal_count", 0).apply()
        }
        val todayCount = prefs.getInt("flashcards_goal_count", 0)
        val hub = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(if (dark) 0xFF071426.toInt() else 0xFFEAF3FF.toInt(), bg, if (dark) 0xFF101B32.toInt() else 0xFFF7FAFF.toInt())).apply { cornerRadius = dp(28).toFloat() }
        }
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(16), dp(18), dp(16), dp(18)); elevation = dp(8).toFloat()
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF16B9F5.toInt(), 0xFF075CE5.toInt(), 0xFF5B35E8.toInt())).apply { cornerRadius = dp(28).toFloat(); setStroke(dp(1), 0x667DD3FC) }
        }
        hero.addView(TextView(this).apply { text = "🎮"; textSize = 42f; gravity = Gravity.CENTER })
        hero.addView(TextView(this).apply { text = "رحلة تعلّم الكلمات"; textSize = 24f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) })
        hero.addView(TextView(this).apply { text = "تعلّم • استمع • اختبر نفسك • اجمع النجوم"; textSize = 13f; gravity = Gravity.CENTER; setTextColor(0xFFE0F2FE.toInt()); setPadding(0, dp(5), 0, 0) })
        hub.addView(hero, marginParams())
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)) }
        fun statTile(emoji: String, label: String, value: String, color: Int): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(6), dp(10), dp(6), dp(10)); elevation = dp(3).toFloat()
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (dark) 0xFF213653.toInt() else 0xFFFFFFFF.toInt(), if (dark) 0xFF15243A.toInt() else 0xFFDDEBFF.toInt())).apply { cornerRadius = dp(18).toFloat(); setStroke(dp(1), if (dark) 0xFF2C4568.toInt() else 0xFFC3D8F5.toInt()) }
            addView(TextView(this@MainActivity).apply { text = emoji; textSize = 22f; gravity = Gravity.CENTER })
            addView(TextView(this@MainActivity).apply { text = value; textSize = 19f; gravity = Gravity.CENTER; setTextColor(color); setTypeface(null, android.graphics.Typeface.BOLD) })
            addView(TextView(this@MainActivity).apply { text = label; textSize = 11f; gravity = Gravity.CENTER; setTextColor(muted) })
        }
        stats.addView(statTile("📚", "كل الكلمات", words.size.toString(), 0xFF38BDF8.toInt()), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        stats.addView(statTile("✅", "أعرفها", known.toString(), 0xFF22C55E.toInt()), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        stats.addView(statTile("🔥", "هدف اليوم", "$todayCount / 15", 0xFFF59E0B.toInt()), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        hub.addView(stats)
        val goal = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 15; progress = todayCount.coerceAtMost(15)
            progressTintList = android.content.res.ColorStateList.valueOf(0xFF22C55E.toInt())
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(if (dark) 0xFF334155.toInt() else 0xFFD8E4F2.toInt())
        }
        hub.addView(goal, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(7)).apply { setMargins(dp(4), 0, dp(4), dp(12)) })
        hub.addView(TextView(this).apply { text = "اختر طريقة التعلّم"; textSize = 18f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(dp(4), dp(4), dp(4), dp(8)) })
        fun modeButton(icon: String, title: String, subtitle: String, color: Int, action: () -> Unit) {
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10))
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(lighten(color, .25f), color, (color and 0x00FFFFFF) or 0xFF071426.toInt())).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), 0x557FFFFF.toInt()) }
                elevation = dp(5).toFloat(); isClickable = true; isFocusable = true; setOnClickListener { action() }
            }
            tile.addView(TextView(this).apply { text = icon; textSize = 30f; gravity = Gravity.CENTER; setShadowLayer(8f, 0f, dp(3).toFloat(), 0xAA000000.toInt()) }, LinearLayout.LayoutParams(dp(54), dp(54)))
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
            labels.addView(TextView(this).apply { text = title; textSize = 17f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) })
            labels.addView(TextView(this).apply { text = subtitle; textSize = 12f; setTextColor(0xFFF1F5F9.toInt()); setPadding(0, dp(2), 0, 0) })
            tile.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            tile.addView(TextView(this).apply { text = "›"; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
            hub.addView(tile, marginParams().apply { setMargins(0, dp(4), 0, dp(4)) })
        }
        modeButton("🃏", "وضع البطاقات", "صورة • كلمة • ترجمة • نطق", 0xFF1769E8.toInt()) { startFlashcardSession("cards") }
        modeButton("🎧", "وضع الاستماع", "استمع إلى الكلمة ثم اكشف معناها", 0xFF059669.toInt()) { startFlashcardSession("listen") }
        modeButton("⌨️", "وضع الكتابة", "اكتب الكلمة البرتغالية من الذاكرة", 0xFFF59E0B.toInt()) { startWritingPractice() }
        modeButton("🧩", "Pair It • طابق الأزواج", "طابق الكلمة البرتغالية مع معناها العربي", 0xFFDB2777.toInt()) { startPairIt() }
        modeButton("🎯", "Guess It • خمّن المعنى", "استمع إلى الكلمة واختر معناها الصحيح", 0xFF0EA5E9.toInt()) { startGuessIt() }
        modeButton("🧠", "المراجعة الذكية", "ابدأ بالكلمات التي وضعتها صعبة", 0xFF7C3AED.toInt()) { startFlashcardSession("review") }
        hub.addView(TextView(this).apply { text = "🏆 إنجازاتك"; textSize = 17f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(dp(4), dp(10), dp(4), dp(6)) })
        val badges = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf(Triple("⭐", "10 كلمات", known >= 10), Triple("📘", "50 كلمة", known >= 50), Triple("👑", "100 كلمة", known >= 100)).forEach { badge ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(5), dp(8), dp(5), dp(8))
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (badge.third) 0xFF176B79.toInt() else if (dark) 0xFF213653.toInt() else 0xFFFFFFFF.toInt(), if (badge.third) 0xFF123D55.toInt() else if (dark) 0xFF14243B.toInt() else 0xFFDDEBFF.toInt())).apply { cornerRadius = dp(18).toFloat(); setStroke(dp(1), if (dark) 0xFF29486E.toInt() else 0xFFC4D9F5.toInt()) }; elevation = dp(3).toFloat()
                alpha = if (badge.third) 1f else 0.65f
                addView(TextView(this@MainActivity).apply { text = badge.first; textSize = 24f; gravity = Gravity.CENTER })
                addView(TextView(this@MainActivity).apply { text = badge.second; textSize = 11f; gravity = Gravity.CENTER; setTextColor(if (dark) Color.WHITE else 0xFF334155.toInt()) })
            }
            badges.addView(tile, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        hub.addView(badges)
        hub.addView(makeTile("✕ إغلاق", if (dark) 0xFF334155.toInt() else 0xFF64748B.toInt()) { closeLearningHub() }, marginParams())
        val hubScroll = ScrollView(this).apply { isFillViewport = true; addView(hub) }
        val hubScreen = learningScreenRoot(hubScroll, bg)
        flashcardsHubView = hubScreen
        learningHubShowing = true
        learningGameShowing = false
        setContentView(hubScreen)
    }

    private fun startWritingPractice() {
        if (words.isEmpty()) { toast("أضف كلمات أولًا"); return }
        val pool = words.shuffled().take(minOf(10, words.size))
        var index = 0
        var score = 0
        val dark = prefs.getBoolean("home_dark", false)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (dark) 0xFF071426.toInt() else 0xFFEAF3FF.toInt(), if (dark) 0xFF101B32.toInt() else 0xFFF7FAFF.toInt())).apply { cornerRadius = dp(26).toFloat() }
        }
        val header = TextView(this).apply {
            text = "⌨️ وضع الكتابة"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD); setPadding(dp(12), dp(14), dp(12), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF16B9F5.toInt(), 0xFF075CE5.toInt(), 0xFF5B35E8.toInt())).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), 0x667DD3FC) }; elevation = dp(6).toFloat()
        }
        val progress = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; setTextColor(if (dark) 0xFFD8E2F0.toInt() else 0xFF64748B.toInt()); setPadding(0, dp(12), 0, dp(8)) }
        val prompt = TextView(this).apply { textSize = 26f; gravity = Gravity.CENTER; setTextColor(if (dark) Color.WHITE else 0xFF14294D.toInt()); setPadding(dp(12), dp(22), dp(12), dp(22)); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (dark) 0xFF1D3557.toInt() else Color.WHITE, if (dark) 0xFF0C1D35.toInt() else 0xFFEAF4FF.toInt())).apply { cornerRadius = dp(28).toFloat(); setStroke(dp(2), if (dark) 0xFF328BFF.toInt() else 0xFF8EC5FF.toInt()) }; elevation = dp(5).toFloat() }
        val answer = EditText(this).apply {
            hint = "اكتب الكلمة بالبرتغالية"; textSize = 18f; setSingleLine(true); gravity = Gravity.CENTER
            setTextColor(if (dark) Color.WHITE else 0xFF14294D.toInt()); setHintTextColor(if (dark) 0xFF9CA3AF.toInt() else 0xFF64748B.toInt())
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (dark) 0xFF243A58.toInt() else Color.WHITE, if (dark) 0xFF15243A.toInt() else 0xFFE8F2FF.toInt())).apply { cornerRadius = dp(18).toFloat(); setStroke(dp(1), if (dark) 0xFF3974C9.toInt() else 0xFFB7D4FA.toInt()) }; elevation = dp(3).toFloat(); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val feedback = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER; setPadding(dp(8), dp(10), dp(8), dp(10)); visibility = View.GONE }
        val check = makeTile("تحقق من الإجابة ✓", 0xFF059669.toInt()) {}
        val next = makeTile("التالي ⟶", 0xFF1769E8.toInt()) {}.apply { visibility = View.GONE }
        fun load() {
            val item = pool[index]
            progress.text = "السؤال ${index + 1} من ${pool.size} • النتيجة $score"
            prompt.text = "✍️ اكتب بالبرتغالية:\n\n${item.ar}"
            answer.setText(""); answer.isEnabled = true; feedback.visibility = View.GONE
            check.visibility = View.VISIBLE; next.visibility = View.GONE
        }
        panel.addView(header); panel.addView(progress); panel.addView(prompt); panel.addView(answer); panel.addView(feedback); panel.addView(check); panel.addView(next)
        panel.addView(makeTile("✕ رجوع إلى تعلّم الكلمات", if (dark) 0xFF334155.toInt() else 0xFF64748B.toInt()) { returnToLearningHub() })
        check.setOnClickListener {
            val item = pool[index]
            if (answer.text.toString().trim().equals(item.pt.trim(), ignoreCase = true)) {
                score++; feedback.text = "✅ صحيح! ${item.pt}"; feedback.setTextColor(0xFF22C55E.toInt())
            } else {
                feedback.text = "💡 الإجابة: ${item.pt} • ${item.ar}"; feedback.setTextColor(0xFFF59E0B.toInt())
            }
            feedback.visibility = View.VISIBLE; answer.isEnabled = false; check.visibility = View.GONE; next.visibility = View.VISIBLE
        }
        next.setOnClickListener {
            if (index < pool.lastIndex) { index++; load() }
            else { prompt.text = "🎉 انتهيت!\n\nنتيجتك: $score / ${pool.size}"; answer.visibility = View.GONE; progress.text = "أحسنت، واصل التدريب!"; check.visibility = View.GONE; next.text = "العودة إلى التعلّم"; next.setOnClickListener { returnToLearningHub() } }
        }
        load()
        showLearningGame(ScrollView(this).apply { isFillViewport = true; addView(panel) })
    }

    private fun startFlashcardSession(mode: String = "cards") {
        if (words.isEmpty()) { toast("أضف كلمات أولًا"); return }
        val knownSet = prefs.getStringSet("flashcards_known_v1", emptySet())!!.toMutableSet()
        val difficultSet = prefs.getStringSet("flashcards_difficult_v1", emptySet())!!.toMutableSet()
        fun wordKey(w: Word): String = "${w.pt.trim().lowercase(java.util.Locale.ROOT)}|${w.ar.trim().lowercase(java.util.Locale.ROOT)}"
        // Unlearned words are shown first; difficult words return at the end of the current round.
        var deck = if (mode == "review") {
            words.filter { wordKey(it) in difficultSet && wordKey(it) !in knownSet }.toMutableList()
        } else if (mode == "listen") {
            (words.filter { wordKey(it) !in knownSet && wordKey(it) !in difficultSet } +
                    words.filter { wordKey(it) !in knownSet && wordKey(it) in difficultSet }).toMutableList()
        } else {
            (words.filter { wordKey(it) !in knownSet && wordKey(it) !in difficultSet } +
                    words.filter { wordKey(it) !in knownSet && wordKey(it) in difficultSet }).toMutableList()
        }
        if (mode == "review" && deck.isEmpty()) { toast("لا توجد كلمات صعبة للمراجعة حاليًا"); return }
        var index = 0
        var revealed = false
        var showExample = false
        var visualVariant = 0
        var reviewAllMode = false
        val dark = prefs.getBoolean("home_dark", false)
        val panelBg = if (dark) 0xFF071426.toInt() else 0xFFEAF3FF.toInt()
        val cardBg = if (dark) 0xFF142846.toInt() else Color.WHITE
        val ink = if (dark) Color.WHITE else 0xFF334155.toInt()
        val muted = if (dark) 0xFFD8E2F0.toInt() else 0xFF64748B.toInt()
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(panelBg, if (dark) 0xFF0C1B31.toInt() else 0xFFF8FBFF.toInt())).apply { cornerRadius = dp(28).toFloat() } }
        val topHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(13), dp(10), dp(13)); elevation = dp(6).toFloat(); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF18B8F4.toInt(), 0xFF075DE7.toInt(), 0xFF5638E8.toInt())).apply { cornerRadius = dp(24).toFloat(); setStroke(dp(1), 0x667DD3FC) } }
        topHeader.addView(ImageView(this).apply {
            setImageResource(R.drawable.flashcard_header)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "أيقونة البطاقات التعليمية"
        }, LinearLayout.LayoutParams(dp(54), dp(58)).apply { marginEnd = dp(8) })
        val headerTitle = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        headerTitle.addView(TextView(this).apply { text = when (mode) { "listen" -> "وضع الاستماع"; "review" -> "المراجعة الذكية"; else -> "البطاقات التعليمية" }; textSize = 20f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) })
        headerTitle.addView(TextView(this).apply { text = when (mode) { "listen" -> "استمع للنطق الأوروبي وتذكّر المعنى"; "review" -> "نراجع الكلمات التي تحتاج إلى تدريب"; else -> "الكلمات الصعبة تعود حتى تتعلمها" }; textSize = 12f; setTextColor(0xFFEAF2FF.toInt()); setPadding(0, 3, 0, 0) })
        topHeader.addView(headerTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        topHeader.addView(makeTile("✕ رجوع", 0xFF143D9C.toInt()) { returnToLearningHub() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panel.addView(topHeader, marginParams())
        val progress = TextView(this).apply { textSize = 14f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, 8, 0, 8) }
        val progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = maxOf(1, deck.size); this.progress = 1; progressTintList = android.content.res.ColorStateList.valueOf(0xFF10F0B0.toInt()); progressBackgroundTintList = android.content.res.ColorStateList.valueOf(if (dark) 0xFF253D5F.toInt() else 0xFFDCE5F1.toInt()) }
        val wordCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(18), dp(20), dp(18), dp(20)); elevation = dp(8).toFloat()
            minimumHeight = dp(0)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(if (dark) 0xFF1D3557.toInt() else 0xFFFFFFFF.toInt(), if (dark) 0xFF0C1D35.toInt() else 0xFFEAF4FF.toInt(), if (dark) 0xFF142B4B.toInt() else 0xFFDDEBFF.toInt())).apply {
                cornerRadius = dp(30).toFloat(); setStroke(dp(2), if (dark) 0xFF328BFF.toInt() else 0xFF8EC5FF.toInt())
            }
        }
        val visual = TextView(this).apply {
            textSize = 68f; gravity = Gravity.CENTER; setPadding(dp(4), dp(4), dp(4), dp(4))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF60A5FA.toInt(), 0xFF2563EB.toInt(), 0xFF102F8F.toInt())).apply { shape = GradientDrawable.OVAL; setStroke(dp(3), 0xFFBFDBFE.toInt()) }
            elevation = dp(8).toFloat(); setShadowLayer(12f, 0f, dp(5).toFloat(), 0xAA000000.toInt())
        }
        val wordText = TextView(this).apply { textSize = 34f; gravity = Gravity.CENTER; setTextColor(if (dark) 0xFFF8FBFF.toInt() else 0xFF102A72.toInt()); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(8), 0, dp(5)); setShadowLayer(3f, 0f, dp(2).toFloat(), if (dark) 0x664DB7FF else 0x22000000) }
        val portugueseTag = TextView(this).apply { text = "🇵🇹  PORTUGUÊS"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(if (dark) 0xFFB8D9FF.toInt() else 0xFF1D4ED8.toInt()); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(dp(14), dp(5), dp(14), dp(5)); background = rounded(if (dark) 0xFF123E82.toInt() else 0xFFDBEAFE.toInt(), 18) }
        val speaker = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; isClickable = true; isFocusable = true
            setPadding(dp(12), dp(8), dp(12), dp(8)); elevation = dp(7).toFloat()
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF20BDF9.toInt(), 0xFF0875FF.toInt(), 0xFF1747D0.toInt())).apply { cornerRadius = dp(28).toFloat(); setStroke(dp(2), 0xFF53C8FF.toInt()) }
            addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.flashcard_sound); scaleType = ImageView.ScaleType.FIT_CENTER; contentDescription = "تشغيل النطق" }, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginEnd = dp(10) })
            addView(TextView(this@MainActivity).apply { text = "استمع للنطق الأوروبي"; textSize = 17f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER })
            setOnClickListener { if (deck.isNotEmpty()) speak(deck[index.coerceIn(0, deck.lastIndex)].pt) }
        }
        val separator = View(this).apply { setBackgroundColor(if (dark) 0xFF29486E.toInt() else 0xFFD2E4FA.toInt()) }
        val translation = TextView(this).apply { textSize = 26f; gravity = Gravity.CENTER; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(12), 0, dp(4)) }
        val arabicTag = TextView(this).apply { text = "العربية"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(if (dark) 0xFF9AF2C5.toInt() else 0xFF047857.toInt()); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(dp(14), dp(5), dp(14), dp(5)); background = rounded(if (dark) 0xFF0D493D.toInt() else 0xFFD1FAE5.toInt(), 18); visibility = View.GONE }
        val example = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER; setTextColor(muted); setPadding(dp(4), dp(10), dp(4), 0); visibility = View.GONE }
        wordCard.addView(visual, LinearLayout.LayoutParams(dp(108), dp(108)).apply { gravity = Gravity.CENTER })
        wordCard.addView(wordText); wordCard.addView(portugueseTag, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER; bottomMargin = dp(8) }); wordCard.addView(speaker, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(2), dp(12), dp(8) ) }); wordCard.addView(separator, LinearLayout.LayoutParams(-1, dp(1)).apply { setMargins(dp(12), dp(8), dp(12), dp(4)) }); wordCard.addView(translation); wordCard.addView(arabicTag); wordCard.addView(example)
        val selfRate = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        var refresh: () -> Unit = {}
        fun ratingButton(label: String, iconRes: Int, colors: IntArray, stroke: Int): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; isClickable = true; isFocusable = true
            setPadding(dp(8), dp(6), dp(8), dp(6)); elevation = dp(12).toFloat()
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = dp(30).toFloat(); setStroke(dp(2), stroke) }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes); scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true; contentDescription = label
            }, LinearLayout.LayoutParams(dp(76), dp(76)).apply { marginEnd = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = label; textSize = 21f; setTextColor(Color.WHITE)
                setTypeface(null, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER
                maxLines = 1; includeFontPadding = true
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val difficult = ratingButton("صعب", R.drawable.flashcard_brain, intArrayOf(0xFFFF4F91.toInt(), 0xFFE6005A.toInt(), 0xFF9F0645.toInt()), 0xFFFF9FC2.toInt())
        val known = ratingButton("أعرفها", R.drawable.flashcard_check, intArrayOf(0xFF4DFF83.toInt(), 0xFF08C96A.toInt(), 0xFF008B51.toInt()), 0xFF9AFFB9.toInt())
        selfRate.addView(difficult, LinearLayout.LayoutParams(0, dp(96), 1f).apply { setMargins(dp(4), dp(8), dp(4), dp(4)) })
        selfRate.addView(known, LinearLayout.LayoutParams(0, dp(96), 1f).apply { setMargins(dp(4), dp(8), dp(4), dp(4)) })
        val actionBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(8), dp(4), dp(4)); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (dark) 0xFF142B4B.toInt() else 0xFFE1EEFF.toInt(), if (dark) 0xFF0B1B32.toInt() else 0xFFF7FAFF.toInt())).apply { cornerRadius = dp(26).toFloat(); setStroke(dp(1), if (dark) 0xFF234D83.toInt() else 0xFFBDD9FF.toInt()) } }
        fun actionItem(icon: String, label: String, color: Int, click: () -> Unit): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), dp(4), dp(3), dp(4)); isClickable = true; isFocusable = true; setOnClickListener { click() }
            val iconRes = when (label) {
                "إظهار الترجمة", "إخفاء الترجمة" -> R.drawable.flashcard_translation
                "مثال", "إخفاء المثال" -> R.drawable.flashcard_example
                "إضافة للمفضلة" -> R.drawable.flashcard_favorite
                "صورة أخرى" -> R.drawable.flashcard_camera
                else -> 0
            }
            addView(FrameLayout(this@MainActivity).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(lighten(color, .30f), color, 0xFF102341.toInt())).apply { shape = GradientDrawable.OVAL; setStroke(dp(1), 0xAA9BD7FF.toInt()) }
                elevation = dp(8).toFloat()
                addView(ImageView(this@MainActivity).apply {
                    if (iconRes != 0) setImageResource(iconRes) else setImageDrawable(null)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    adjustViewBounds = true
                    contentDescription = label
                }, FrameLayout.LayoutParams(dp(70), dp(70), Gravity.CENTER))
            }, LinearLayout.LayoutParams(dp(82), dp(76)).apply { gravity = Gravity.CENTER })
            addView(TextView(this@MainActivity).apply { text = label; textSize = 12f; gravity = Gravity.CENTER; setTextColor(ink); setPadding(0, dp(3), 0, 0); maxLines = 2 })
        }
        val reveal = actionItem("🌐", "إظهار الترجمة", 0xFF0875FF.toInt()) { if (deck.isNotEmpty()) { revealed = !revealed; refresh() } }
        val revealLabel = reveal.getChildAt(1) as TextView
        val exampleAction = actionItem("📄", "مثال", 0xFF34527D.toInt()) {
            if (deck.isNotEmpty()) {
                val w = deck[index.coerceIn(0, deck.lastIndex)]
                if (w.examplePt.isBlank() && w.exampleAr.isBlank()) toast("لا يوجد مثال محفوظ لهذه الكلمة")
                else { revealed = true; showExample = !showExample; refresh() }
            }
        }
        val exampleLabel = exampleAction.getChildAt(1) as TextView
        var favoriteIconView: ImageView? = null
        val favoriteAction = actionItem("💜", "إضافة للمفضلة", 0xFF9333EA.toInt()) {
            if (deck.isNotEmpty()) {
                val w = deck[index.coerceIn(0, deck.lastIndex)]; val fav = prefs.getStringSet("flashcards_favorites_v1", emptySet())?.toMutableSet() ?: mutableSetOf()
                val key = wordKey(w)
                if (fav.contains(key)) { fav.remove(key); toast("أزيلت من المفضلة") } else { fav.add(key); toast("أضيفت إلى المفضلة ⭐") }
                prefs.edit().putStringSet("flashcards_favorites_v1", fav.toSet()).apply()
                favoriteIconView?.setImageResource(R.drawable.flashcard_favorite)
                if (fav.contains(key)) favoriteIconView?.setColorFilter(0xFFFFD54F.toInt()) else favoriteIconView?.clearColorFilter()
            }
        }
        favoriteIconView = (favoriteAction.getChildAt(0) as? FrameLayout)?.getChildAt(0) as? ImageView
        val imageAction = actionItem("📸", "صورة أخرى", 0xFFF59E0B.toInt()) {
            if (deck.isNotEmpty()) { visualVariant = (visualVariant + 1) % 2; refresh() }
        }
        listOf(reveal, exampleAction, favoriteAction, imageAction).forEach { actionBar.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        panel.addView(progress); panel.addView(progressBar, LinearLayout.LayoutParams(-1, dp(6)).apply { setMargins(0, 0, 0, dp(8)) }); panel.addView(wordCard, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, dp(8), 0, dp(8)) }); panel.addView(selfRate); panel.addView(actionBar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        var touchStartX = 0f
        wordCard.setOnTouchListener { _, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> { touchStartX = event.x; true }
                android.view.MotionEvent.ACTION_UP -> {
                    val delta = event.x - touchStartX
                    if (kotlin.math.abs(delta) > dp(70)) {
                        if (deck.isEmpty()) { return@setOnTouchListener true }
                        if (delta < 0) {
                            if (index < deck.lastIndex) { index++; revealed = false; showExample = false; visualVariant = 0; refresh() }
                            else { toast("وصلت إلى نهاية الجولة") }
                        } else {
                            if (index > 0) { index--; revealed = false; showExample = false; visualVariant = 0; refresh() }
                            else { toast("هذه أول بطاقة") }
                        }
                    }
                    true
                }
                else -> true
            }
        }
        fun persistStates() {
            prefs.edit().putStringSet("flashcards_known_v1", knownSet.toSet())
                .putStringSet("flashcards_difficult_v1", difficultSet.toSet()).apply()
        }
        refresh = {
            if (deck.isEmpty()) {
                progress.text = "🎉 انتهيت من جميع الكلمات!"
                progressBar.max = 1; progressBar.progress = 1
                wordText.text = "أحسنت! 🎉"
                translation.text = "تعلمت جميع الكلمات الموجودة في هذه الجولة."
                example.text = "ارجع إلى مركز التعلّم لاختيار جولة جديدة."
                arabicTag.visibility = View.GONE
                actionBar.visibility = View.GONE
                difficult.isEnabled = false
                known.isEnabled = false
                speaker.visibility = View.GONE
            } else {
                index = index.coerceIn(0, deck.lastIndex)
                val w = deck[index]
                val savedFavorites = prefs.getStringSet("flashcards_favorites_v1", emptySet()) ?: emptySet()
                favoriteIconView?.setImageResource(R.drawable.flashcard_favorite)
                if (wordKey(w) in savedFavorites) favoriteIconView?.setColorFilter(0xFFFFD54F.toInt()) else favoriteIconView?.clearColorFilter()
                progress.text = "${index + 1} / ${deck.size}" + if (reviewAllMode) " • مراجعة شاملة" else ""
                progressBar.max = deck.size; progressBar.progress = index + 1
                val baseVisual = flashcardVisual(w.pt, w.ar)
                visual.text = if (visualVariant == 1) alternateFlashcardVisual(baseVisual) else baseVisual
                wordText.text = w.pt
                translation.text = if (revealed) w.ar else if (mode == "listen") "استمع أولًا، ثم حاول تذكّر المعنى" else "تذكّر المعنى ثم اضغط إظهار الترجمة"
                arabicTag.visibility = if (revealed) View.VISIBLE else View.GONE
                example.text = if (showExample && revealed && w.examplePt.isNotBlank()) "${w.examplePt}\n${w.exampleAr}" else ""
                revealLabel.text = if (revealed) "إخفاء الترجمة" else "إظهار الترجمة"
                exampleLabel.text = if (showExample) "إخفاء المثال" else "مثال"
                actionBar.visibility = View.VISIBLE; speaker.visibility = View.VISIBLE
                difficult.isEnabled = !reviewAllMode && mode != "review"
                known.isEnabled = true
                example.visibility = if (showExample && revealed && w.examplePt.isNotBlank()) View.VISIBLE else View.GONE
            }
        }
        difficult.setOnClickListener {
            if (deck.isNotEmpty() && !reviewAllMode) {
                val w = deck[index]; val key = wordKey(w)
                difficultSet.add(key); knownSet.remove(key); persistStates()
                // Remove this card from the current queue; it will return after the new words.
                deck.removeAt(index)
                if (index >= deck.size) index = maxOf(0, deck.size - 1)
                revealed = false; showExample = false; visualVariant = 0; refresh()
            }
        }
        known.setOnClickListener {
            if (deck.isNotEmpty()) {
                val w = deck[index]; val key = wordKey(w)
                knownSet.add(key); difficultSet.remove(key); persistStates()
                val today = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(java.util.Date())
                if (prefs.getString("flashcards_goal_date", "") != today) prefs.edit().putString("flashcards_goal_date", today).putInt("flashcards_goal_count", 0).apply()
                prefs.edit().putInt("flashcards_goal_count", prefs.getInt("flashcards_goal_count", 0) + 1).apply()
                deck.removeAt(index)
                if (index >= deck.size) index = maxOf(0, deck.size - 1)
                revealed = false; showExample = false; visualVariant = 0; refresh()
            }
        }
        refresh()
        // The flashcard session is a fixed full-screen page. Swipes on the card
        // navigate between words; the page itself must not become vertically scrollable.
        showLearningGame(panel)
    }

    private fun alternateFlashcardVisual(base: String): String = when (base) {
        "🏠" -> "🏡"
        "🍎" -> "🍏"
        "🍌" -> "🍌✨"
        "🍊" -> "🍊✨"
        "🍓" -> "🍓✨"
        "🍇" -> "🍇✨"
        "🍅" -> "🍅✨"
        "🥕" -> "🥕✨"
        "🧅" -> "🧅✨"
        "🥔" -> "🥔✨"
        "🚗" -> "🚙"
        "📚" -> "📖"
        else -> "$base ✨"
    }

    private fun flashcardVisual(pt: String, ar: String): String {
        val value = (pt + " " + ar).lowercase(Locale.ROOT)
        return when {
            listOf("maçã", "تفاح", "apple").any { value.contains(it) } -> "🍎"
            listOf("banana", "موز").any { value.contains(it) } -> "🍌"
            listOf("laranja", "برتقال", "orange").any { value.contains(it) } -> "🍊"
            listOf("morango", "فراولة").any { value.contains(it) } -> "🍓"
            listOf("uva", "عنب").any { value.contains(it) } -> "🍇"
            listOf("tomate", "طماطم").any { value.contains(it) } -> "🍅"
            listOf("cenoura", "جزر").any { value.contains(it) } -> "🥕"
            listOf("cebola", "بصل").any { value.contains(it) } -> "🧅"
            listOf("batata", "بطاطا").any { value.contains(it) } -> "🥔"
            listOf("aluno", "aluna", "طالب", "طالبة").any { value.contains(it) } -> "🧑‍🎓"
            listOf("professor", "professora", "أستاذ", "أستاذة").any { value.contains(it) } -> "👩‍🏫"
            listOf("casa", "منزل", "بيت").any { value.contains(it) } -> "🏠"
            listOf("carro", "سيارة").any { value.contains(it) } -> "🚗"
            listOf("livro", "كتاب").any { value.contains(it) } -> "📚"
            listOf("água", "ماء").any { value.contains(it) } -> "💧"
            listOf("sol", "شمس").any { value.contains(it) } -> "☀️"
            listOf("gato", "قط").any { value.contains(it) } -> "🐈"
            listOf("cão", "cachorro", "كلب").any { value.contains(it) } -> "🐕"
            else -> "✨"
        }
    }

    /** Pair It: responsive, polished matching game. Only this game's layout is customized here. */
    private fun startPairIt() {
        val uniqueWords = words.distinctBy { "${it.pt.trim().lowercase(Locale.ROOT)}|${it.ar.trim().lowercase(Locale.ROOT)}" }
        if (uniqueWords.size < 2) { toast("أضف كلمتين على الأقل لبدء اللعبة"); return }

        val dark = prefs.getBoolean("home_dark", false)
        val panelBg = if (dark) 0xFF0B1220.toInt() else 0xFFF4F7FC.toInt()
        val cardBg = if (dark) 0xFF1B2B43.toInt() else Color.WHITE
        val ink = if (dark) 0xFFF8FAFC.toInt() else 0xFF172554.toInt()
        val muted = if (dark) 0xFFB8C7DC.toInt() else 0xFF64748B.toInt()
        val blue = 0xFF1685FF.toInt()
        val green = 0xFF16A34A.toInt()
        val red = 0xFFEF4444.toInt()
        val amber = 0xFFF59E0B.toInt()
        val roundSize = minOf(5, uniqueWords.size)
        var roundWords = uniqueWords.shuffled().take(roundSize)
        var score = 0
        var mistakes = 0
        val matched = mutableSetOf<Int>()
        val selected = mutableListOf<Int>()
        var locked = false

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = rounded(panelBg, 26)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(13), dp(12), dp(13))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFF0EA5E9.toInt(), 0xFF4F46E5.toInt())).apply { cornerRadius = dp(22).toFloat() }
        }
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(TextView(this).apply {
            text = "🧩  طابق الأزواج"; textSize = 21f; setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        titleCol.addView(TextView(this).apply {
            text = "Pair It · تعلّم باللعب"; textSize = 12f; setTextColor(0xFFE0ECFF.toInt())
            setPadding(0, dp(3), 0, 0)
        })
        header.addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f))
        val closeTop = TextView(this).apply {
            text = "×"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = rounded(0x33203050, 18); setPadding(dp(15), dp(4), dp(15), dp(4))
            setOnClickListener { returnToLearningHub() }
        }
        header.addView(closeTop)
        panel.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        // Three compact score tiles keep the numbers readable in both LTR and RTL layouts.
        val metrics = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun metricTile(caption: String, color: Int): Pair<LinearLayout, TextView> {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; elevation = dp(3).toFloat()
                setPadding(dp(5), dp(8), dp(5), dp(8)); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (dark) 0xFF213653.toInt() else 0xFFFFFFFF.toInt(), if (dark) 0xFF14243B.toInt() else 0xFFDDEBFF.toInt())).apply { cornerRadius = dp(18).toFloat(); setStroke(dp(1), if (dark) 0xFF29486E.toInt() else 0xFFC4D9F5.toInt()) }
            }
            val value = TextView(this).apply {
                text = "0"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(color)
                setTypeface(null, android.graphics.Typeface.BOLD); maxLines = 1
            }
            box.addView(value)
            box.addView(TextView(this).apply {
                text = caption; textSize = 11f; gravity = Gravity.CENTER; setTextColor(muted)
                setPadding(0, dp(2), 0, 0); maxLines = 1
            })
            return box to value
        }
        val (pairsBox, pairsValue) = metricTile("الأزواج", green)
        val (mistakesBox, mistakesValue) = metricTile("الأخطاء", red)
        val (pointsBox, pointsValue) = metricTile("النقاط", amber)
        listOf(pairsBox, mistakesBox, pointsBox).forEach { metrics.addView(it, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) }) }
        panel.addView(metrics, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = roundSize; progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(green)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(if (dark) 0xFF334155.toInt() else 0xFFDCE6F4.toInt())
        }
        panel.addView(progress, LinearLayout.LayoutParams(-1, dp(7)).apply { setMargins(dp(2), 0, dp(2), dp(10)) })

        // The language-direction label is intentionally omitted to reclaim vertical space.
        val grid = android.widget.GridLayout(this).apply { columnCount = 2; rowCount = roundSize * 2 }
        val tileHeight = if (resources.configuration.screenHeightDp < 760) 68 else if (resources.configuration.screenHeightDp < 850) 74 else 82
        val feedback = TextView(this).apply {
            textSize = 13f; gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)); setTextColor(muted)
            text = "اضغط بطاقتين متطابقتين لإكمال الزوج"; background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (dark) 0xFF152B48.toInt() else 0xFFE4F0FF.toInt(), if (dark) 0xFF0C1B31.toInt() else 0xFFF8FBFF.toInt())).apply { cornerRadius = dp(16).toFloat() }
        }
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun actionButton(label: String, color: Int, click: () -> Unit): TextView = TextView(this).apply {
            text = label; textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD); setPadding(dp(8), dp(13), dp(8), dp(13))
            background = rounded(color, 18); setOnClickListener { click() }
        }
        val restart = actionButton("🔄  جولة جديدة", 0xFF0EA5E9.toInt()) {}
        val close = actionButton("رجوع إلى التعلّم  ×", if (dark) 0xFF334155.toInt() else 0xFF64748B.toInt()) { returnToLearningHub() }
        bottom.addView(restart, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(4), 0) })
        bottom.addView(close, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4), 0, dp(3), 0) })
        panel.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        panel.addView(feedback, LinearLayout.LayoutParams(-1, -2))
        panel.addView(bottom, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })

        fun updateStatus() {
            pairsValue.text = "$score/$roundSize"
            mistakesValue.text = "$mistakes"
            pointsValue.text = "${score * 10}"
            progress.progress = score
            if (matched.size == roundSize * 2) {
                feedback.text = "🏆 أحسنت! أكملت الجولة · ${score * 10} نقطة"
                feedback.setTextColor(green)
            } else if (!locked && selected.isEmpty()) {
                feedback.text = "اضغط بطاقتين متطابقتين لإكمال الزوج"
                feedback.setTextColor(muted)
            }
        }
        fun renderGrid() {
            grid.removeAllViews()
            val stableTiles = mutableListOf<Pair<Word, Boolean>>()
            roundWords.forEach { w -> stableTiles.add(w to true); stableTiles.add(w to false) }
            val order = (grid.tag as? List<Pair<Word, Boolean>>) ?: stableTiles.shuffled()
            grid.tag = order
            order.forEachIndexed { idx, pair ->
                val word = pair.first
                val isPortuguese = pair.second
                val isMatched = idx in matched
                val isSelected = idx in selected
                val fill = when {
                    isMatched -> if (dark) 0xFF123D31.toInt() else 0xFFDCFCE7.toInt()
                    isSelected -> if (dark) 0xFF1D4ED8.toInt() else 0xFFDBEAFE.toInt()
                    else -> cardBg
                }
                val stroke = when {
                    isMatched -> green
                    isSelected -> blue
                    else -> if (dark) 0xFF24364E.toInt() else 0xFFE2E8F0.toInt()
                }
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                    setPadding(dp(7), dp(8), dp(7), dp(8))
                    background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (isMatched) (if (dark) 0xFF14563F.toInt() else 0xFFDCFCE7.toInt()) else if (isSelected) (if (dark) 0xFF2563EB.toInt() else 0xFFDBEAFE.toInt()) else (if (dark) 0xFF223B60.toInt() else 0xFFFFFFFF.toInt()), fill)).apply {
                        cornerRadius = dp(21).toFloat(); setStroke(dp(if (isMatched || isSelected) 2 else 1), stroke)
                    }
                    elevation = if (isMatched) 0f else dp(4).toFloat()
                    isEnabled = !isMatched
                }
                tile.addView(TextView(this).apply {
                    text = when {
                        isMatched -> "✓"
                        isPortuguese -> "🇵🇹  PORTUGUÊS"
                        else -> "العربية"
                    }
                    textSize = 10f; gravity = Gravity.CENTER
                    setTextColor(if (isMatched) green else if (isPortuguese) (if (dark) 0xFF93C5FD.toInt() else 0xFF2563EB.toInt()) else (if (dark) 0xFFFCD34D.toInt() else 0xFFB45309.toInt()))
                    setTypeface(null, android.graphics.Typeface.BOLD)
                })
                tile.addView(TextView(this).apply {
                    text = if (isPortuguese) word.pt else word.ar
                    textSize = if ((if (isPortuguese) word.pt else word.ar).length > 17) 14f else 17f
                    gravity = Gravity.CENTER; setTextColor(if (isMatched) (if (dark) 0xFFBBF7D0.toInt() else 0xFF166534.toInt()) else ink)
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    maxLines = 3; setPadding(0, dp(4), 0, 0)
                }, LinearLayout.LayoutParams(-1, -2))
                tile.alpha = if (isMatched) 0.88f else 1f
                tile.setOnClickListener {
                    if (locked || idx in matched || idx in selected) return@setOnClickListener
                    if (selected.isEmpty()) {
                        selected.add(idx); renderGrid(); return@setOnClickListener
                    }
                    val firstIndex = selected.first()
                    val allTiles = grid.tag as List<Pair<Word, Boolean>>
                    val first = allTiles[firstIndex]
                    val second = allTiles[idx]
                    selected.add(idx)
                    val isPair = first.first.pt.equals(second.first.pt, true) &&
                        first.first.ar.equals(second.first.ar, true) && first.second != second.second
                    if (isPair) {
                        matched.add(firstIndex); matched.add(idx); score++
                        val today = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(java.util.Date())
                        if (prefs.getString("flashcards_goal_date", "") != today) prefs.edit().putString("flashcards_goal_date", today).putInt("flashcards_goal_count", 0).apply()
                        prefs.edit().putInt("flashcards_goal_count", prefs.getInt("flashcards_goal_count", 0) + 1).apply()
                        selected.clear(); updateStatus(); renderGrid()
                    } else {
                        mistakes++; locked = true
                        feedback.text = "ليستا زوجًا متطابقًا — حاول مرة أخرى"
                        feedback.setTextColor(red)
                        renderGrid()
                        Handler(Looper.getMainLooper()).postDelayed({ selected.clear(); locked = false; updateStatus(); renderGrid() }, 700)
                    }
                }
                val lp = android.widget.GridLayout.LayoutParams().apply {
                    width = 0; height = dp(tileHeight)
                    columnSpec = android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f)
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                }
                grid.addView(tile, lp)
            }
            updateStatus()
        }
        restart.setOnClickListener {
            roundWords = uniqueWords.shuffled().take(roundSize)
            score = 0; mistakes = 0; matched.clear(); selected.clear(); locked = false
            grid.tag = null; renderGrid()
        }
        renderGrid()
        showLearningGame(panel)
    }

    /** Guess It: choose the Arabic meaning for a Portuguese word. */
    private fun startGuessIt() {
        val uniqueWords = words.distinctBy { "${it.pt.trim().lowercase(Locale.ROOT)}|${it.ar.trim().lowercase(Locale.ROOT)}" }
        if (uniqueWords.size < 2) { toast("أضف كلمتين على الأقل لبدء اللعبة"); return }
        val deck = uniqueWords.shuffled().take(minOf(10, uniqueWords.size))
        var index = 0
        var score = 0
        var answered = false
        var selectedAnswer: String? = null
        val dark = prefs.getBoolean("home_dark", false)
        val panelBg = if (dark) 0xFF071426.toInt() else 0xFFEAF3FF.toInt()
        val cardBg = if (dark) 0xFF142846.toInt() else Color.WHITE
        val ink = if (dark) 0xFFF8FAFC.toInt() else 0xFF172554.toInt()
        val muted = if (dark) 0xFFB8C7DC.toInt() else 0xFF64748B.toInt()
        val green = 0xFF16A34A.toInt()
        val red = 0xFFEF4444.toInt()
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(panelBg, if (dark) 0xFF0C1B31.toInt() else 0xFFF8FBFF.toInt())).apply { cornerRadius = dp(28).toFloat() } }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(13), dp(10), dp(13)); elevation = dp(6).toFloat()
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF18B8F4.toInt(), 0xFF075DE7.toInt(), 0xFF5638E8.toInt())).apply { cornerRadius = dp(24).toFloat(); setStroke(dp(1), 0x667DD3FC) }
        }
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(TextView(this).apply { text = "🎯 Guess It • خمّن المعنى"; textSize = 20f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) })
        titleCol.addView(TextView(this).apply { text = "اختر الترجمة العربية الصحيحة"; textSize = 12f; setTextColor(0xFFE0F2FE.toInt()); setPadding(0, dp(3), 0, 0) })
        header.addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(makeTile("✕ رجوع", 0xFF143D9C.toInt()) { returnToLearningHub() })
        val progressText = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; setTextColor(muted); setPadding(0, dp(12), 0, dp(6)) }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = deck.size; progress = 1; progressTintList = android.content.res.ColorStateList.valueOf(0xFF22C55E.toInt())
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(if (dark) 0xFF334155.toInt() else 0xFFDCE6F4.toInt())
        }
        val promptCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(14), dp(18), dp(14), dp(18)); elevation = dp(8).toFloat()
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (dark) 0xFF1D3557.toInt() else Color.WHITE, if (dark) 0xFF0C1D35.toInt() else 0xFFEAF4FF.toInt())).apply { cornerRadius = dp(28).toFloat(); setStroke(dp(2), if (dark) 0xFF328BFF.toInt() else 0xFF8EC5FF.toInt()) }
        }
        val visual = TextView(this).apply { textSize = 62f; gravity = Gravity.CENTER; setPadding(dp(6), dp(6), dp(6), dp(6)); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF60A5FA.toInt(), 0xFF2563EB.toInt(), 0xFF102F8F.toInt())).apply { shape = GradientDrawable.OVAL; setStroke(dp(2), 0xFFBFDBFE.toInt()) }; elevation = dp(7).toFloat() }
        val wordText = TextView(this).apply { textSize = 29f; gravity = Gravity.CENTER; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(4), 0, dp(8)) }
        val speaker = makeTile("🔊 استمع إلى النطق", 0xFF0875FF.toInt()) {}.apply { textSize = 16f; elevation = dp(6).toFloat(); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF20BDF9.toInt(), 0xFF0875FF.toInt(), 0xFF1747D0.toInt())).apply { cornerRadius = dp(28).toFloat(); setStroke(dp(2), 0xFF53C8FF.toInt()) } }
        promptCard.addView(visual); promptCard.addView(wordText); promptCard.addView(speaker, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(24), dp(4), dp(24), 0) })
        val optionsTitle = TextView(this).apply { text = "ما المعنى الصحيح؟"; textSize = 17f; gravity = Gravity.CENTER; setTextColor(ink); setPadding(0, dp(12), 0, dp(6)) }
        val optionsGrid = android.widget.GridLayout(this).apply { columnCount = 2 }
        val feedback = TextView(this).apply { textSize = 15f; gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)); visibility = View.GONE }
        val next = makeTile("السؤال التالي ⟶", 0xFF0EA5E9.toInt()) {}
        panel.addView(header); panel.addView(progressText); panel.addView(progress, LinearLayout.LayoutParams(-1, dp(7)).apply { setMargins(dp(3), 0, dp(3), dp(4)) })
        panel.addView(promptCard, marginParams()); panel.addView(optionsTitle); panel.addView(optionsGrid, LinearLayout.LayoutParams(-1, 0, 1f)); panel.addView(feedback); panel.addView(next, marginParams())

        var optionViews = mutableListOf<Button>()
        fun loadQuestion() {
            answered = false; selectedAnswer = null
            val item = deck[index]
            progressText.text = "السؤال ${index + 1} / ${deck.size}     •     ⭐ $score نقطة"
            progress.progress = index + 1
            visual.text = flashcardVisual(item.pt, item.ar)
            wordText.text = item.pt
            speaker.setOnClickListener { speak(item.pt) }
            feedback.visibility = View.GONE
            optionsGrid.removeAllViews(); optionViews.clear()
            val alternatives = (uniqueWords.filter { it.pt != item.pt && it.ar != item.ar }.map { it.ar }.distinct().shuffled().take(3) + item.ar).shuffled()
            alternatives.forEach { option ->
                val button = Button(this).apply {
                    text = option; textSize = 19f; isAllCaps = false; setTextColor(ink); gravity = Gravity.CENTER
                    background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (dark) 0xFF25466F.toInt() else Color.WHITE, if (dark) 0xFF142846.toInt() else 0xFFEAF4FF.toInt())).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), if (dark) 0xFF315B8C.toInt() else 0xFFB8D8FF.toInt()) }
                    minHeight = dp(74); setPadding(dp(8), dp(8), dp(8), dp(8)); elevation = dp(5).toFloat(); stateListAnimator = null
                    setOnClickListener {
                        if (answered) return@setOnClickListener
                        answered = true; selectedAnswer = option
                        val correct = option == item.ar
                        if (correct) {
                            score++
                            val today = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(java.util.Date())
                            if (prefs.getString("flashcards_goal_date", "") != today) prefs.edit().putString("flashcards_goal_date", today).putInt("flashcards_goal_count", 0).apply()
                            prefs.edit().putInt("flashcards_goal_count", prefs.getInt("flashcards_goal_count", 0) + 1).apply()
                        }
                        feedback.visibility = View.VISIBLE
                        feedback.text = if (correct) "✅ إجابة صحيحة! ${item.pt} = ${item.ar}" else "💡 الإجابة الصحيحة: ${item.ar}"
                        feedback.setTextColor(if (correct) green else red)
                        feedback.background = rounded(if (correct) (if (dark) 0xFF14532D.toInt() else 0xFFDCFCE7.toInt()) else (if (dark) 0xFF7F1D1D.toInt() else 0xFFFEE2E2.toInt()), 14)
                        optionViews.forEach { b ->
                            b.isEnabled = false
                            when (b.text.toString()) {
                                item.ar -> { b.background = rounded(if (dark) 0xFF166534.toInt() else 0xFFDCFCE7.toInt(), 16); b.setTextColor(if (dark) 0xFFDCFCE7.toInt() else 0xFF166534.toInt()) }
                                option -> if (!correct) { b.background = rounded(if (dark) 0xFF7F1D1D.toInt() else 0xFFFEE2E2.toInt(), 16); b.setTextColor(if (dark) Color.WHITE else 0xFF991B1B.toInt()) }
                            }
                        }
                        progressText.text = "السؤال ${index + 1} / ${deck.size}     •     ⭐ $score نقطة"
                    }
                }
                optionViews.add(button)
                val lp = android.widget.GridLayout.LayoutParams().apply {
                    width = 0; height = dp(76); columnSpec = android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f)
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                }
                optionsGrid.addView(button, lp)
            }
            next.text = if (index == deck.lastIndex) "إنهاء الجولة 🏆" else "السؤال التالي ⟶"
        }
        next.setOnClickListener {
            if (!answered) { toast("اختر إجابة أولًا"); return@setOnClickListener }
            if (index < deck.lastIndex) { index++; loadQuestion() }
            else {
                AlertDialog.Builder(this).setTitle("🏆 انتهت الجولة!")
                    .setMessage("نتيجتك: $score / ${deck.size}\n${if (score == deck.size) "ممتاز! إجابات كاملة." else "واصل التدريب وستتحسن."}")
                    .setPositiveButton("جولة جديدة") { _, _ -> startGuessIt() }
                    .setNegativeButton("العودة إلى التعلّم") { _, _ -> returnToLearningHub() }.show()
            }
        }
        loadQuestion()
        showLearningGame(panel)
    }

    private fun startQuiz() {
        if (words.size < 2) { toast("أضف كلمتين على الأقل لبدء الاختبار"); return }
        val quizWords = words.shuffled().take(minOf(10, words.size))
        var index = 0
        var score = 0
        var answered = false
        val dark = prefs.getBoolean("home_dark", false)
        val panelBg = if (dark) 0xFF101827.toInt() else 0xFFF5F3FF.toInt()
        val cardBg = if (dark) 0xFF202B3C.toInt() else Color.WHITE
        val ink = if (dark) Color.WHITE else 0xFF243B53.toInt()
        val muted = if (dark) 0xFFD8E2F0.toInt() else 0xFF64748B.toInt()
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16); background = rounded(panelBg, 28) }
        lateinit var dialog: AlertDialog
        val topHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(14, 12, 10, 12); background = rounded(0xFF7C3AED.toInt(), 20) }
        val headerTitle = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        headerTitle.addView(TextView(this).apply { text = "🎯 اختبار الكلمات"; textSize = 20f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) })
        headerTitle.addView(TextView(this).apply { text = "اختر الترجمة الصحيحة واجمع النقاط"; textSize = 12f; setTextColor(0xFFF3E8FF.toInt()); setPadding(0, 3, 0, 0) })
        topHeader.addView(headerTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        topHeader.addView(makeTile("✕", 0xFF5B21B6.toInt()) { dialog.dismiss() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panel.addView(topHeader, marginParams())
        val progress = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; setTextColor(muted); setPadding(0, 8, 0, 8) }
        val progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = quizWords.size; this.progress = 1; progressTintList = android.content.res.ColorStateList.valueOf(0xFF8B5CF6.toInt()); progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xFFE9D5FF.toInt()) }
        val questionCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(18, 18, 18, 18); background = rounded(cardBg, 22) }
        val prompt = TextView(this).apply { text = "ما ترجمة هذه الكلمة؟"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(muted) }
        val word = TextView(this).apply { textSize = 30f; gravity = Gravity.CENTER; setTextColor(if (dark) Color.WHITE else 0xFF4C1D95.toInt()); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 12, 0, 12) }
        val sound = makeTile("🔊 استمع", 0xFF7C3AED.toInt()) { speak(word.text.toString()) }
        questionCard.addView(prompt); questionCard.addView(word); questionCard.addView(sound)
        val optionsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val feedback = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER; setPadding(10, 10, 10, 10); visibility = View.GONE }
        val next = makeTile("التالي ⟶", 0xFF1769E8.toInt()) {}
        panel.addView(progress); panel.addView(progressBar); panel.addView(questionCard, marginParams()); panel.addView(optionsBox); panel.addView(feedback); panel.addView(next)
        dialog = AlertDialog.Builder(this).setView(panel).create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        fun loadQuestion() {
            answered = false
            val item = quizWords[index]
            progress.text = "السؤال ${index + 1} من ${quizWords.size} • النتيجة $score"
            progressBar.progress = index + 1
            word.text = item.pt
            feedback.visibility = View.GONE
            optionsBox.removeAllViews()
            val options = (words.filter { it.pt != item.pt }.shuffled().take(3).map { it.ar } + item.ar).distinct().shuffled()
            options.forEachIndexed { optionIndex, option ->
                val button = makeTile("${('A'.code + optionIndex).toChar()}     $option", 0xFFFFFFFF.toInt()) {}.apply { setTextColor(ink); textSize = 17f; gravity = Gravity.CENTER_VERTICAL; background = rounded(cardBg, 16) }
                button.setOnClickListener {
                    if (answered) return@setOnClickListener
                    answered = true
                    val correct = option == item.ar
                    if (correct) score++
                    feedback.visibility = View.VISIBLE
                    feedback.text = if (correct) "✅ صحيح! ${item.pt} = ${item.ar}" else "❌ الإجابة الصحيحة: ${item.ar}"
                    feedback.setTextColor(if (correct) 0xFF047857.toInt() else 0xFFB91C1C.toInt())
                    feedback.background = rounded(if (correct) 0xFFD1FAE5.toInt() else 0xFFFEE2E2.toInt(), 14)
                    for (childIndex in 0 until optionsBox.childCount) { val child = optionsBox.getChildAt(childIndex); if (child is Button) child.isEnabled = false }
                    button.background = rounded(if (correct) 0xFFD1FAE5.toInt() else 0xFFFEE2E2.toInt(), 16)
                }
                optionsBox.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 4, 0, 4) })
            }
            next.text = if (index == quizWords.lastIndex) "إنهاء الاختبار" else "التالي ⟶"
        }
        next.setOnClickListener {
            if (!answered) { toast("اختر إجابة أولًا"); return@setOnClickListener }
            if (index < quizWords.lastIndex) { index++; loadQuestion() }
            else { AlertDialog.Builder(this).setTitle("انتهى الاختبار 🎉").setMessage("نتيجتك: $score من ${quizWords.size}").setPositiveButton("حسنًا", null).show(); dialog.dismiss() }
        }
        loadQuestion(); dialog.show()
    }

    private fun speak(text: String) {
        if (!ttsReady) { toast("الصوت البرتغالي غير متاح حاليًا على الهاتف"); return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "word-${System.currentTimeMillis()}")
    }

    private fun importWords() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-excel", "text/csv", "text/comma-separated-values", "text/plain"
            ))
        }
        startActivityForResult(intent, importRequest)
    }

    private fun normalizeCategoryText(value: String): String =
        java.text.Normalizer.normalize(value.trim().lowercase(Locale.ROOT), java.text.Normalizer.Form.NFD)
            .replace("\\p{M}+".toRegex(), "")
            .replace("[^\\p{L}\\p{N}]+".toRegex(), " ")
            .trim()

    private fun parseImportedCategory(value: String): String {
        val v = normalizeCategoryText(value)
        if (v.isBlank()) return ""
        val tokens = v.split(Regex("\\s+"))
        return when {
            tokens.any { it in setOf("verb", "verbs", "verbo", "verbos") } || v == "فعل" || v.contains("افعال") -> "الأفعال"
            tokens.any { it in setOf("adjective", "adjectives", "adjetivo", "adjetivos") } || v == "صفة" || v.contains("صفات") -> "الصفات"
            tokens.any { it in setOf("noun", "nouns", "name", "nome", "nomes", "substantivo", "substantivos") } ||
                v == "اسم" || v.contains("اسماء") || v.startsWith("اسم ") -> "الأسماء"
            else -> ""
        }
    }

    private fun importFromUri(uri: Uri) {
        try {
            val name = (contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else ""
            } ?: "").lowercase(Locale.ROOT)
            val rows = if (name.endsWith(".xlsx")) readXlsx(uri) else readDelimited(uri)
            if (rows.isEmpty()) { toast("لم أجد صفوفًا في الملف"); return }
            val first = rows.first().map { normalizeCategoryText(it) }
            val categoryHeader = { h: String ->
                h.contains("category") || h.contains("categoria") || h.contains("part of speech") ||
                    h.contains("word type") || h.contains("tipo de palavra") || h.contains("classe gramatical") || h.contains("classificacao") ||
                    h == "classe" || h == "pos" || h.contains("نوع الكلمة") || h.contains("التصنيف") || h.contains("الفئة") || h.contains("النوع") || h.contains("نوع") || h.contains("صنف") || h == "القسم"
            }
            val headerLikely = first.any { h ->
                h.contains("portugu") || h == "pt" || h.contains("العربي") || h == "ar" ||
                    h.contains("ترجم") || categoryHeader(h)
            }
            var ptCol = 0; var arCol = 1; var exPtCol = 2; var exArCol = 3; var categoryCol = -1
            var startRow = 0
            if (headerLikely) {
                fun findCol(predicate: (String) -> Boolean, fallback: Int): Int = first.indexOfFirst(predicate).let { if (it >= 0) it else fallback }
                ptCol = findCol({ it.contains("portugu") || it == "pt" || it == "portugues" }, 0)
                arCol = findCol({ it.contains("العربي") || it == "ar" || it.contains("ترجم") }, if (ptCol == 0) 1 else 0)
                exPtCol = findCol({ it.contains("exemplo") || (it.contains("مثال") && it.contains("برتغ")) }, 2)
                exArCol = findCol({ it.contains("traducao do exemplo") || it.contains("ترجمة المثال") }, 3)
                categoryCol = findCol(categoryHeader, -1)
                startRow = 1
            }
            var added = 0; var updated = 0; var importedNouns = 0; var importedVerbs = 0; var importedAdjectives = 0
            var invalidCategoryRows = 0; var guessedRows = 0
            // Build the index once: repeated indexOfFirst scans made large imports unnecessarily slow.
            val wordIndex = HashMap<String, Int>(words.size + rows.size)
            words.forEachIndexed { index, existing -> wordIndex[existing.pt.trim().lowercase(Locale.ROOT)] = index }
            for (r in startRow until rows.size) {
                val row = rows[r]
                val pt = row.getOrNull(ptCol)?.trim().orEmpty()
                val ar = row.getOrNull(arCol)?.trim().orEmpty()
                if (pt.isBlank() || ar.isBlank()) continue
                val exPt = row.getOrNull(exPtCol)?.trim().orEmpty()
                val exAr = row.getOrNull(exArCol)?.trim().orEmpty()
                val rawCategory = if (categoryCol >= 0) row.getOrNull(categoryCol)?.trim().orEmpty() else ""
                val explicitCategory = parseImportedCategory(rawCategory)
                // If a category column exists, never silently guess when its value is missing/invalid.
                // This prevents a typo in the Excel category from moving a word into the wrong list.
                if (categoryCol >= 0 && explicitCategory.isBlank()) { invalidCategoryRows++; continue }
                val importedCategory = if (categoryCol >= 0) explicitCategory else guessWordCategory(pt).also { guessedRows++ }
                val key = pt.trim().lowercase(Locale.ROOT)
                val index = wordIndex[key]
                val word = Word(pt, ar, exPt, exAr, importedCategory, categoryCol >= 0)
                if (index != null) { words[index] = word; updated++ } else { wordIndex[key] = words.size; words.add(word); added++ }
                when (importedCategory) {
                    "الأسماء" -> importedNouns++
                    "الأفعال" -> importedVerbs++
                    "الصفات" -> importedAdjectives++
                }
            }
            saveWords()
            if (showingMyWords) showMyWords() else buildUi()
            updateStatus()
            val summary = "استيراد: +$added، تحديث $updated | أسماء $importedNouns، أفعال $importedVerbs، صفات $importedAdjectives"
            when {
                invalidCategoryRows > 0 -> android.app.AlertDialog.Builder(this)
                    .setTitle("مراجعة تصنيف Excel")
                    .setMessage("$summary\n\nتم تجاوز $invalidCategoryRows صفًا لأن خانة نوع الكلمة فارغة أو غير معروفة. استخدم الأسماء/الأفعال/الصفات أو Noun/Verb/Adjective أو Nome/Verbo/Adjetivo.")
                    .setPositiveButton("حسنًا", null).show()
                guessedRows > 0 -> android.app.AlertDialog.Builder(this)
                    .setTitle("تم الاستيراد مع تصنيف تلقائي")
                    .setMessage("$summary\n\nلم يتضمن الملف عمود نوع الكلمة؛ لذلك تم تخمين التصنيف تلقائيًا وقد يحتاج بعض الكلمات إلى مراجعة. للحصول على تصنيف موثوق، أضف عمودًا باسم نوع الكلمة وحدد نوع كل كلمة في Excel.")
                    .setPositiveButton("حسنًا", null).show()
                else -> toast(summary)
            }
        } catch (e: Exception) {
            toast("تعذر استيراد الملف. استخدم Excel بصيغة .xlsx أو CSV")
        }
    }

    private fun readDelimited(uri: Uri): List<List<String>> {
        val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: return emptyList()
        val lines = text.removePrefix("\uFEFF").split(Regex("\r?\n")).filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList()
        val delimiter = listOf('\t', ';', ',').maxByOrNull { d -> lines.first().count { it == d } } ?: ','
        return lines.map { line ->
            val cells = mutableListOf<String>(); val cell = StringBuilder(); var quoted = false; var i = 0
            while (i < line.length) {
                val ch = line[i]
                if (ch == '"') {
                    if (quoted && i + 1 < line.length && line[i + 1] == '"') { cell.append('"'); i++ } else quoted = !quoted
                } else if (ch == delimiter && !quoted) { cells.add(cell.toString()); cell.setLength(0) } else cell.append(ch)
                i++
            }
            cells.add(cell.toString()); cells
        }
    }

    private fun readXlsx(uri: Uri): List<List<String>> {
        val entries = mutableMapOf<String, ByteArray>()
        val input = contentResolver.openInputStream(uri) ?: return emptyList()
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && (entry.name == "xl/sharedStrings.xml" || entry.name == "xl/worksheets/sheet1.xml")) {
                    val out = ByteArrayOutputStream(); zip.copyTo(out); entries[entry.name] = out.toByteArray()
                }
                entry = zip.nextEntry
            }
        }
        val sheet = entries["xl/worksheets/sheet1.xml"] ?: return emptyList()
        val shared = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) } ?: emptyList()
        val result = mutableListOf<List<String>>()
        val parser = Xml.newPullParser(); parser.setInput(ByteArrayInputStream(sheet), "UTF-8")
        var event = parser.eventType; var inCell = false; var cellType = ""; var cellRef = ""; var value = ""; var inValue = false; var row = mutableMapOf<Int, String>()
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> row = mutableMapOf()
                    "c" -> { inCell = true; cellType = parser.getAttributeValue(null, "t") ?: ""; cellRef = parser.getAttributeValue(null, "r") ?: ""; value = "" }
                    "v", "t" -> if (inCell) inValue = true
                }
                XmlPullParser.TEXT -> if (inValue) value += parser.text
                XmlPullParser.END_TAG -> when (parser.name) {
                    "v", "t" -> inValue = false
                    "c" -> {
                        val col = cellRef.takeWhile { it.isLetter() }.fold(0) { acc, ch -> acc * 26 + (ch.uppercaseChar() - 'A' + 1) } - 1
                        val decoded = if (cellType == "s") shared.getOrNull(value.toIntOrNull() ?: -1).orEmpty() else value
                        if (col >= 0) row[col] = decoded
                        inCell = false
                    }
                    "row" -> if (row.isNotEmpty()) result.add((0..(row.keys.maxOrNull() ?: 0)).map { row[it].orEmpty() })
                }
            }
            event = parser.next()
        }
        return result
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val out = mutableListOf<String>(); val parser = Xml.newPullParser(); parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        var event = parser.eventType; var inSi = false; var inText = false; val current = StringBuilder()
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) { "si" -> { inSi = true; current.setLength(0) }; "t" -> if (inSi) inText = true }
                XmlPullParser.TEXT -> if (inSi && inText) current.append(parser.text)
                XmlPullParser.END_TAG -> when (parser.name) { "t" -> inText = false; "si" -> { out.add(current.toString()); inSi = false } }
            }
            event = parser.next()
        }
        return out
    }

    private fun exportWords() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_TITLE, "PortugueseWords.xlsx")
        }
        startActivityForResult(intent, exportRequest)
    }

    private fun xmlCell(value: String): String = value
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")

    private fun exportWordsXlsx(output: java.io.OutputStream) {
        val rows = mutableListOf(listOf("Português", "العربية", "نوع الكلمة", "Exemplo", "ترجمة المثال"))
        // Keep categories explicit and export each Portuguese headword only once.
        words.distinctBy { it.pt.trim().lowercase(Locale.ROOT) }.forEach { word ->
            rows.add(listOf(word.pt, word.ar, wordCategory(word), word.examplePt, word.exampleAr))
        }
        val letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        val sheet = buildString {
            append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
            append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
            rows.forEachIndexed { rowIndex, row ->
                append("<row r=\"${rowIndex + 1}\">")
                row.forEachIndexed { colIndex, value ->
                    val col = if (colIndex < letters.length) letters[colIndex].toString() else "A"
                    append("<c r=\"$col${rowIndex + 1}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">")
                    append(xmlCell(value))
                    append("</t></is></c>")
                }
                append("</row>")
            }
            append("</sheetData></worksheet>")
        }
        ZipOutputStream(output).use { zip ->
            fun entry(name: String, content: String) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(content.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
            entry("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
            entry("_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            entry("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Português" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            entry("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
            entry("xl/worksheets/sheet1.xml", sheet)
        }
    }

    @Deprecated("Deprecated in Android but kept for compatibility with target devices")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == importRequest && resultCode == RESULT_OK && data?.data != null) {
            importFromUri(data.data!!)
        }
        if (requestCode == exportRequest && resultCode == RESULT_OK && data?.data != null) {
            try {
                val output = contentResolver.openOutputStream(data.data!!)
                    ?: throw IllegalStateException("تعذر فتح الملف للحفظ")
                exportWordsXlsx(output)
                toast("تم تصدير ملف Excel مع التصنيف بنجاح")
            } catch (e: Exception) { toast("تعذر التصدير: ${e.message}") }
        }
    }

    private fun loadWords() {
        words.clear()
        val arr = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) { val o = arr.optJSONObject(i) ?: continue; words.add(Word(o.optString("pt"), o.optString("ar"), o.optString("examplePt"), o.optString("exampleAr"), o.optString("category").ifBlank { guessWordCategory(o.optString("pt")) }, o.optBoolean("categoryManual", false))) }
    }
    private fun saveWords() { val arr = JSONArray(); words.forEach { arr.put(JSONObject().put("pt", it.pt).put("ar", it.ar).put("examplePt", it.examplePt).put("exampleAr", it.exampleAr).put("category", wordCategory(it)).put("categoryManual", it.categoryManual)) }; prefs.edit().putString("items", arr.toString()).apply() }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
    }
    private fun requestExactAlarmThenSchedule() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotificationPermission()
            toast("اسمح بالإشعارات ثم اضغط تشغيل مرة أخرى")
            return
        }
        prefs.edit().putBoolean("reminders_enabled", true).apply()
        ReminderScheduler.scheduleNext(this)
        updateStatus("التذكير يعمل دون توقف طوال 24 ساعة: ${if (prefs.getInt("interval_minutes", 5) == -10) "كل 10 ثوانٍ" else "كل ${prefs.getInt("interval_minutes", 5)} دقيقة"}")
        if (Build.VERSION.SDK_INT >= 23) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                AlertDialog.Builder(this)
                    .setTitle("السماح بالعمل في الخلفية")
                    .setMessage("لتحسين انتظام التذكيرات والشاشة مقفلة، اسمح للتطبيق بتجاوز تحسين البطارية. قد يزيد ذلك استهلاك البطارية، خصوصًا عند اختيار تذكير كل دقيقة.")
                    .setPositiveButton("فتح الإعدادات") { _, _ ->
                        try {
                            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                        } catch (_: Exception) {
                            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                        }
                    }
                    .setNegativeButton("لاحقًا", null)
                    .show()
            }
        }
    }
    private fun updateStatus(message: String? = null) { status?.text = message ?: "عدد الكلمات المحفوظة: ${words.size}\nالتذكير: ${if (prefs.getInt("interval_minutes", 5) == -10) "كل 10 ثوانٍ" else "كل ${prefs.getInt("interval_minutes", 5)} دقيقة"} طوال اليوم" }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

object ReminderScheduler {
    fun scheduleNext(context: Context) {
        val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("reminders_enabled", false)) return
        val intent = Intent(context, ReminderService::class.java).setAction(ReminderService.ACTION_RESCHEDULE)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        } catch (_: Exception) {
            // The UI will remain usable; the user can tap Start again if Android blocks service startup.
        }
    }

    fun cancel(context: Context) {
        context.stopService(Intent(context, ReminderService::class.java))
        val alarmIntent = PendingIntent.getBroadcast(context, 12, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(alarmIntent)
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(1001)
    }
}

class ReminderService : Service() {
    companion object {
        const val ACTION_RESCHEDULE = "com.bekri.wordreminder.RESCHEDULE"
        private const val SERVICE_NOTIFICATION_ID = 2001
        private const val WORD_NOTIFICATION_ID = 1001
        private const val SERVICE_CHANNEL = "reminder_service"
        private const val WORD_CHANNEL = "words"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null
    private var index = 0
    private val tick = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences("words", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("reminders_enabled", false)) {
                stopSelf()
                return
            }
            // Continuous mode: reminders run 24 hours a day until the user turns them off.
            // Do not pause at 22:00 or wait until 08:00.
            val arr = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
            val knownKeys = prefs.getStringSet("flashcards_known_v1", emptySet())!!.toSet()
            val difficultKeys = prefs.getStringSet("flashcards_difficult_v1", emptySet())!!.toSet()
            val selectedKeys = prefs.getStringSet("notification_selected_word_keys", emptySet())!!.toSet()
            val mode = prefs.getString("notification_word_mode", "all") ?: "all"
            val eligibleItems = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.filter { item ->
                val key = notificationWordKey(item.optString("pt"), item.optString("ar"))
                when (mode) {
                    "unknown" -> key in difficultKeys
                    "known" -> key in knownKeys
                    "difficult" -> key in difficultKeys
                    "selected" -> key in selectedKeys
                    else -> true
                }
            }.distinctBy { notificationWordKey(it.optString("pt"), it.optString("ar")) }
            if (eligibleItems.isNotEmpty()) {
                if (index >= eligibleItems.size) index = 0
                val item = eligibleItems[index]
                if (item != null) {
                    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                    val open = PendingIntent.getActivity(this@ReminderService, 2, Intent(this@ReminderService, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    val ptWord = item.optString("pt").ifBlank { "Palavra portuguesa" }
                    val arWord = item.optString("ar")
                    val speakIntent = Intent(this@ReminderService, NotificationSpeakReceiver::class.java)
                        .setAction(NotificationSpeakReceiver.ACTION_SPEAK)
                        .putExtra(NotificationSpeakReceiver.EXTRA_TEXT, ptWord)
                    val speakPending = PendingIntent.getBroadcast(this@ReminderService, 3100 + index, speakIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this@ReminderService, WORD_CHANNEL) else android.app.Notification.Builder(this@ReminderService)
                    val largeIcon = android.graphics.BitmapFactory.decodeResource(resources, R.drawable.portugal_book_icon)
                    // Custom two-line notification: Portuguese first, Arabic meaning below,
                    // with the pronunciation button directly beside the Arabic translation.
                    val notificationView = android.widget.RemoteViews(packageName, R.layout.notification_word).apply {
                        setTextViewText(R.id.notificationPortugueseWord, "🇵🇹 $ptWord")
                        setTextViewText(R.id.notificationArabicMeaning, arWord.ifBlank { "لا توجد ترجمة عربية" })
                        setOnClickPendingIntent(R.id.notificationSpeakButton, speakPending)
                    }
                    val notification = builder.setSmallIcon(R.drawable.ic_notification)
                        .setLargeIcon(largeIcon)
                        .setColor(0xFF1769E8.toInt())
                        .setContentTitle("🇵🇹 $ptWord")
                        .setContentText(arWord.ifBlank { "لا توجد ترجمة عربية" })
                        .setCustomContentView(notificationView)
                        .setCustomBigContentView(notificationView)
                        .setContentIntent(open)
                        .setAutoCancel(false)
                        .build()
                    // Cancel first so Android treats each reminder as a fresh alert, even for a one-word list.
                    manager.cancel(WORD_NOTIFICATION_ID)
                    manager.notify(WORD_NOTIFICATION_ID, notification)
                    index = (index + 1) % eligibleItems.size
                    prefs.edit().putInt("next_index", index).apply()
                }
            } else {
                // Never leave a previous/all-words notification visible when the chosen filter has no matches.
                (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(WORD_NOTIFICATION_ID)
            }
            val minutes = prefs.getInt("interval_minutes", 5)
            handler.postDelayed(this, if (minutes == -10) 10_000L else minutes.coerceIn(1, 60) * 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WordReminder:ReminderLoop").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
    }

    private fun scheduleMorningWake(at: Long) {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java).setAction("com.bekri.wordreminder.MORNING_WAKE")
        val pi = PendingIntent.getBroadcast(this, 13, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else alarm.setExact(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: SecurityException) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            manager.createNotificationChannel(android.app.NotificationChannel(SERVICE_CHANNEL, "حالة التذكير", android.app.NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
            manager.createNotificationChannel(android.app.NotificationChannel(WORD_CHANNEL, "تذكير الكلمات", android.app.NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, SERVICE_CHANNEL) else android.app.Notification.Builder(this)
        val ongoing = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("كلمات البرتغالية")
            .setContentText("التذكير نشط في الخلفية")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(SERVICE_NOTIFICATION_ID, ongoing, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(SERVICE_NOTIFICATION_ID, ongoing)
        }
        handler.removeCallbacks(tick)
        val prefs = getSharedPreferences("words", Context.MODE_PRIVATE)
        if (prefs.getBoolean("reminders_enabled", false)) {
            acquireWakeLock()
            index = prefs.getInt("next_index", 0).coerceAtLeast(0)
            val minutes = prefs.getInt("interval_minutes", 5)
            handler.postDelayed(tick, if (minutes == -10) 10_000L else minutes.coerceIn(1, 60) * 60_000L)
        } else {
            stopSelf()
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Keep the user-enabled reminder service running when the app is swiped from Recents.
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(SERVICE_NOTIFICATION_ID)
        }
        releaseWakeLock()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}

class ReminderReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
        if (prefs.getBoolean("reminders_enabled", false) && intent?.action == "com.bekri.wordreminder.MORNING_WAKE") {
            ReminderScheduler.scheduleNext(context)
        }
    }
}

class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
            if (prefs.getBoolean("reminders_enabled", false)) ReminderScheduler.scheduleNext(context)
        }
    }
}


/** Speaks the Portuguese word when the user taps the notification's audio action. */
class NotificationSpeakReceiver : android.content.BroadcastReceiver() {
    companion object {
        const val ACTION_SPEAK = "com.bekri.wordreminder.NOTIFICATION_SPEAK"
        const val EXTRA_TEXT = "spoken_text"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val text = intent?.getStringExtra(EXTRA_TEXT)?.trim().orEmpty()
        if (text.isBlank()) return
        val pending = goAsync()
        val appContext = context.applicationContext
        lateinit var speech: TextToSpeech
        speech = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val lang = speech.setLanguage(Locale("pt", "PT"))
                if (lang != TextToSpeech.LANG_MISSING_DATA && lang != TextToSpeech.LANG_NOT_SUPPORTED) {
                    speech.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { android.os.Handler(Looper.getMainLooper()).post { speech.shutdown(); pending.finish() } }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { android.os.Handler(Looper.getMainLooper()).post { speech.shutdown(); pending.finish() } }
                    })
                    speech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "notification-word-${System.currentTimeMillis()}")
                } else {
                    speech.shutdown(); pending.finish()
                }
            } else {
                speech.shutdown(); pending.finish()
            }
        }

    }
}
