# LusoPro 3D Android — v1.0.1

## ما تم إصلاحه
النسخة السابقة كانت موقع HTML/CSS/JavaScript فقط، لذلك فشل AndroidForge لأنه لم يجد ملفات Gradle.
هذه الحزمة أصبحت مشروع Android/Gradle فعليًا، وتحتوي على واجهة الويب داخل `app/src/main/assets/www`.

## التقنية
- Android: Kotlin + Android Gradle Plugin.
- واجهة التطبيق: HTML5 + CSS3 + JavaScript.
- تشغيل الواجهة: Android WebView.
- النطق: Android TextToSpeech مع Locale `pt-PT` (يعتمد توفر صوت البرتغالية الأوروبية على جهاز المستخدم).
- العمل دون إنترنت: ملفات الواجهة مضمنة داخل APK؛ لا يحتاج التطبيق إلى اتصال لفتح الواجهة.

## البناء
افتح المجلد الجذر الذي يحتوي `settings.gradle` في Android Studio، أو ارفع ZIP إلى AndroidForge.
المهمة المتوقعة: `assembleDebug`.
ملف APK المتوقع بعد نجاح البناء: `app/build/outputs/apk/debug/app-debug.apk`.

## سهولة التعديل
- `app/src/main/assets/www/index.html`: بنية الواجهة.
- `app/src/main/assets/www/style.css`: الألوان والتصميم والمؤثرات.
- `app/src/main/assets/www/app.js`: الوظائف والمفردات والاختبارات.
- `app/src/main/java/com/lusopro/threed/MainActivity.kt`: ربط Android وWebView والنطق.
- `app/build.gradle`: إعدادات نسخة Android.

## حدود النسخة
هذه نسخة Android أولية لتصحيح مشكلة Gradle وتشغيل الواجهة. القاموس ما زال عينة صغيرة وليس 20,000 كلمة. لم يتم اختبار APK فعليًا في بيئة البناء هذه؛ يجب تشغيل AndroidForge للتحقق من التجميع.
