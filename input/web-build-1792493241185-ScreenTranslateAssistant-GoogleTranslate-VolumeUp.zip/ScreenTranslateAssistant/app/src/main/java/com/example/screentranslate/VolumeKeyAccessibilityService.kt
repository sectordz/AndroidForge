package com.example.screentranslate

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.os.SystemClock

class VolumeKeyAccessibilityService : AccessibilityService() {
    private var volumeUpDownAt = 0L
    private var triggered = false
    private val longPressMs = 650L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No window content is collected.
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_UP) return false

        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount == 0) {
                    volumeUpDownAt = SystemClock.elapsedRealtime()
                    triggered = false
                } else if (!triggered &&
                    SystemClock.elapsedRealtime() - volumeUpDownAt >= longPressMs) {
                    triggered = true
                    sendTranslateCommand()
                }
                // Let Android process volume changes until a long press is detected.
                return triggered
            }
            KeyEvent.ACTION_UP -> {
                val wasTriggered = triggered
                volumeUpDownAt = 0L
                triggered = false
                return wasTriggered
            }
        }
        return false
    }

    private fun sendTranslateCommand() {
        val intent = Intent(this, FloatingTranslateService::class.java).apply {
            action = FloatingTranslateService.ACTION_TRANSLATE_NOW
        }
        try {
            startService(intent)
        } catch (_: Exception) {
            // The floating service must first be started from the app and screen-capture permission granted.
        }
    }
}
