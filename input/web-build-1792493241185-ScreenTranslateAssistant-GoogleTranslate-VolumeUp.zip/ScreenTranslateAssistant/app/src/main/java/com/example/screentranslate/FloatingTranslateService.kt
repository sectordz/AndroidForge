package com.example.screentranslate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class FloatingTranslateService : Service() {
    companion object {
        const val ACTION_START = "com.example.screentranslate.START"
        const val ACTION_TRANSLATE_NOW = "com.example.screentranslate.TRANSLATE_NOW"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL = "screen_translate"
    }

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var resultView: TextView? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TRANSLATE_NOW) {
            if (projection != null) captureAndTranslate()
            else showResult("افتح التطبيق وفعّل مشاركة الشاشة أولًا.")
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_START) {
            createNotificationChannel()
            val notification = if (Build.VERSION.SDK_INT >= 26) {
                Notification.Builder(this, CHANNEL)
                    .setContentTitle("مترجم الشاشة يعمل")
                    .setContentText("اضغط مطولًا على الفقاعة لترجمة الشاشة")
                    .setSmallIcon(android.R.drawable.ic_menu_search)
                    .build()
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(this)
                    .setContentTitle("مترجم الشاشة يعمل")
                    .setContentText("اضغط مطولًا على الفقاعة لترجمة الشاشة")
                    .setSmallIcon(android.R.drawable.ic_menu_search)
                    .build()
            }
            startForeground(1001, notification)
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            val data = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(EXTRA_RESULT_DATA)
            }
            if (data != null) {
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection = mgr.getMediaProjection(resultCode, data)
                createBubble()
            }
        }
        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "مترجم الشاشة", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun createBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val bubbleView = TextView(this).apply {
            text = "文\nع"
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xDD263B63.toInt())
            elevation = 12f
            setPadding(14, 12, 14, 12)
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 12
            y = 420
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var longPressed = false
        val longPress = Runnable {
            longPressed = true
            captureAndTranslate()
        }
        bubbleView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    moved = false; longPressed = false
                    mainHandler.postDelayed(longPress, 550)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) {
                        moved = true
                        mainHandler.removeCallbacks(longPress)
                        params.x = (startX - dx).coerceAtLeast(0)
                        params.y = (startY + dy).coerceAtLeast(0)
                        try { wm.updateViewLayout(bubbleView, params) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPress)
                    true
                }
                else -> true
            }
        }
        bubble = bubbleView
        wm.addView(bubbleView, params)
    }

    private fun captureAndTranslate() {
        if (busy) return
        val mp = projection ?: return
        busy = true
        showResult("جارٍ التقاط الشاشة وترجمة النص…")
        try {
            val metrics = resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi
            imageReader?.close()
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            val reader = imageReader!!
            virtualDisplay?.release()
            virtualDisplay = mp.createVirtualDisplay(
                "ScreenTranslateCapture", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, mainHandler
            )
            mainHandler.postDelayed({
                try {
                    val image = reader.acquireLatestImage()
                    if (image == null) {
                        showResult("تعذّر التقاط الشاشة. جرّب مرة أخرى.")
                        busy = false
                        return@postDelayed
                    }
                    val plane = image.planes[0]
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                    padded.copyPixelsFromBuffer(plane.buffer)
                    image.close()
                    val bitmap = Bitmap.createBitmap(padded, 0, 0, width, height)
                    padded.recycle()
                    recognizeAndTranslate(bitmap)
                } catch (e: Exception) {
                    showResult("حدث خطأ أثناء قراءة الشاشة.")
                    busy = false
                }
            }, 350)
        } catch (e: Exception) {
            showResult("لم أستطع التقاط الشاشة. أعد تفعيل المساعد.")
            busy = false
        }
    }

    private fun recognizeAndTranslate(bitmap: Bitmap) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                bitmap.recycle()
                val text = result.text.trim()
                recognizer.close()
                if (text.isBlank()) {
                    showResult("لم أجد نصًا واضحًا على الشاشة.")
                    busy = false
                    return@addOnSuccessListener
                }
                translateWithGoogleCloud(text)
            }
            .addOnFailureListener {
                bitmap.recycle()
                recognizer.close()
                showResult("تعذّرت قراءة النص من الشاشة.")
                busy = false
            }
    }


    // ضع مفتاح Google Cloud Translation API في هذا المتغير قبل البناء.
    // لا تنشر APK يحتوي على مفتاح ثابت؛ استخدم خادمًا وسيطًا لحماية المفتاح في النسخة المنشورة.
    private val googleTranslationApiKey = "PUT_YOUR_GOOGLE_CLOUD_TRANSLATION_API_KEY_HERE"

    private fun translateWithGoogleCloud(text: String) {
        if (googleTranslationApiKey.startsWith("PUT_")) {
            showResult("أضف مفتاح Google Cloud Translation API في FloatingTranslateService.kt أولًا.")
            busy = false
            return
        }
        Thread {
            var connection: HttpURLConnection? = null
            try {
                val url = URL("https://translation.googleapis.com/language/translate/v2?key=$googleTranslationApiKey")
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                }
                val payload = JSONObject()
                    .put("q", text)
                    .put("source", "pt")
                    .put("target", "ar")
                    .put("format", "text")
                    .toString()
                connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                val status = connection.responseCode
                val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                val body = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                if (status !in 200..299) {
                    val message = try {
                        JSONObject(body).optJSONObject("error")?.optString("message")
                    } catch (_: Exception) { null }
                    mainHandler.post {
                        showResult("خطأ من Google Translate API: ${message ?: "HTTP $status"}")
                        busy = false
                    }
                } else {
                    val translated = JSONObject(body)
                        .getJSONObject("data")
                        .getJSONArray("translations")
                        .getJSONObject(0)
                        .getString("translatedText")
                    mainHandler.post {
                        showResult(android.text.Html.fromHtml(translated, android.text.Html.FROM_HTML_MODE_LEGACY).toString())
                        busy = false
                    }
                }
            } catch (e: Exception) {
                mainHandler.post {
                    showResult("تعذّر الاتصال بخدمة Google للترجمة. تحقق من الإنترنت ومفتاح API.")
                    busy = false
                }
            } finally {
                connection?.disconnect()
            }
        }.start()
    }

    private fun showResult(message: String) {
        mainHandler.post {
            try {
                resultView?.let { wm.removeView(it) }
                val view = TextView(this).apply {
                    text = message + "\n\nاضغط هنا للإغلاق"
                    textSize = 17f
                    setTextColor(0xFFFFFFFF.toInt())
                    setBackgroundColor(0xF0222630.toInt())
                    setPadding(28, 24, 28, 24)
                    textDirection = View.TEXT_DIRECTION_RTL
                    setOnClickListener {
                        try { wm.removeView(this) } catch (_: Exception) {}
                        resultView = null
                    }
                }
                val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                           else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
                val params = WindowManager.LayoutParams(
                    (resources.displayMetrics.widthPixels * 0.88f).toInt(),
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.CENTER
                }
                wm.addView(view, params)
                resultView = view
            } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        try { resultView?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        virtualDisplay?.release()
        imageReader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
