package com.bekri.wordreminder

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

 data class Word(val pt: String, val ar: String, val examplePt: String = "", val exampleAr: String = "")

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val prefs by lazy { getSharedPreferences("words", MODE_PRIVATE) }
    private val words = mutableListOf<Word>()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var intervalSpinner: Spinner
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val exportRequest = 431

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        loadWords()
        buildUi()
        askNotificationPermission()
        updateStatus()
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("pt", "PT"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 18, 20, 12) }
        root.addView(TextView(this).apply { text = "🇵🇹 كلمات البرتغالية"; textSize = 25f; gravity = Gravity.CENTER; setPadding(0, 4, 0, 10) })
        root.addView(TextView(this).apply { text = "احفظ الكلمات والجمل، وتعلّمها بالبطاقات والاختبارات. يعمل التذكير في الخلفية من 08:00 إلى 22:00."; textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 0, 0, 10) })
        status = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; setPadding(0, 0, 0, 10) }
        root.addView(status)
        root.addView(Button(this).apply { text = "＋ إضافة كلمة"; setOnClickListener { editWord(null) } })
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        controls.addView(Button(this).apply { text = "▶ تشغيل التذكير"; setOnClickListener { requestExactAlarmThenSchedule() } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        controls.addView(Button(this).apply { text = "■ إيقاف"; setOnClickListener { prefs.edit().putBoolean("reminders_enabled", false).apply(); ReminderScheduler.cancel(this@MainActivity); updateStatus("تم إيقاف التذكيرات") } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(controls)
        val intervalRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        intervalRow.addView(TextView(this).apply { text = "الفاصل:"; textSize = 16f; setPadding(0, 0, 8, 0) })
        intervalSpinner = Spinner(this)
        intervalSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, (1..10).map { "كل $it دقيقة" })
        intervalSpinner.setSelection((prefs.getInt("interval_minutes", 5).coerceIn(1, 10)) - 1)
        intervalSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val minutes = position + 1
                val old = prefs.getInt("interval_minutes", 5)
                prefs.edit().putInt("interval_minutes", minutes).apply()
                if (old != minutes && prefs.getBoolean("reminders_enabled", false)) ReminderScheduler.scheduleNext(this@MainActivity)
                updateStatus()
            }
        }
        intervalRow.addView(intervalSpinner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(intervalRow)
        val learningRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        learningRow.addView(Button(this).apply { text = "🃏 البطاقات"; setOnClickListener { startFlashcards() } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        learningRow.addView(Button(this).apply { text = "🎯 اختبار"; setOnClickListener { startQuiz() } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(learningRow)
        val toolsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        toolsRow.addView(Button(this).apply { text = "📤 تصدير الكلمات"; setOnClickListener { exportWords() } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        toolsRow.addView(Button(this).apply { text = "🔊 تجربة النطق"; setOnClickListener { if (words.isEmpty()) toast("أضف كلمة أولًا") else speak(words.first().pt) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(toolsRow)
        root.addView(TextView(this).apply { text = "كلماتك (اضغط للتعديل، واضغط مطولًا للحذف)"; textSize = 17f; setPadding(0, 12, 0, 6) })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        renderWords()
    }

    private fun editWord(existing: Int?) {
        val current = existing?.let { words[it] }
        val pt = EditText(this).apply { hint = "الكلمة بالبرتغالية"; textSize = 17f; setSingleLine(true); current?.let { setText(it.pt) } }
        val ar = EditText(this).apply { hint = "الترجمة بالعربية"; textSize = 17f; setSingleLine(true); current?.let { setText(it.ar) } }
        val exPt = EditText(this).apply { hint = "مثال بالبرتغالية (اختياري)"; textSize = 16f; current?.let { setText(it.examplePt) } }
        val exAr = EditText(this).apply { hint = "ترجمة المثال (اختياري)"; textSize = 16f; current?.let { setText(it.exampleAr) } }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 0, 22, 0); addView(pt); addView(ar); addView(exPt); addView(exAr) }
        AlertDialog.Builder(this).setTitle(if (existing == null) "إضافة كلمة" else "تعديل الكلمة").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val p = pt.text.toString().trim(); val a = ar.text.toString().trim()
                if (p.isNotEmpty() && a.isNotEmpty()) {
                    val w = Word(p, a, exPt.text.toString().trim(), exAr.text.toString().trim())
                    if (existing == null) words.add(w) else if (existing in words.indices) words[existing] = w
                    saveWords(); renderWords(); updateStatus()
                } else toast("اكتب الكلمة والترجمة")
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun renderWords() {
        list.removeAllViews()
        if (words.isEmpty()) list.addView(TextView(this).apply { text = "لم تضف كلمات بعد. ابدأ بإضافة أول كلمة."; textSize = 16f; setPadding(8, 16, 8, 16) })
        words.forEachIndexed { i, w ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 10, 12, 10); setBackgroundResource(android.R.drawable.list_selector_background) }
            row.addView(TextView(this).apply { text = w.pt; textSize = 19f })
            row.addView(TextView(this).apply { text = w.ar; textSize = 17f; gravity = Gravity.END })
            if (w.examplePt.isNotBlank()) row.addView(TextView(this).apply { text = "${w.examplePt}\n${w.exampleAr}"; textSize = 14f; setPadding(0, 5, 0, 0) })
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            buttons.addView(Button(this@MainActivity).apply { text = "🔊"; setOnClickListener { speak(w.pt) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            buttons.addView(Button(this@MainActivity).apply { text = "تعديل"; setOnClickListener { editWord(i) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            buttons.addView(Button(this@MainActivity).apply { text = "حذف"; setOnClickListener { confirmDelete(i) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(buttons)
            list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            list.addView(View(this).apply { setBackgroundColor(0xFFE0E0E0.toInt()) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        }
    }

    private fun confirmDelete(i: Int) {
        if (i !in words.indices) return
        AlertDialog.Builder(this).setMessage("حذف ${words[i].pt}؟").setPositiveButton("حذف") { _, _ -> words.removeAt(i); saveWords(); renderWords(); updateStatus() }.setNegativeButton("إلغاء", null).show()
    }

    private fun startFlashcards() {
        if (words.isEmpty()) { toast("أضف كلمات أولًا"); return }
        var index = 0
        var revealed = false
        val cardText = TextView(this).apply { textSize = 20f; gravity = Gravity.CENTER; setPadding(24, 24, 24, 24); minHeight = 180 }
        val dialog = AlertDialog.Builder(this).setTitle("بطاقات الكلمات").setView(cardText).setPositiveButton("إظهار الترجمة", null).setNeutralButton("التالي ⟶", null).setNegativeButton("إغلاق", null).create()
        fun showCard() {
            val w = words[index % words.size]
            cardText.text = if (revealed) {
                buildString {
                    append("${index + 1} / ${words.size}\n\n${w.pt}\n${w.ar}")
                    if (w.examplePt.isNotBlank()) append("\n\n${w.examplePt}\n${w.exampleAr}")
                }
            } else "${index + 1} / ${words.size}\n\n${w.pt}\n\nحاول تذكّر المعنى ثم اضغط إظهار الترجمة"
        }
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { revealed = !revealed; dialog.getButton(AlertDialog.BUTTON_POSITIVE).text = if (revealed) "إخفاء الترجمة" else "إظهار الترجمة"; showCard() }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { index = (index + 1) % words.size; revealed = false; dialog.getButton(AlertDialog.BUTTON_POSITIVE).text = "إظهار الترجمة"; showCard() }
            showCard()
        }
        dialog.show()
    }

    private fun startQuiz() {
        if (words.size < 2) { toast("أضف كلمتين على الأقل لبدء الاختبار"); return }
        val item = words.random()
        val options = (words.filter { it.pt != item.pt }.shuffled().take(3).map { it.ar } + item.ar).distinct().shuffled()
        AlertDialog.Builder(this).setTitle("ما ترجمة: ${item.pt}؟").setItems(options.toTypedArray()) { _, which ->
            if (options[which] == item.ar) AlertDialog.Builder(this).setMessage("✅ صحيح! ${item.pt} = ${item.ar}").setPositiveButton("حسنًا", null).show()
            else AlertDialog.Builder(this).setMessage("❌ الإجابة الصحيحة: ${item.ar}").setPositiveButton("حسنًا", null).show()
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun speak(text: String) {
        if (!ttsReady) { toast("الصوت البرتغالي غير متاح حاليًا على الهاتف"); return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "word-${System.currentTimeMillis()}")
    }

    private fun exportWords() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "PortugueseWords.json") }
        startActivityForResult(intent, exportRequest)
    }

    @Deprecated("Deprecated in Android but kept for compatibility with target devices")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == exportRequest && resultCode == RESULT_OK && data?.data != null) {
            try {
                val arr = JSONArray(); words.forEach { arr.put(JSONObject().put("pt", it.pt).put("ar", it.ar).put("examplePt", it.examplePt).put("exampleAr", it.exampleAr)) }
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(arr.toString(2)) }
                toast("تم تصدير الكلمات بنجاح")
            } catch (e: Exception) { toast("تعذر التصدير: ${e.message}") }
        }
    }

    private fun loadWords() {
        words.clear()
        val arr = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) { val o = arr.optJSONObject(i) ?: continue; words.add(Word(o.optString("pt"), o.optString("ar"), o.optString("examplePt"), o.optString("exampleAr"))) }
    }
    private fun saveWords() { val arr = JSONArray(); words.forEach { arr.put(JSONObject().put("pt", it.pt).put("ar", it.ar).put("examplePt", it.examplePt).put("exampleAr", it.exampleAr)) }; prefs.edit().putString("items", arr.toString()).apply() }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
    }
    private fun requestExactAlarmThenSchedule() {
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))); toast("اسمح للتطبيق بالمنبّهات الدقيقة ثم ارجع واضغط تشغيل"); return }
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) { askNotificationPermission(); toast("اسمح بالإشعارات ثم اضغط تشغيل مرة أخرى"); return }
        prefs.edit().putBoolean("reminders_enabled", true).apply()
        ReminderScheduler.scheduleNext(this)
        updateStatus("التذكير يعمل في الخلفية: كل ${prefs.getInt("interval_minutes", 5)} دقيقة بين 08:00 و22:00")
    }
    private fun updateStatus(message: String? = null) { status.text = message ?: "عدد الكلمات المحفوظة: ${words.size}\nالتذكير: كل ${prefs.getInt("interval_minutes", 5)} دقيقة، 08:00–22:00" }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

object ReminderScheduler {
    fun scheduleNext(context: Context) {
        val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("reminders_enabled", false)) return
        val now = System.currentTimeMillis()
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = now }
        val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
        if (hour >= 22 || hour < 8) {
            if (hour >= 22) cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
            cal.set(java.util.Calendar.HOUR_OF_DAY, 8); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
            setAlarm(context, cal.timeInMillis); return
        }
        val minutes = prefs.getInt("interval_minutes", 5).coerceIn(1, 10)
        setAlarm(context, now + minutes * 60 * 1000L)
    }
    private fun setAlarm(context: Context, at: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(context, 12, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); return }
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) else am.setExact(AlarmManager.RTC_WAKEUP, at, pi)
    }
    fun cancel(context: Context) { val pi = PendingIntent.getBroadcast(context, 12, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi) }
}

class ReminderReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("reminders_enabled", false)) return
        val arr = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        val now = java.util.Calendar.getInstance(); val hour = now.get(java.util.Calendar.HOUR_OF_DAY)
        if (hour in 8..21 && arr.length() > 0) {
            val index = prefs.getInt("next_index", 0).let { if (it >= arr.length()) 0 else it }
            val item = arr.optJSONObject(index)
            if (item != null) {
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(android.app.NotificationChannel("words", "تذكير الكلمات", android.app.NotificationManager.IMPORTANCE_DEFAULT))
                val open = PendingIntent.getActivity(context, 2, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val notification = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, "words") else android.app.Notification.Builder(context)
                val text = "${item.optString("pt")} — ${item.optString("ar")}"
                notification.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(item.optString("pt")).setContentText(item.optString("ar")).setStyle(android.app.Notification.BigTextStyle().bigText(text)).setContentIntent(open).setAutoCancel(true)
                manager.notify(1001, notification.build())
                prefs.edit().putInt("next_index", (index + 1) % arr.length()).apply()
            }
        }
        ReminderScheduler.scheduleNext(context)
    }
}

class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) ReminderScheduler.scheduleNext(context)
    }
}
