# Minification is disabled for the prototype.
