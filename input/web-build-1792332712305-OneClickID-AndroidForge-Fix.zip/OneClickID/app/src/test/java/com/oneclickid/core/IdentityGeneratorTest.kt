package com.oneclickid.core
import org.junit.Assert.*
import org.junit.Test
class IdentityGeneratorTest{
 @Test fun passwordHasRequestedLength(){assertEquals(24,IdentityGenerator.password(24).length)}
 @Test fun passwordsAreNotConstant(){assertNotEquals(IdentityGenerator.password(),IdentityGenerator.password())}
 @Test fun generatedEmailLocalPartUsesSafeCharacters(){val s=IdentityGenerator.emailLocalPart();assertEquals(12,s.length);assertTrue(s.all{it.isLetterOrDigit()})}
}
