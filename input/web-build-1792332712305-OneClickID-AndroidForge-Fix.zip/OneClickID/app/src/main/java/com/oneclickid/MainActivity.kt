package com.oneclickid
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import com.oneclickid.ui.OneClickApp
import com.oneclickid.ui.ProfileViewModel
import com.oneclickid.ui.ProfileViewModelFactory
class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); val app=application as OneClickApplication
  setContent { MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFFB7AEFF),onPrimary=Color(0xFF17132F),secondary=Color(0xFF83DCCB),background=Color(0xFF0C0D14),surface=Color(0xFF171923),surfaceVariant=Color(0xFF25283A),onSurface=Color(0xFFF1F0F8),onSurfaceVariant=Color(0xFFB5B8C9))) { val vm:ProfileViewModel=viewModel(factory=ProfileViewModelFactory(app.profiles)); OneClickApp(vm) } }
 }
}
