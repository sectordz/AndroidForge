package com.oneclickid.ui
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.oneclickid.data.ProfileEntity
import com.oneclickid.data.ProfileRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
class ProfileViewModel(private val repository:ProfileRepository):ViewModel(){
 val profiles=repository.observeProfiles().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 fun addProfile(name:String,email:String,displayName:String,kind:String){if(name.isBlank()||!email.contains('@'))return;viewModelScope.launch{val first=profiles.value.isEmpty();repository.add(ProfileEntity(name=name.trim(),email=email.trim(),displayName=displayName.trim().ifBlank{name.trim()},kind=kind,isDefault=first))}}
 fun delete(profile:ProfileEntity)=viewModelScope.launch{repository.delete(profile)}
 fun setDefault(profile:ProfileEntity)=viewModelScope.launch{repository.setDefault(profile.id)}
}
class ProfileViewModelFactory(private val repository:ProfileRepository):ViewModelProvider.Factory{
 @Suppress("UNCHECKED_CAST") override fun <T:ViewModel> create(modelClass:Class<T>):T {if(modelClass.isAssignableFrom(ProfileViewModel::class.java))return ProfileViewModel(repository) as T;throw IllegalArgumentException("Unknown ViewModel class")}
}
