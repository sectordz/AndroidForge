package com.oneclickid
import android.app.Application
import com.oneclickid.data.AppDatabase
import com.oneclickid.data.ProfileRepository
class OneClickApplication : Application() {
    val database by lazy { AppDatabase.get(this) }
    val profiles by lazy { ProfileRepository(database.profileDao()) }
}
