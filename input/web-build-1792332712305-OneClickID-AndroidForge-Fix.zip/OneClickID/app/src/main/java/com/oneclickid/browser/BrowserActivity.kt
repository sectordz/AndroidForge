package com.oneclickid.browser
import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.oneclickid.OneClickApplication
import com.oneclickid.core.IdentityGenerator
import com.oneclickid.data.ProfileEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.json.JSONObject

class BrowserActivity:ComponentActivity(){private var webView:WebView?=null
 @SuppressLint("SetJavaScriptEnabled") override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);val start=intent.getStringExtra("url")?:"https://example.com";setContent{MaterialTheme(colorScheme=darkColorScheme(primary=androidx.compose.ui.graphics.Color(0xFFB7AEFF))){BrowserScreen(start,{webView=it},{runBlocking{(application as OneClickApplication).profiles.observeProfiles().first()}},{finish()})}}}
 override fun onDestroy(){webView?.apply{stopLoading();loadUrl("about:blank");removeAllViews();destroy()};webView=null;super.onDestroy()}
}
@SuppressLint("SetJavaScriptEnabled") @Composable private fun BrowserScreen(initialUrl:String,onWebView:(WebView)->Unit,profilesProvider:suspend()->List<ProfileEntity>,onBack:()->Unit){
 var address by remember{mutableStateOf(initialUrl)};var title by remember{mutableStateOf("Browser")};var fieldCount by remember{mutableIntStateOf(0)};var showFill by remember{mutableStateOf(false)};var profiles by remember{mutableStateOf(emptyList<ProfileEntity>())};var notice by remember{mutableStateOf("Choose a profile to fill common fields.")};var loading by remember{mutableStateOf(false)};var web by remember{mutableStateOf<WebView?>(null)}
 LaunchedEffect(Unit){profiles=profilesProvider()}
 Column(Modifier.fillMaxSize()){Row(Modifier.fillMaxWidth().padding(6.dp),horizontalArrangement=Arrangement.spacedBy(5.dp)){IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Back")};OutlinedTextField(address,{address=it},modifier=Modifier.weight(1f),singleLine=true,label={Text("Address")});IconButton(onClick={val u=normalUrl(address);address=u;web?.loadUrl(u)} ){Icon(Icons.Default.Refresh,"Load")}}
 AndroidView(modifier=Modifier.weight(1f).fillMaxWidth(),factory={ctx->WebView(ctx).apply{settings.javaScriptEnabled=true;settings.domStorageEnabled=true;settings.javaScriptCanOpenWindowsAutomatically=false;settings.allowFileAccess=false;settings.allowContentAccess=false;settings.setSupportMultipleWindows(false);CookieManager.getInstance().setAcceptCookie(true);webChromeClient=object:WebChromeClient(){override fun onReceivedTitle(view:WebView?,t:String?){title=t?:"Browser"};override fun onProgressChanged(view:WebView?,p:Int){loading=p<100}};webViewClient=object:WebViewClient(){override fun shouldOverrideUrlLoading(view:WebView?,request:WebResourceRequest?):Boolean{return request?.url?.scheme !in listOf("http","https")};override fun onPageFinished(view:WebView?,url:String?){address=url?:address;evaluateJavascript(DETECT_JS){r->fieldCount=r?.trim('"')?.toIntOrNull()?:0};evaluateJavascript(FILL_HELPER,null)}};web=this;onWebView(this);loadUrl(normalUrl(initialUrl))}},update={web=it})
 Surface(color=MaterialTheme.colorScheme.surface,tonalElevation=3.dp){Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){FilledTonalButton(onClick={showFill=true},modifier=Modifier.weight(1f)){Icon(Icons.Default.AutoAwesome,null);Spacer(Modifier.width(7.dp));Text("Quick Fill")};OutlinedButton(onClick={notice="Page: $title"}){Icon(Icons.Default.Security,null);Spacer(Modifier.width(5.dp));Text("Page info")}};Text(if(loading)"Loading…" else "$title • $fieldCount likely form fields",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
 if(showFill)ModalBottomSheet(onDismissRequest={showFill=false}){Column(Modifier.fillMaxWidth().padding(horizontal=18.dp).padding(bottom=28.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Quick Fill",style=MaterialTheme.typography.headlineSmall);Text(notice,color=MaterialTheme.colorScheme.onSurfaceVariant);if(profiles.isEmpty())Text("No profiles saved. Create one in the main app first.") else profiles.forEach{p->Card(modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp),onClick={val payload=JSONObject().apply{put("email",p.email);put("name",p.displayName);put("password",IdentityGenerator.password())}.toString();web?.evaluateJavascript("window.__oneClickFill(${JSONObject.quote(payload)})"){result->notice=if(result?.contains("filled:")==true)"Autofill attempted for ${p.name}. Review every field before submitting." else "Attempted autofill for ${p.name}. Check the form manually."};showFill=false}){Row(Modifier.fillMaxWidth().padding(14.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)){Icon(Icons.Default.Security,null,tint=MaterialTheme.colorScheme.primary);Column(Modifier.weight(1f)){Text(p.name,style=MaterialTheme.typography.titleMedium);Text(p.email,color=MaterialTheme.colorScheme.onSurfaceVariant)};if(p.isDefault)AssistChip(onClick={},label={Text("Default")})}}};Text("Quick Fill never presses Submit. Generated passwords are temporary in this prototype; save them in a trusted password manager before relying on them.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
}
private fun normalUrl(raw:String):String{val s=raw.trim();if(s.isBlank())return "https://example.com";return if(s.startsWith("https://",true)||s.startsWith("http://",true))s else "https://$s"}
private val DETECT_JS="""(function(){return String(Array.from(document.querySelectorAll('input,textarea,select')).filter(e=>!e.disabled&&!['hidden','submit','button','reset','image'].includes((e.type||'').toLowerCase())).length)})()"""
private val FILL_HELPER="""
(function(){window.__oneClickFill=function(payloadText){try{const p=JSON.parse(payloadText);const els=Array.from(document.querySelectorAll('input,textarea'));let n=0;const visible=e=>!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length);const put=(e,v)=>{const d=Object.getOwnPropertyDescriptor(e.constructor.prototype,'value')?.set;if(d)d.call(e,v);else e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));};for(const e of els){if(e.disabled||e.readOnly||!visible(e))continue;const t=(e.type||'').toLowerCase();const h=((e.name||'')+' '+(e.id||'')+' '+(e.autocomplete||'')+' '+(e.placeholder||'')+' '+(e.getAttribute('aria-label')||'')).toLowerCase();if(['hidden','submit','button','reset','file','checkbox','radio'].includes(t))continue;if(t==='email'||/e-?mail/.test(h)){if(!e.value){put(e,p.email||'');n++}}else if(/confirm|repeat|again/.test(h)&&/pass/.test(h)){if(!e.value){put(e,p.password||'');n++}}else if(t==='password'||/password|passwd/.test(h)){if(!e.value){put(e,p.password||'');n++}}else if(/full.?name|display.?name|your.?name/.test(h)){if(!e.value){put(e,p.name||'');n++}}else if(/first.?name/.test(h)){if(!e.value){put(e,(p.name||'').split(' ')[0]);n++}}}return 'filled:'+n}catch(e){return 'error'}}})();
"""
