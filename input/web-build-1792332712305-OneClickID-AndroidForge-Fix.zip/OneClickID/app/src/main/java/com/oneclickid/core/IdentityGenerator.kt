package com.oneclickid.core
import java.security.SecureRandom
object IdentityGenerator {
 private val random=SecureRandom()
 private const val ALPHABET="abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789!@#%_-"
 fun password(length:Int=20):String { require(length in 12..64); return buildString(length){repeat(length){append(ALPHABET[random.nextInt(ALPHABET.length)])}} }
 fun emailLocalPart():String { val alphabet="abcdefghjkmnpqrstuvwxyz23456789"; return buildString { repeat(12){append(alphabet[random.nextInt(alphabet.length)])} } }
}
