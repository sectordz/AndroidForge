package com.oneclickid.data
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName="profiles")
data class ProfileEntity(@PrimaryKey(autoGenerate=true) val id:Long=0, val name:String, val email:String, val displayName:String, val kind:String="EMAIL", val isDefault:Boolean=false, val createdAt:Long=System.currentTimeMillis())
