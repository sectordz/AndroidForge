package com.oneclickid.data
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
@Dao interface ProfileDao {
 @Query("SELECT * FROM profiles ORDER BY isDefault DESC, createdAt DESC") fun observeAll():Flow<List<ProfileEntity>>
 @Insert suspend fun insert(profile:ProfileEntity):Long
 @Delete suspend fun delete(profile:ProfileEntity)
 @Query("UPDATE profiles SET isDefault = 0") suspend fun clearDefaults()
 @Query("UPDATE profiles SET isDefault = 1 WHERE id = :id") suspend fun setDefault(id:Long)
}
