package com.oneclickid.data
import kotlinx.coroutines.flow.Flow
class ProfileRepository(private val dao:ProfileDao){
 fun observeProfiles():Flow<List<ProfileEntity>>=dao.observeAll()
 suspend fun add(profile:ProfileEntity)=dao.insert(profile)
 suspend fun delete(profile:ProfileEntity)=dao.delete(profile)
 suspend fun setDefault(id:Long){dao.clearDefaults();dao.setDefault(id)}
}
