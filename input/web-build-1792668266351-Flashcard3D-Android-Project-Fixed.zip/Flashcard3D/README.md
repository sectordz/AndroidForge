# Flashcard 3D — Android demo

A new standalone Android Studio project for a single Portuguese-Arabic 3D-style learning card (`avô` / `الجدّ`). It does not modify or depend on PortugueseWordReminder.

## Build
1. Open this folder in Android Studio (Giraffe or newer recommended).
2. Allow Gradle sync; Android Gradle Plugin 8.7.3 and Kotlin 2.0.21 are declared in the build files.
3. Install Android SDK Platform 35 if prompted.
4. Select **Run** to install on an Android device or emulator.

The UI is an offline HTML/CSS screen rendered in Android WebView. The speak buttons call Android TextToSpeech with Portuguese (Portugal). Actual voice availability depends on the device's installed TTS voice data.

## Project structure
- `app/src/main/java/com/flashcard3d/demo/MainActivity.kt`: WebView host and native TTS bridge
- `app/src/main/assets/index.html`: card UI, styling and button interactions
- `app/src/main/assets/avo-grandfather.png`: image asset used in the demo

No internet permission or remote assets are required. This is a source project, not a prebuilt APK.
