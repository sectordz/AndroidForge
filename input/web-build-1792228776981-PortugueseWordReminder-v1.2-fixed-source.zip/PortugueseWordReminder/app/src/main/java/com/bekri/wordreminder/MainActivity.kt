package com.bekri.wordreminder

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.*
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

 data class Word(val pt: String, val ar: String, val examplePt: String = "", val exampleAr: String = "")

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val prefs by lazy { getSharedPreferences("words", MODE_PRIVATE) }
    private val words = mutableListOf<Word>()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var intervalSpinner: Spinner
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val exportRequest = 431
    private val importRequest = 432
    private var showingMyWords = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        loadWords()
        buildUi()
        askNotificationPermission()
        updateStatus()
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("pt", "PT"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Keep the app content below Android's status bar and above the navigation bar.
            // Android 15 enforces edge-to-edge for newer target SDKs, so fixed padding alone
            // can let the header overlap the clock and battery icons.
            setPadding(16, 12, 16, 10)
            setBackgroundColor(Color.rgb(246, 248, 252))
            setOnApplyWindowInsetsListener { view, insets ->
                val topInset: Int
                val bottomInset: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    topInset = bars.top
                    bottomInset = bars.bottom
                } else {
                    @Suppress("DEPRECATION")
                    run {
                        topInset = insets.systemWindowInsetTop
                        bottomInset = insets.systemWindowInsetBottom
                    }
                }
                view.setPadding(
                    (16 * resources.displayMetrics.density).toInt(),
                    topInset + (12 * resources.displayMetrics.density).toInt(),
                    (16 * resources.displayMetrics.density).toInt(),
                    bottomInset + (10 * resources.displayMetrics.density).toInt()
                )
                insets
            }
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(14, 14, 14, 14)
            background = rounded(0xFF1769E8.toInt(), 22)
        }
        header.addView(TextView(this).apply {
            text = "🇵🇹 كلمات البرتغالية"
            textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD)
        })
        header.addView(TextView(this).apply {
            text = "Português • تعلّم الكلمات والجمل يوميًا"
            textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 5, 0, 0)
        })
        content.addView(header, marginParams())

        status = TextView(this).apply {
            textSize = 15f; gravity = Gravity.CENTER; setTextColor(0xFF253858.toInt()); setPadding(8, 12, 8, 12)
            background = rounded(Color.WHITE, 16)
        }
        content.addView(status, marginParams())

        content.addView(makeTile("＋ إضافة كلمة", 0xFF168B55.toInt()) { editWord(null) }, marginParams())
        val reminderRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        reminderRow.addView(makeTile("▶ تشغيل التذكير", 0xFF1769E8.toInt()) { requestExactAlarmThenSchedule() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 3, 4, 3) })
        reminderRow.addView(makeTile("■ إيقاف", 0xFF64748B.toInt()) {
            prefs.edit().putBoolean("reminders_enabled", false).apply(); ReminderScheduler.cancel(this@MainActivity); updateStatus("تم إيقاف التذكيرات")
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 3, 0, 3) })
        content.addView(reminderRow)

        val intervalCard = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(12, 6, 12, 6); background = rounded(Color.WHITE, 14) }
        intervalCard.addView(TextView(this).apply { text = "⏱ الفاصل:"; textSize = 16f; setTextColor(0xFF253858.toInt()); setPadding(0, 0, 8, 0) })
        intervalSpinner = Spinner(this)
        intervalSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, (1..10).map { "كل $it دقيقة" })
        intervalSpinner.setSelection((prefs.getInt("interval_minutes", 5).coerceIn(1, 10)) - 1)
        intervalSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val minutes = position + 1
                val old = prefs.getInt("interval_minutes", 5)
                prefs.edit().putInt("interval_minutes", minutes).apply()
                if (old != minutes && prefs.getBoolean("reminders_enabled", false)) ReminderScheduler.scheduleNext(this@MainActivity)
                updateStatus()
            }
        }
        intervalCard.addView(intervalSpinner, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(intervalCard, marginParams())

        val learnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        learnRow.addView(makeTile("🃏 البطاقات التعليمية", 0xFF168B55.toInt()) { startFlashcards() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 3, 4, 3) })
        learnRow.addView(makeTile("🎯 اختبار الكلمات", 0xFF7C3AED.toInt()) { startQuiz() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 3, 0, 3) })
        content.addView(learnRow)

        val toolsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        toolsRow.addView(makeTile("📥 استيراد Excel", 0xFF0D9488.toInt()) { importWords() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 3, 4, 3) })
        toolsRow.addView(makeTile("📤 تصدير الكلمات", 0xFFF59E0B.toInt()) { exportWords() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 3, 0, 3) })
        content.addView(toolsRow)
        val soundRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        soundRow.addView(makeTile("🔊 تجربة النطق الأوروبي", 0xFF2563EB.toInt()) { if (words.isEmpty()) toast("أضف كلمة أولًا") else speak(words.first().pt) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 3, 4, 3) })
        soundRow.addView(makeTile("📖 الجمل والأمثلة", 0xFFDB2777.toInt()) { showExamples() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(4, 3, 0, 3) })
        content.addView(soundRow, marginParams())
        content.addView(makeTile("📚 كلماتي — البحث والتصنيف", 0xFF0F766E.toInt()) { showMyWords() }, marginParams())

        content.addView(TextView(this).apply {
            text = "📚 كلماتك (اضغط تعديل، أو حذف لإزالتها)"; textSize = 19f; setTextColor(0xFF172B4D.toInt()); setPadding(4, 12, 4, 6); setTypeface(null, android.graphics.Typeface.BOLD)
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        renderWords()
    }

    private fun showMyWords() {
        showingMyWords = true
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 8)
            setBackgroundColor(0xFFF4F7FC.toInt())
            setOnApplyWindowInsetsListener { view, insets ->
                val top: Int
                val bottom: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    top = bars.top; bottom = bars.bottom
                } else {
                    @Suppress("DEPRECATION")
                    run { top = insets.systemWindowInsetTop; bottom = insets.systemWindowInsetBottom }
                }
                view.setPadding((16 * resources.displayMetrics.density).toInt(), top + (8 * resources.displayMetrics.density).toInt(), (16 * resources.displayMetrics.density).toInt(), bottom + (8 * resources.displayMetrics.density).toInt())
                insets
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(16, 16, 16, 16)
            background = rounded(0xFF1769E8.toInt(), 24)
        }
        header.addView(TextView(this).apply { text = "🇵🇹 كلمات البرتغالية"; textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD) })
        header.addView(TextView(this).apply { text = "قائمة كلماتك المحفوظة"; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 4, 0, 0) })
        root.addView(header, marginParams())

        val summary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12); background = rounded(Color.WHITE, 18) }
        val count = TextView(this).apply { text = "📘 ${words.size} كلمة محفوظة"; textSize = 20f; setTextColor(0xFF102A43.toInt()); setTypeface(null, android.graphics.Typeface.BOLD) }
        summary.addView(count)
        val search = EditText(this).apply {
            hint = "🔎 ابحث عن كلمة أو ترجمة..."; textSize = 16f; isSingleLine = true; setPadding(14, 10, 14, 10)
            background = rounded(0xFFF0F4FA.toInt(), 16)
        }
        val searchParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 10 }
        summary.addView(search, searchParams)
        root.addView(summary, marginParams())

        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val filters = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 2, 0, 2) }
        val categories = listOf("الكل", "الأسماء", "الأفعال", "الصفات")
        var activeCategory = "الكل"
        val categoryButtons = mutableMapOf<String, Button>()
        categories.forEach { category ->
            val b = Button(this).apply {
                text = category; textSize = 12f; isAllCaps = false; setPadding(2, 2, 2, 2)
                setTextColor(if (category == activeCategory) Color.WHITE else 0xFF334155.toInt())
                background = rounded(if (category == activeCategory) 0xFF1769E8.toInt() else Color.WHITE, 14)
            }
            b.setOnClickListener {
                activeCategory = category
                categoryButtons.forEach { (name, button) ->
                    button.setTextColor(if (name == activeCategory) Color.WHITE else 0xFF334155.toInt())
                    button.background = rounded(if (name == activeCategory) 0xFF1769E8.toInt() else Color.WHITE, 14)
                }
                renderMyWordRows(search.text.toString(), activeCategory, rows, count)
            }
            categoryButtons[category] = b
            filters.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 2, 2, 2) })
        }
        root.addView(filters, marginParams())
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(rows) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 5, 0, 0) }
        bottom.addView(makeTile("⌂ الرئيسية", 0xFF64748B.toInt()) { showingMyWords = false; buildUi() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(makeTile("＋ إضافة", 0xFF168B55.toInt()) { editWord(null) ; renderMyWordRows(search.text.toString(), activeCategory, rows, count) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(makeTile("🃏 البطاقات", 0xFF7C3AED.toInt()) { startFlashcards() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(makeTile("🎯 الاختبار", 0xFFDB2777.toInt()) { startQuiz() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(bottom)
        setContentView(root)
        renderMyWordRows("", activeCategory, rows, count)
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, countChanged: Int) { renderMyWordRows(s?.toString().orEmpty(), activeCategory, rows, count) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun wordCategory(word: Word): String {
        val w = word.pt.lowercase(Locale.ROOT)
        val verbs = setOf("ser", "estar", "ter", "fazer", "ir", "vir", "ver", "dizer", "poder", "querer", "saber", "dar", "ficar", "trabalhar", "comer", "beber", "falar", "morar", "estudar", "aprender", "soletrar", "chamar-se", "gostar", "precisar", "abrir", "fechar", "ler", "escrever", "ouvir", "andar", "comprar", "vender", "viver", "sentir", "dormir", "sair", "entrar")
        return when {
            w in verbs || w.endsWith("ar") || w.endsWith("er") || w.endsWith("ir") -> "الأفعال"
            w.endsWith("oso") || w.endsWith("osa") || w.endsWith("ico") || w.endsWith("ica") || w.endsWith("ável") || w.endsWith("ível") || w.endsWith("ente") || w.endsWith("al") -> "الصفات"
            else -> "الأسماء"
        }
    }

    private fun renderMyWordRows(query: String, category: String, rows: LinearLayout, count: TextView) {
        rows.removeAllViews()
        val filtered = words.withIndex().filter { (_, word) ->
            val matchesText = query.isBlank() || word.pt.contains(query, true) || word.ar.contains(query, true) || word.examplePt.contains(query, true) || word.exampleAr.contains(query, true)
            val matchesCategory = category == "الكل" || wordCategory(word) == category
            matchesText && matchesCategory
        }
        count.text = "📘 ${words.size} كلمة محفوظة • النتائج: ${filtered.size}"
        if (filtered.isEmpty()) {
            rows.addView(TextView(this).apply { text = "لا توجد كلمات مطابقة. جرّب بحثًا آخر أو أضف كلمة جديدة."; textSize = 16f; setTextColor(0xFF64748B.toInt()); setPadding(16, 24, 16, 24); background = rounded(Color.WHITE, 18) }, marginParams())
            return
        }
        filtered.forEach { indexed ->
            val i = indexed.index; val w = indexed.value
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 12); background = rounded(Color.WHITE, 18) }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val wordsText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            wordsText.addView(TextView(this).apply { text = w.pt; textSize = 22f; setTextColor(0xFF102A43.toInt()); setTypeface(null, android.graphics.Typeface.BOLD) })
            wordsText.addView(TextView(this).apply { text = w.ar; textSize = 18f; setTextColor(0xFF52677F.toInt()); setPadding(0, 3, 0, 0) })
            top.addView(wordsText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val categoryColor = when (wordCategory(w)) { "الأفعال" -> 0xFFFFE7A3.toInt(); "الصفات" -> 0xFFFCE0F0.toInt(); else -> 0xFFD8F8E5.toInt() }
            top.addView(TextView(this).apply { text = when (wordCategory(w)) { "الأفعال" -> "🏃 فعل"; "الصفات" -> "★ صفة"; else -> "⌂ اسم" }; textSize = 12f; setTextColor(0xFF334155.toInt()); setPadding(9, 7, 9, 7); background = rounded(categoryColor, 18) })
            card.addView(top)
            if (w.examplePt.isNotBlank()) card.addView(TextView(this).apply { text = "${w.examplePt}\n${w.exampleAr}"; textSize = 14f; setTextColor(0xFF52677F.toInt()); setPadding(10, 8, 10, 8); background = rounded(0xFFF1F5F9.toInt(), 12) }, marginParams())
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            actions.addView(makeTile("🔊 نطق", 0xFF1769E8.toInt()) { speak(w.pt) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 5, 3, 0) })
            actions.addView(makeTile("✎ تعديل", 0xFF64748B.toInt()) { editWord(i); rows.post { renderMyWordRows(query, category, rows, count) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 5, 3, 0) })
            actions.addView(makeTile("▤ حذف", 0xFFDC2626.toInt()) { confirmDelete(i); rows.post { renderMyWordRows(query, category, rows, count) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 5, 0, 0) })
            card.addView(actions)
            rows.addView(card, marginParams())
        }
    }

    override fun onBackPressed() {
        if (showingMyWords) { showingMyWords = false; buildUi() } else super.onBackPressed()
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radiusDp * resources.displayMetrics.density
    }

    private fun marginParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        setMargins(0, 4, 0, 4)
    }

    private fun makeTile(label: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 14f; setTextColor(Color.WHITE); isAllCaps = false; setPadding(8, 8, 8, 8)
        background = rounded(color, 14)
        setOnClickListener { action() }
    }

    private fun editWord(existing: Int?) {
        val current = existing?.let { words[it] }
        val pt = EditText(this).apply { hint = "الكلمة بالبرتغالية"; textSize = 17f; setSingleLine(true); current?.let { setText(it.pt) } }
        val ar = EditText(this).apply { hint = "الترجمة بالعربية"; textSize = 17f; setSingleLine(true); current?.let { setText(it.ar) } }
        val exPt = EditText(this).apply { hint = "مثال بالبرتغالية (اختياري)"; textSize = 16f; current?.let { setText(it.examplePt) } }
        val exAr = EditText(this).apply { hint = "ترجمة المثال (اختياري)"; textSize = 16f; current?.let { setText(it.exampleAr) } }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 0, 22, 0); addView(pt); addView(ar); addView(exPt); addView(exAr) }
        AlertDialog.Builder(this).setTitle(if (existing == null) "إضافة كلمة" else "تعديل الكلمة").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val p = pt.text.toString().trim(); val a = ar.text.toString().trim()
                if (p.isNotEmpty() && a.isNotEmpty()) {
                    val w = Word(p, a, exPt.text.toString().trim(), exAr.text.toString().trim())
                    if (existing == null) words.add(w) else if (existing in words.indices) words[existing] = w
                    saveWords(); if (showingMyWords) showMyWords() else renderWords(); updateStatus()
                } else toast("اكتب الكلمة والترجمة")
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun renderWords() {
        list.removeAllViews()
        if (words.isEmpty()) {
            list.addView(TextView(this).apply { text = "لم تضف كلمات بعد. أضف كلمة أو استورد ملف Excel."; textSize = 16f; setTextColor(0xFF64748B.toInt()); setPadding(12, 18, 12, 18); background = rounded(Color.WHITE, 16) }, marginParams())
            return
        }
        words.forEachIndexed { i, w ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 12); background = rounded(Color.WHITE, 16)
            }
            card.addView(TextView(this).apply { text = w.pt; textSize = 22f; setTextColor(0xFF102A43.toInt()); setTypeface(null, android.graphics.Typeface.BOLD) })
            card.addView(TextView(this).apply { text = w.ar; textSize = 18f; gravity = Gravity.END; setTextColor(0xFF334E68.toInt()); setPadding(0, 2, 0, 4) })
            if (w.examplePt.isNotBlank()) {
                card.addView(TextView(this).apply { text = "${w.examplePt}\n${w.exampleAr}"; textSize = 14f; setTextColor(0xFF486581.toInt()); setPadding(8, 8, 8, 8); background = rounded(0xFFF1F5F9.toInt(), 10) })
            }
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            buttons.addView(makeTile("🔊", 0xFF1769E8.toInt()) { speak(w.pt) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.7f).apply { setMargins(0, 4, 3, 0) })
            buttons.addView(makeTile("تعديل", 0xFF64748B.toInt()) { editWord(i) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 4, 3, 0) })
            buttons.addView(makeTile("حذف", 0xFFDC2626.toInt()) { confirmDelete(i) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 4, 0, 0) })
            card.addView(buttons)
            list.addView(card, marginParams())
        }
    }

    private fun confirmDelete(i: Int) {
        if (i !in words.indices) return
        AlertDialog.Builder(this).setMessage("حذف ${words[i].pt}؟").setPositiveButton("حذف") { _, _ -> words.removeAt(i); saveWords(); if (showingMyWords) showMyWords() else renderWords(); updateStatus() }.setNegativeButton("إلغاء", null).show()
    }

    private fun showExamples() {
        val examples = words.filter { it.examplePt.isNotBlank() }
        if (examples.isEmpty()) {
            AlertDialog.Builder(this).setTitle("الجمل والأمثلة")
                .setMessage("لا توجد أمثلة محفوظة بعد. أضف كلمة ثم اكتب المثال البرتغالي وترجمته، أو استورد ملف Excel بأربعة أعمدة: البرتغالية، العربية، المثال، ترجمة المثال.")
                .setPositiveButton("حسنًا", null).show()
            return
        }
        val body = examples.joinToString("\n\n──────────\n\n") { "${it.examplePt}\n${it.exampleAr}\n(${it.pt} = ${it.ar})" }
        val text = TextView(this).apply { this.text = body; textSize = 17f; setTextColor(0xFF243B53.toInt()); setPadding(22, 14, 22, 14) }
        AlertDialog.Builder(this).setTitle("الجمل والأمثلة (${examples.size})").setView(ScrollView(this).apply { addView(text) }).setPositiveButton("إغلاق", null).show()
    }

    private fun startFlashcards() {
        if (words.isEmpty()) { toast("أضف كلمات أولًا"); return }
        var index = 0
        var revealed = false
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 8, 18, 12); background = rounded(0xFFF4F7FC.toInt(), 24) }
        val progress = TextView(this).apply { textSize = 14f; setTextColor(0xFF475569.toInt()); gravity = Gravity.CENTER; setPadding(0, 4, 0, 10) }
        val progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = words.size; this.progress = 1; progressTintList = android.content.res.ColorStateList.valueOf(0xFF10B981.toInt()); progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xFFDCE5F1.toInt()) }
        val wordCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(18, 22, 18, 22); minimumHeight = (270 * resources.displayMetrics.density).toInt(); background = rounded(Color.WHITE, 24) }
        val wordText = TextView(this).apply { textSize = 32f; gravity = Gravity.CENTER; setTextColor(0xFF102A72.toInt()); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 10, 0, 10) }
        val speaker = makeTile("🔊 استمع للنطق الأوروبي", 0xFF1769E8.toInt()) { speak(words[index % words.size].pt) }
        val translation = TextView(this).apply { textSize = 23f; gravity = Gravity.CENTER; setTextColor(0xFF334155.toInt()); setPadding(0, 14, 0, 4) }
        val example = TextView(this).apply { textSize = 15f; gravity = Gravity.CENTER; setTextColor(0xFF64748B.toInt()); setPadding(4, 10, 4, 0) }
        wordCard.addView(wordText); wordCard.addView(speaker); wordCard.addView(translation); wordCard.addView(example)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val previous = makeTile("← السابق", 0xFF64748B.toInt()) {}
        val reveal = makeTile("👁 إظهار الترجمة", 0xFF1769E8.toInt()) {}
        val next = makeTile("التالي ⟶", 0xFF059669.toInt()) {}
        nav.addView(previous, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 8, 2, 2) })
        nav.addView(reveal, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f).apply { setMargins(2, 8, 2, 2) })
        nav.addView(next, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 8, 2, 2) })
        val selfRate = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        var refresh: () -> Unit = {}
        val difficult = makeTile("🔴 صعب", 0xFFFCE7F3.toInt()) { index = (index + 1) % words.size; revealed = false; refresh() }
        difficult.setTextColor(0xFFBE185D.toInt())
        val known = makeTile("✅ أعرفها", 0xFFD1FAE5.toInt()) { index = (index + 1) % words.size; revealed = false; refresh() }
        known.setTextColor(0xFF047857.toInt())
        selfRate.addView(difficult, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 8, 2, 2) })
        selfRate.addView(known, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 8, 2, 2) })
        panel.addView(progress); panel.addView(progressBar); panel.addView(wordCard, marginParams()); panel.addView(nav); panel.addView(selfRate)
        val dialog = AlertDialog.Builder(this).setTitle("🃏 البطاقات التعليمية").setView(panel).setNegativeButton("إغلاق", null).create()
        refresh = {
            val w = words[index % words.size]
            progress.text = "${index + 1} / ${words.size}"
            progressBar.progress = index + 1
            wordText.text = w.pt
            translation.text = if (revealed) w.ar else "تذكّر المعنى ثم اضغط إظهار الترجمة"
            example.text = if (revealed && w.examplePt.isNotBlank()) "${w.examplePt}\n${w.exampleAr}" else ""
            reveal.text = if (revealed) "إخفاء الترجمة" else "👁 إظهار الترجمة"
        }
        previous.setOnClickListener { index = (index - 1 + words.size) % words.size; revealed = false; refresh() }
        next.setOnClickListener { index = (index + 1) % words.size; revealed = false; refresh() }
        reveal.setOnClickListener { revealed = !revealed; refresh() }
        refresh(); dialog.show()
    }

    private fun startQuiz() {
        if (words.size < 2) { toast("أضف كلمتين على الأقل لبدء الاختبار"); return }
        val quizWords = words.shuffled().take(minOf(10, words.size))
        var index = 0
        var score = 0
        var answered = false
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 8, 18, 14); background = rounded(0xFFF7F5FF.toInt(), 24) }
        val progress = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; setTextColor(0xFF475569.toInt()); setPadding(0, 4, 0, 8) }
        val progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = quizWords.size; this.progress = 1; progressTintList = android.content.res.ColorStateList.valueOf(0xFF8B5CF6.toInt()); progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xFFE9D5FF.toInt()) }
        val questionCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(18, 18, 18, 18); background = rounded(Color.WHITE, 22) }
        val prompt = TextView(this).apply { text = "ما ترجمة هذه الكلمة؟"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(0xFF64748B.toInt()) }
        val word = TextView(this).apply { textSize = 30f; gravity = Gravity.CENTER; setTextColor(0xFF4C1D95.toInt()); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 12, 0, 12) }
        val sound = makeTile("🔊 استمع", 0xFF7C3AED.toInt()) { speak(word.text.toString()) }
        questionCard.addView(prompt); questionCard.addView(word); questionCard.addView(sound)
        val optionsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val feedback = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER; setPadding(10, 10, 10, 10); visibility = View.GONE }
        val next = makeTile("التالي ⟶", 0xFF1769E8.toInt()) {}
        panel.addView(progress); panel.addView(progressBar); panel.addView(questionCard, marginParams()); panel.addView(optionsBox); panel.addView(feedback); panel.addView(next)
        val dialog = AlertDialog.Builder(this).setTitle("🎯 اختبار الكلمات").setView(panel).setNegativeButton("إغلاق", null).create()
        fun loadQuestion() {
            answered = false
            val item = quizWords[index]
            progress.text = "السؤال ${index + 1} من ${quizWords.size} • النتيجة $score"
            progressBar.progress = index + 1
            word.text = item.pt
            feedback.visibility = View.GONE
            optionsBox.removeAllViews()
            val options = (words.filter { it.pt != item.pt }.shuffled().take(3).map { it.ar } + item.ar).distinct().shuffled()
            options.forEachIndexed { optionIndex, option ->
                val button = makeTile("${('A'.code + optionIndex).toChar()}     $option", 0xFFFFFFFF.toInt()) {}.apply { setTextColor(0xFF243B53.toInt()); textSize = 17f; gravity = Gravity.CENTER_VERTICAL; background = rounded(Color.WHITE, 16) }
                button.setOnClickListener {
                    if (answered) return@setOnClickListener
                    answered = true
                    val correct = option == item.ar
                    if (correct) score++
                    feedback.visibility = View.VISIBLE
                    feedback.text = if (correct) "✅ صحيح! ${item.pt} = ${item.ar}" else "❌ الإجابة الصحيحة: ${item.ar}"
                    feedback.setTextColor(if (correct) 0xFF047857.toInt() else 0xFFB91C1C.toInt())
                    feedback.background = rounded(if (correct) 0xFFD1FAE5.toInt() else 0xFFFEE2E2.toInt(), 14)
                    for (childIndex in 0 until optionsBox.childCount) { val child = optionsBox.getChildAt(childIndex); if (child is Button) child.isEnabled = false }
                    button.background = rounded(if (correct) 0xFFD1FAE5.toInt() else 0xFFFEE2E2.toInt(), 16)
                }
                optionsBox.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 4, 0, 4) })
            }
            next.text = if (index == quizWords.lastIndex) "إنهاء الاختبار" else "التالي ⟶"
        }
        next.setOnClickListener {
            if (!answered) { toast("اختر إجابة أولًا"); return@setOnClickListener }
            if (index < quizWords.lastIndex) { index++; loadQuestion() }
            else { AlertDialog.Builder(this).setTitle("انتهى الاختبار 🎉").setMessage("نتيجتك: $score من ${quizWords.size}").setPositiveButton("حسنًا", null).show(); dialog.dismiss() }
        }
        loadQuestion(); dialog.show()
    }

    private fun speak(text: String) {
        if (!ttsReady) { toast("الصوت البرتغالي غير متاح حاليًا على الهاتف"); return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "word-${System.currentTimeMillis()}")
    }

    private fun importWords() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-excel", "text/csv", "text/comma-separated-values", "text/plain"
            ))
        }
        startActivityForResult(intent, importRequest)
    }

    private fun importFromUri(uri: Uri) {
        try {
            val name = (contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else ""
            } ?: "").lowercase(Locale.ROOT)
            val rows = if (name.endsWith(".xlsx")) readXlsx(uri) else readDelimited(uri)
            if (rows.isEmpty()) { toast("لم أجد صفوفًا في الملف"); return }
            val first = rows.first().map { it.trim().lowercase(Locale.ROOT) }
            val headerLikely = first.any { it.contains("portugu") || it == "pt" || it.contains("العربي") || it == "ar" || it.contains("ترجم") }
            var ptCol = 0; var arCol = 1; var exPtCol = 2; var exArCol = 3
            var startRow = 0
            if (headerLikely) {
                fun findCol(predicate: (String) -> Boolean, fallback: Int): Int = first.indexOfFirst(predicate).let { if (it >= 0) it else fallback }
                ptCol = findCol({ it.contains("portugu") || it == "pt" || it == "portugues" || it == "português" }, 0)
                arCol = findCol({ it.contains("العربي") || it == "ar" || it.contains("ترجم") }, if (ptCol == 0) 1 else 0)
                exPtCol = findCol({ it.contains("exemplo") || it.contains("مثال") && it.contains("برتغ") }, 2)
                exArCol = findCol({ it.contains("tradução do exemplo") || it.contains("ترجمة المثال") }, 3)
                startRow = 1
            }
            var added = 0; var updated = 0
            for (r in startRow until rows.size) {
                val row = rows[r]
                val pt = row.getOrNull(ptCol)?.trim().orEmpty()
                val ar = row.getOrNull(arCol)?.trim().orEmpty()
                if (pt.isBlank() || ar.isBlank()) continue
                val exPt = row.getOrNull(exPtCol)?.trim().orEmpty()
                val exAr = row.getOrNull(exArCol)?.trim().orEmpty()
                val index = words.indexOfFirst { it.pt.equals(pt, ignoreCase = true) }
                val word = Word(pt, ar, exPt, exAr)
                if (index >= 0) { words[index] = word; updated++ } else { words.add(word); added++ }
            }
            saveWords(); if (showingMyWords) showMyWords() else renderWords(); updateStatus()
            toast("تم الاستيراد: أضيف $added، وتم تحديث $updated كلمة")
        } catch (e: Exception) {
            toast("تعذر استيراد الملف. استخدم Excel بصيغة .xlsx أو CSV")
        }
    }

    private fun readDelimited(uri: Uri): List<List<String>> {
        val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: return emptyList()
        val lines = text.removePrefix("\uFEFF").split(Regex("\r?\n")).filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList()
        val delimiter = listOf('\t', ';', ',').maxByOrNull { d -> lines.first().count { it == d } } ?: ','
        return lines.map { line ->
            val cells = mutableListOf<String>(); val cell = StringBuilder(); var quoted = false; var i = 0
            while (i < line.length) {
                val ch = line[i]
                if (ch == '"') {
                    if (quoted && i + 1 < line.length && line[i + 1] == '"') { cell.append('"'); i++ } else quoted = !quoted
                } else if (ch == delimiter && !quoted) { cells.add(cell.toString()); cell.setLength(0) } else cell.append(ch)
                i++
            }
            cells.add(cell.toString()); cells
        }
    }

    private fun readXlsx(uri: Uri): List<List<String>> {
        val entries = mutableMapOf<String, ByteArray>()
        val input = contentResolver.openInputStream(uri) ?: return emptyList()
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && (entry.name == "xl/sharedStrings.xml" || entry.name == "xl/worksheets/sheet1.xml")) {
                    val out = ByteArrayOutputStream(); zip.copyTo(out); entries[entry.name] = out.toByteArray()
                }
                entry = zip.nextEntry
            }
        }
        val sheet = entries["xl/worksheets/sheet1.xml"] ?: return emptyList()
        val shared = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) } ?: emptyList()
        val result = mutableListOf<List<String>>()
        val parser = Xml.newPullParser(); parser.setInput(ByteArrayInputStream(sheet), "UTF-8")
        var event = parser.eventType; var inCell = false; var cellType = ""; var cellRef = ""; var value = ""; var inValue = false; var row = mutableMapOf<Int, String>()
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> row = mutableMapOf()
                    "c" -> { inCell = true; cellType = parser.getAttributeValue(null, "t") ?: ""; cellRef = parser.getAttributeValue(null, "r") ?: ""; value = "" }
                    "v", "t" -> if (inCell) inValue = true
                }
                XmlPullParser.TEXT -> if (inValue) value += parser.text
                XmlPullParser.END_TAG -> when (parser.name) {
                    "v", "t" -> inValue = false
                    "c" -> {
                        val col = cellRef.takeWhile { it.isLetter() }.fold(0) { acc, ch -> acc * 26 + (ch.uppercaseChar() - 'A' + 1) } - 1
                        val decoded = if (cellType == "s") shared.getOrNull(value.toIntOrNull() ?: -1).orEmpty() else value
                        if (col >= 0) row[col] = decoded
                        inCell = false
                    }
                    "row" -> if (row.isNotEmpty()) result.add((0..(row.keys.maxOrNull() ?: 0)).map { row[it].orEmpty() })
                }
            }
            event = parser.next()
        }
        return result
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val out = mutableListOf<String>(); val parser = Xml.newPullParser(); parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        var event = parser.eventType; var inSi = false; var inText = false; val current = StringBuilder()
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) { "si" -> { inSi = true; current.setLength(0) }; "t" -> if (inSi) inText = true }
                XmlPullParser.TEXT -> if (inSi && inText) current.append(parser.text)
                XmlPullParser.END_TAG -> when (parser.name) { "t" -> inText = false; "si" -> { out.add(current.toString()); inSi = false } }
            }
            event = parser.next()
        }
        return out
    }

    private fun exportWords() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "PortugueseWords.json") }
        startActivityForResult(intent, exportRequest)
    }

    @Deprecated("Deprecated in Android but kept for compatibility with target devices")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == importRequest && resultCode == RESULT_OK && data?.data != null) {
            importFromUri(data.data!!)
        }
        if (requestCode == exportRequest && resultCode == RESULT_OK && data?.data != null) {
            try {
                val arr = JSONArray(); words.forEach { arr.put(JSONObject().put("pt", it.pt).put("ar", it.ar).put("examplePt", it.examplePt).put("exampleAr", it.exampleAr)) }
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(arr.toString(2)) }
                toast("تم تصدير الكلمات بنجاح")
            } catch (e: Exception) { toast("تعذر التصدير: ${e.message}") }
        }
    }

    private fun loadWords() {
        words.clear()
        val arr = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) { val o = arr.optJSONObject(i) ?: continue; words.add(Word(o.optString("pt"), o.optString("ar"), o.optString("examplePt"), o.optString("exampleAr"))) }
    }
    private fun saveWords() { val arr = JSONArray(); words.forEach { arr.put(JSONObject().put("pt", it.pt).put("ar", it.ar).put("examplePt", it.examplePt).put("exampleAr", it.exampleAr)) }; prefs.edit().putString("items", arr.toString()).apply() }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
    }
    private fun requestExactAlarmThenSchedule() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotificationPermission()
            toast("اسمح بالإشعارات ثم اضغط تشغيل مرة أخرى")
            return
        }
        prefs.edit().putBoolean("reminders_enabled", true).apply()
        ReminderScheduler.scheduleNext(this)
        updateStatus("التذكير يعمل في الخلفية: كل ${prefs.getInt("interval_minutes", 5)} دقيقة بين 08:00 و22:00")
        if (Build.VERSION.SDK_INT >= 23) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                AlertDialog.Builder(this)
                    .setTitle("السماح بالعمل في الخلفية")
                    .setMessage("لتحسين انتظام التذكيرات والشاشة مقفلة، اسمح للتطبيق بتجاوز تحسين البطارية. قد يزيد ذلك استهلاك البطارية، خصوصًا عند اختيار تذكير كل دقيقة.")
                    .setPositiveButton("فتح الإعدادات") { _, _ ->
                        try {
                            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                        } catch (_: Exception) {
                            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                        }
                    }
                    .setNegativeButton("لاحقًا", null)
                    .show()
            }
        }
    }
    private fun updateStatus(message: String? = null) { status.text = message ?: "عدد الكلمات المحفوظة: ${words.size}\nالتذكير: كل ${prefs.getInt("interval_minutes", 5)} دقيقة، 08:00–22:00" }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

object ReminderScheduler {
    fun scheduleNext(context: Context) {
        val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("reminders_enabled", false)) return
        val intent = Intent(context, ReminderService::class.java).setAction(ReminderService.ACTION_RESCHEDULE)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        } catch (_: Exception) {
            // The UI will remain usable; the user can tap Start again if Android blocks service startup.
        }
    }

    fun cancel(context: Context) {
        context.stopService(Intent(context, ReminderService::class.java))
        val alarmIntent = PendingIntent.getBroadcast(context, 12, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(alarmIntent)
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(1001)
    }
}

class ReminderService : Service() {
    companion object {
        const val ACTION_RESCHEDULE = "com.bekri.wordreminder.RESCHEDULE"
        private const val SERVICE_NOTIFICATION_ID = 2001
        private const val WORD_NOTIFICATION_ID = 1001
        private const val SERVICE_CHANNEL = "reminder_service"
        private const val WORD_CHANNEL = "words"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null
    private var index = 0
    private val tick = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences("words", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("reminders_enabled", false)) {
                stopSelf()
                return
            }
            val now = java.util.Calendar.getInstance()
            val hour = now.get(java.util.Calendar.HOUR_OF_DAY)
            if (hour >= 22 || hour < 8) {
                val next = java.util.Calendar.getInstance().apply {
                    if (hour >= 22) add(java.util.Calendar.DAY_OF_YEAR, 1)
                    set(java.util.Calendar.HOUR_OF_DAY, 8)
                    set(java.util.Calendar.MINUTE, 0)
                    set(java.util.Calendar.SECOND, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                }
                releaseWakeLock() // Do not keep the CPU awake overnight.
                scheduleMorningWake(next.timeInMillis)
                return
            }
            val arr = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
            if (arr.length() > 0) {
                if (index >= arr.length()) index = 0
                val item = arr.optJSONObject(index)
                if (item != null) {
                    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                    val open = PendingIntent.getActivity(this@ReminderService, 2, Intent(this@ReminderService, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this@ReminderService, WORD_CHANNEL) else android.app.Notification.Builder(this@ReminderService)
                    val text = "${item.optString("pt")} — ${item.optString("ar")}"
                    val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle(item.optString("pt"))
                        .setContentText(item.optString("ar"))
                        .setStyle(android.app.Notification.BigTextStyle().bigText(text))
                        .setContentIntent(open)
                        .setAutoCancel(true)
                        .build()
                    // Cancel first so Android treats each reminder as a fresh alert, even for a one-word list.
                    manager.cancel(WORD_NOTIFICATION_ID)
                    manager.notify(WORD_NOTIFICATION_ID, notification)
                    index = (index + 1) % arr.length()
                    prefs.edit().putInt("next_index", index).apply()
                }
            }
            val minutes = prefs.getInt("interval_minutes", 5).coerceIn(1, 10)
            handler.postDelayed(this, minutes * 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WordReminder:ReminderLoop").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
    }

    private fun scheduleMorningWake(at: Long) {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java).setAction("com.bekri.wordreminder.MORNING_WAKE")
        val pi = PendingIntent.getBroadcast(this, 13, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else alarm.setExact(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: SecurityException) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            manager.createNotificationChannel(android.app.NotificationChannel(SERVICE_CHANNEL, "حالة التذكير", android.app.NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
            manager.createNotificationChannel(android.app.NotificationChannel(WORD_CHANNEL, "تذكير الكلمات", android.app.NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, SERVICE_CHANNEL) else android.app.Notification.Builder(this)
        val ongoing = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("كلمات البرتغالية")
            .setContentText("التذكير نشط في الخلفية")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(SERVICE_NOTIFICATION_ID, ongoing, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(SERVICE_NOTIFICATION_ID, ongoing)
        }
        handler.removeCallbacks(tick)
        val prefs = getSharedPreferences("words", Context.MODE_PRIVATE)
        if (prefs.getBoolean("reminders_enabled", false)) {
            val now = java.util.Calendar.getInstance()
            val hour = now.get(java.util.Calendar.HOUR_OF_DAY)
            if (hour >= 22 || hour < 8) {
                val next = java.util.Calendar.getInstance().apply {
                    if (hour >= 22) add(java.util.Calendar.DAY_OF_YEAR, 1)
                    set(java.util.Calendar.HOUR_OF_DAY, 8); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
                }
                releaseWakeLock()
                scheduleMorningWake(next.timeInMillis)
            } else {
                acquireWakeLock()
                index = prefs.getInt("next_index", 0).coerceAtLeast(0)
                val minutes = prefs.getInt("interval_minutes", 5).coerceIn(1, 10)
                handler.postDelayed(tick, minutes * 60_000L)
            }
        } else {
            stopSelf()
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Keep the user-enabled reminder service running when the app is swiped from Recents.
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(SERVICE_NOTIFICATION_ID)
        }
        releaseWakeLock()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}

class ReminderReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
        if (prefs.getBoolean("reminders_enabled", false) && intent?.action == "com.bekri.wordreminder.MORNING_WAKE") {
            ReminderScheduler.scheduleNext(context)
        }
    }
}

class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
            if (prefs.getBoolean("reminders_enabled", false)) ReminderScheduler.scheduleNext(context)
        }
    }
}
