package com.bekri.wordreminder

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.*
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

 data class Word(val pt: String, val ar: String, val examplePt: String = "", val exampleAr: String = "")

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val prefs by lazy { getSharedPreferences("words", MODE_PRIVATE) }
    private val words = mutableListOf<Word>()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var intervalSpinner: Spinner
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val exportRequest = 431
    private val importRequest = 432
    private var showingMyWords = false
    private var showingConjugations = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        loadWords()
        buildUi()
        askNotificationPermission()
        updateStatus()
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("pt", "PT"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun buildUi() {
        showingMyWords = false
        val dark = prefs.getBoolean("home_dark", false)
        val bg = if (dark) 0xFF101827.toInt() else 0xFFF1F8FF.toInt()
        val ink = if (dark) Color.WHITE else 0xFF14294D.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
            setBackgroundColor(bg)
            setOnApplyWindowInsetsListener { view, insets ->
                val top: Int; val bottom: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    top = bars.top; bottom = bars.bottom
                } else {
                    @Suppress("DEPRECATION")
                    run { top = insets.systemWindowInsetTop; bottom = insets.systemWindowInsetBottom }
                }
                view.setPadding(0, top, 0, bottom); insets
            }
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 8, 14, 8) }
        scroll.addView(content)

        // Hero area: scenic Portuguese banner, app title, couple label and theme switch.
        val hero = FrameLayout(this).apply {
            background = rounded(0xFF168FE8.toInt(), 28); clipToOutline = true; elevation = 3f
        }
        hero.addView(ImageView(this).apply {
            setImageResource(R.drawable.portugal_banner); scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "منظر ساحلي من البرتغال"
        }, FrameLayout.LayoutParams(-1, (270 * resources.displayMetrics.density).toInt()))
        val shade = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x220057B8, 0x000057B8, 0x990057B8.toInt()))
        }
        hero.addView(shade, FrameLayout.LayoutParams(-1, (270 * resources.displayMetrics.density).toInt()))
        val heroColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(12, 42, 12, 12) }
        val logo = ImageView(this).apply { setImageResource(R.drawable.portugal_book_icon); scaleType = ImageView.ScaleType.FIT_CENTER; contentDescription = "كتاب اللغة البرتغالية" }
        heroColumn.addView(logo, LinearLayout.LayoutParams((142 * resources.displayMetrics.density).toInt(), (112 * resources.displayMetrics.density).toInt()))
        heroColumn.addView(TextView(this).apply { text = "Português"; textSize = 31f; setTextColor(0xFF092A70.toInt()); gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD) })
        heroColumn.addView(TextView(this).apply { text = "تعلّم يوميًا"; textSize = 21f; setTextColor(0xFF102A55.toInt()); gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD) })
        heroColumn.addView(TextView(this).apply { text = "♥  Racha & Med  ♥"; textSize = 17f; setTextColor(0xFF14294D.toInt()); gravity = Gravity.CENTER; setPadding(14, 5, 14, 5); background = rounded(0xFFFFD6E4.toInt(), 22) })
        hero.addView(heroColumn, FrameLayout.LayoutParams(-1, (270 * resources.displayMetrics.density).toInt()))
        val settings = TextView(this).apply {
            text = "⚙"; textSize = 25f; gravity = Gravity.CENTER; setTextColor(0xFF243B60.toInt()); background = rounded(Color.WHITE, 50); elevation = 2f
            setOnClickListener { showSettingsDialog() }
        }
        hero.addView(settings, FrameLayout.LayoutParams((48 * resources.displayMetrics.density).toInt(), (48 * resources.displayMetrics.density).toInt(), Gravity.TOP or Gravity.START).apply { leftMargin = 12; topMargin = 12 })
        val theme = TextView(this).apply {
            text = if (dark) "🌙  ☀️" else "☀️  🌙"; textSize = 19f; gravity = Gravity.CENTER; setTextColor(0xFF14294D.toInt()); background = rounded(Color.WHITE, 30); setPadding(12, 7, 12, 7); elevation = 2f
            setOnClickListener { prefs.edit().putBoolean("home_dark", !dark).apply(); buildUi() }
        }
        hero.addView(theme, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (44 * resources.displayMetrics.density).toInt(), Gravity.TOP or Gravity.END).apply { rightMargin = 12; topMargin = 14 })
        content.addView(hero, LinearLayout.LayoutParams(-1, (270 * resources.displayMetrics.density).toInt()).apply { bottomMargin = (10 * resources.displayMetrics.density).toInt() })

        // Saved words / reminder summary card.
        val summary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 13, 16, 12); background = rounded(if (dark) 0xFF202B3C.toInt() else Color.WHITE, 22); elevation = 2f }
        val topSummary = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val book = ImageView(this).apply { setImageResource(R.drawable.open_book_icon); scaleType = ImageView.ScaleType.FIT_CENTER }
        topSummary.addView(book, LinearLayout.LayoutParams((70 * resources.displayMetrics.density).toInt(), (60 * resources.displayMetrics.density).toInt()))
        val countCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 0, 0, 0) }
        countCol.addView(TextView(this).apply { text = "عدد الكلمات المحفوظة:"; textSize = 16f; setTextColor(ink) })
        countCol.addView(TextView(this).apply { text = words.size.toString(); textSize = 28f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD) })
        topSummary.addView(countCol, LinearLayout.LayoutParams(0, -2, 1f))
        val progressCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 500; progress = words.size.coerceAtMost(500); progressTintList = android.content.res.ColorStateList.valueOf(0xFF39C979.toInt()); progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xFFD9E6F2.toInt()) }
        progressCol.addView(progress, LinearLayout.LayoutParams((125 * resources.displayMetrics.density).toInt(), (10 * resources.displayMetrics.density).toInt()))
        progressCol.addView(TextView(this).apply { text = "${words.size} / 500"; textSize = 13f; gravity = Gravity.END; setTextColor(ink) })
        topSummary.addView(progressCol)
        summary.addView(topSummary)
        summary.addView(TextView(this).apply { text = "◷  التذكير: كل ${prefs.getInt("interval_minutes", 5)} دقائق، 08:00 – 22:00"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(ink); setPadding(0, 9, 0, 0) })
        content.addView(summary, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = (12 * resources.displayMetrics.density).toInt() })

        // Two-column colorful feature cards, each with its own illustration.
        fun featureRow(left: View, right: View) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(left, LinearLayout.LayoutParams(0, (142 * resources.displayMetrics.density).toInt(), 1f).apply { setMargins(0, 0, 6, 7) })
            row.addView(right, LinearLayout.LayoutParams(0, (142 * resources.displayMetrics.density).toInt(), 1f).apply { setMargins(6, 0, 0, 7) })
            content.addView(row)
        }
        featureRow(homeCard(R.drawable.books_icon, "تعلم الكلمات", "البطاقات التعليمية", 0xFF00A66A.toInt()) { startFlashcards() },
            homeCard(R.drawable.target_icon, "اختبار الكلمات", "اختر مستواك", 0xFF6425E8.toInt()) { startQuiz() })
        featureRow(homeCard(R.drawable.running_icon, "تصريف الأفعال", "جميع الأزمنة", 0xFFFF8A00.toInt()) { showConjugations() },
            homeCard(R.drawable.excel_icon, "استيراد كلمات", "Excel", 0xFF087AF0.toInt()) { importWords() })
        featureRow(homeCard(R.drawable.open_book_icon, "الجمل والأمثلة", "أمثلة وحوارات", 0xFFE91E78.toInt()) { showExamples() },
            homeCard(R.drawable.search_icon, "كلماتي", "البحث والتصنيف", 0xFF00A9A5.toInt()) { showMyWords() })
        featureRow(homeCard(R.drawable.pencil_icon, "إضافة كلمة", "أضف مفردات جديدة", 0xFF2876E8.toInt()) { editWord(null) },
            homeCard(R.drawable.speaker_icon, "التذكيرات", "تشغيل التذكير", 0xFF168B55.toInt()) { requestExactAlarmThenSchedule() })
        val extra = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 5, 0, 4) }
        extra.addView(makeTile("📤 تصدير Excel", 0xFF0D9488.toInt()) { exportWords() }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(3, 0, 3, 0) })
        extra.addView(makeTile("■ إيقاف التذكير", 0xFF64748B.toInt()) { prefs.edit().putBoolean("reminders_enabled", false).apply(); ReminderScheduler.cancel(this@MainActivity); updateStatus("تم إيقاف التذكيرات") }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(3, 0, 3, 0) })
        content.addView(extra)
        content.addView(TextView(this).apply { text = "كلماتي المحفوظة"; textSize = 19f; setTextColor(ink); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(4, 12, 4, 4) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(4, 5, 4, 5); background = rounded(if (dark) 0xFF202B3C.toInt() else Color.WHITE, 20); elevation = 5f }
        fun navItem(label: String, icon: String, action: () -> Unit) = TextView(this).apply {
            text = "$icon\n$label"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(if (label == "الرئيسية") 0xFF087AF0.toInt() else if (dark) 0xFFD8E2F0.toInt() else 0xFF64748B.toInt()); setPadding(2, 4, 2, 4); setOnClickListener { action() }
        }
        nav.addView(navItem("الرئيسية", "⌂") { buildUi() }, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(navItem("كلماتي", "◧") { showMyWords() }, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(navItem("إضافة", "⊕") { editWord(null) }, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(navItem("الإحصائيات", "▥") { showStats() }, LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(navItem("المزيد", "•••") { showSettingsDialog() }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(nav, LinearLayout.LayoutParams(-1, -2).apply { setMargins(10, 4, 10, 5) })
        setContentView(root)
        renderWords()
    }

    private fun homeCard(iconRes: Int, title: String, subtitle: String, color: Int, action: () -> Unit): View {
        val card = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(lighten(color, 0.18f), color)).apply { cornerRadius = 24 * resources.displayMetrics.density }
            elevation = 3f; isClickable = true; isFocusable = true; setOnClickListener { action() }
        }
        val icon = ImageView(this).apply { setImageResource(iconRes); scaleType = ImageView.ScaleType.FIT_CENTER; contentDescription = title }
        card.addView(icon, FrameLayout.LayoutParams((68 * resources.displayMetrics.density).toInt(), (65 * resources.displayMetrics.density).toInt(), Gravity.TOP or Gravity.START).apply { leftMargin = (14 * resources.displayMetrics.density).toInt(); topMargin = (9 * resources.displayMetrics.density).toInt() })
        card.addView(TextView(this).apply { text = "›"; textSize = 29f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); background = rounded(0x55FFFFFF, 50) }, FrameLayout.LayoutParams((38 * resources.displayMetrics.density).toInt(), (38 * resources.displayMetrics.density).toInt(), Gravity.TOP or Gravity.END).apply { rightMargin = (12 * resources.displayMetrics.density).toInt(); topMargin = (18 * resources.displayMetrics.density).toInt() })
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 0, 8, 0) }
        labels.addView(TextView(this).apply { text = title; textSize = 17f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) })
        labels.addView(TextView(this).apply { text = subtitle; textSize = 14f; setTextColor(0xFFF4F8FF.toInt()) })
        card.addView(labels, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = (13 * resources.displayMetrics.density).toInt() })
        return card
    }

    private fun showStats() {
        val nouns = words.count { !it.pt.endsWith("ar") && !it.pt.endsWith("er") && !it.pt.endsWith("ir") }
        val verbs = words.size - nouns
        AlertDialog.Builder(this).setTitle("الإحصائيات").setMessage("عدد الكلمات المحفوظة: ${words.size}\nهدفك: 500 كلمة\nاستمر في التعلّم يوميًا!") .setPositiveButton("حسنًا", null).show()
    }

    private fun showSettingsDialog() {
        val options = arrayOf("تبديل الوضع النهاري / الليلي", "تشغيل التذكير", "إيقاف التذكير", "تصدير الكلمات إلى Excel")
        AlertDialog.Builder(this).setTitle("الإعدادات والمزيد").setItems(options) { _, which ->
            when (which) {
                0 -> { prefs.edit().putBoolean("home_dark", !prefs.getBoolean("home_dark", false)).apply(); buildUi() }
                1 -> requestExactAlarmThenSchedule()
                2 -> { prefs.edit().putBoolean("reminders_enabled", false).apply(); ReminderScheduler.cancel(this); updateStatus("تم إيقاف التذكيرات") }
                3 -> exportWords()
            }
        }.show()
    }

    private fun showMyWords() {
        showingMyWords = true
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 8)
            setBackgroundColor(0xFFF4F7FC.toInt())
            setOnApplyWindowInsetsListener { view, insets ->
                val top: Int
                val bottom: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    top = bars.top; bottom = bars.bottom
                } else {
                    @Suppress("DEPRECATION")
                    run { top = insets.systemWindowInsetTop; bottom = insets.systemWindowInsetBottom }
                }
                view.setPadding((16 * resources.displayMetrics.density).toInt(), top + (8 * resources.displayMetrics.density).toInt(), (16 * resources.displayMetrics.density).toInt(), bottom + (8 * resources.displayMetrics.density).toInt())
                insets
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(16, 16, 16, 16)
            background = rounded(0xFF1769E8.toInt(), 24)
        }
        header.addView(TextView(this).apply { text = "🇵🇹 كلمات البرتغالية"; textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setTypeface(null, android.graphics.Typeface.BOLD) })
        header.addView(TextView(this).apply { text = "قائمة كلماتك المحفوظة"; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 4, 0, 0) })
        root.addView(header, marginParams())

        val summary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12); background = rounded(Color.WHITE, 18) }
        val count = TextView(this).apply { text = "📘 ${words.size} كلمة محفوظة"; textSize = 20f; setTextColor(0xFF102A43.toInt()); setTypeface(null, android.graphics.Typeface.BOLD) }
        summary.addView(count)
        val search = EditText(this).apply {
            hint = "🔎 ابحث عن كلمة أو ترجمة..."; textSize = 16f; isSingleLine = true; setPadding(14, 10, 14, 10)
            background = rounded(0xFFF0F4FA.toInt(), 16)
        }
        val searchParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 10 }
        summary.addView(search, searchParams)
        root.addView(summary, marginParams())

        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val filters = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 2, 0, 2) }
        val categories = listOf("الكل", "الأسماء", "الأفعال", "الصفات")
        var activeCategory = "الكل"
        val categoryButtons = mutableMapOf<String, Button>()
        categories.forEach { category ->
            val b = Button(this).apply {
                text = category; textSize = 12f; isAllCaps = false; setPadding(2, 2, 2, 2)
                setTextColor(if (category == activeCategory) Color.WHITE else 0xFF334155.toInt())
                background = rounded(if (category == activeCategory) 0xFF1769E8.toInt() else Color.WHITE, 14)
            }
            b.setOnClickListener {
                activeCategory = category
                categoryButtons.forEach { (name, button) ->
                    button.setTextColor(if (name == activeCategory) Color.WHITE else 0xFF334155.toInt())
                    button.background = rounded(if (name == activeCategory) 0xFF1769E8.toInt() else Color.WHITE, 14)
                }
                renderMyWordRows(search.text.toString(), activeCategory, rows, count)
            }
            categoryButtons[category] = b
            filters.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 2, 2, 2) })
        }
        root.addView(filters, marginParams())
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(rows) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 5, 0, 0) }
        bottom.addView(makeTile("⌂ الرئيسية", 0xFF64748B.toInt()) { showingMyWords = false; buildUi() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(makeTile("＋ إضافة", 0xFF168B55.toInt()) { editWord(null) ; renderMyWordRows(search.text.toString(), activeCategory, rows, count) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(makeTile("🃏 البطاقات", 0xFF7C3AED.toInt()) { startFlashcards() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bottom.addView(makeTile("🎯 الاختبار", 0xFFDB2777.toInt()) { startQuiz() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(bottom)
        setContentView(root)
        renderMyWordRows("", activeCategory, rows, count)
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, countChanged: Int) { renderMyWordRows(s?.toString().orEmpty(), activeCategory, rows, count) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun wordCategory(word: Word): String {
        val w = word.pt.lowercase(Locale.ROOT)
        val verbStem = w.removeSuffix("-se")
        val verbs = setOf("ser", "estar", "ter", "fazer", "ir", "vir", "ver", "dizer", "poder", "querer", "saber", "dar", "ficar", "trabalhar", "comer", "beber", "falar", "morar", "estudar", "aprender", "soletrar", "chamar-se", "gostar", "precisar", "abrir", "fechar", "ler", "escrever", "ouvir", "andar", "comprar", "vender", "viver", "sentir", "dormir", "sair", "entrar")
        return when {
            w in verbs || verbStem in verbs || verbStem.endsWith("ar") || verbStem.endsWith("er") || verbStem.endsWith("ir") -> "الأفعال"
            w.endsWith("oso") || w.endsWith("osa") || w.endsWith("ico") || w.endsWith("ica") || w.endsWith("ável") || w.endsWith("ível") || w.endsWith("ente") || w.endsWith("al") -> "الصفات"
            else -> "الأسماء"
        }
    }

    private fun renderMyWordRows(query: String, category: String, rows: LinearLayout, count: TextView) {
        rows.removeAllViews()
        val filtered = words.withIndex().filter { (_, word) ->
            val matchesText = query.isBlank() || word.pt.contains(query, true) || word.ar.contains(query, true) || word.examplePt.contains(query, true) || word.exampleAr.contains(query, true)
            val matchesCategory = category == "الكل" || wordCategory(word) == category
            matchesText && matchesCategory
        }
        count.text = "📘 ${words.size} كلمة محفوظة • النتائج: ${filtered.size}"
        if (filtered.isEmpty()) {
            rows.addView(TextView(this).apply { text = "لا توجد كلمات مطابقة. جرّب بحثًا آخر أو أضف كلمة جديدة."; textSize = 16f; setTextColor(0xFF64748B.toInt()); setPadding(16, 24, 16, 24); background = rounded(Color.WHITE, 18) }, marginParams())
            return
        }
        filtered.forEach { indexed ->
            val i = indexed.index; val w = indexed.value
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 12); background = rounded(Color.WHITE, 18) }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val wordsText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            wordsText.addView(TextView(this).apply { text = w.pt; textSize = 22f; setTextColor(0xFF102A43.toInt()); setTypeface(null, android.graphics.Typeface.BOLD) })
            wordsText.addView(TextView(this).apply { text = w.ar; textSize = 18f; setTextColor(0xFF52677F.toInt()); setPadding(0, 3, 0, 0) })
            top.addView(wordsText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val categoryColor = when (wordCategory(w)) { "الأفعال" -> 0xFFFFE7A3.toInt(); "الصفات" -> 0xFFFCE0F0.toInt(); else -> 0xFFD8F8E5.toInt() }
            top.addView(TextView(this).apply { text = when (wordCategory(w)) { "الأفعال" -> "🏃 فعل"; "الصفات" -> "★ صفة"; else -> "⌂ اسم" }; textSize = 12f; setTextColor(0xFF334155.toInt()); setPadding(9, 7, 9, 7); background = rounded(categoryColor, 18) })
            card.addView(top)
            if (w.examplePt.isNotBlank()) card.addView(TextView(this).apply { text = "${w.examplePt}\n${w.exampleAr}"; textSize = 14f; setTextColor(0xFF52677F.toInt()); setPadding(10, 8, 10, 8); background = rounded(0xFFF1F5F9.toInt(), 12) }, marginParams())
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            actions.addView(makeTile("🔊 نطق", 0xFF1769E8.toInt()) { speak(w.pt) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 5, 3, 0) })
            actions.addView(makeTile("✎ تعديل", 0xFF64748B.toInt()) { editWord(i); rows.post { renderMyWordRows(query, category, rows, count) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 5, 3, 0) })
            actions.addView(makeTile("▤ حذف", 0xFFDC2626.toInt()) { confirmDelete(i); rows.post { renderMyWordRows(query, category, rows, count) } }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 5, 0, 0) })
            card.addView(actions)
            rows.addView(card, marginParams())
        }
    }

    override fun onBackPressed() {
        if (showingMyWords || showingConjugations) {
            showingMyWords = false
            showingConjugations = false
            buildUi()
        } else super.onBackPressed()
    }

    private fun showConjugations() {
        showingConjugations = true
        showingMyWords = false
        val verbs = words.filter { wordCategory(it) == "الأفعال" }
            .distinctBy { it.pt.lowercase(Locale.ROOT) }
            .sortedBy { it.pt.lowercase(Locale.ROOT) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 8)
            setBackgroundColor(0xFFF4F7FC.toInt())
            setOnApplyWindowInsetsListener { view, insets ->
                val top: Int
                val bottom: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    top = bars.top; bottom = bars.bottom
                } else {
                    @Suppress("DEPRECATION")
                    run { top = insets.systemWindowInsetTop; bottom = insets.systemWindowInsetBottom }
                }
                view.setPadding((14 * resources.displayMetrics.density).toInt(), top + (8 * resources.displayMetrics.density).toInt(), (14 * resources.displayMetrics.density).toInt(), bottom + (8 * resources.displayMetrics.density).toInt())
                insets
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 14, 12, 14)
            background = rounded(0xFF1769E8.toInt(), 20)
        }
        header.addView(makeTile("← رجوع", 0xFF0D47A1.toInt()) {
            showingConjugations = false
            buildUi()
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        header.addView(TextView(this).apply {
            text = "تصريف الأفعال"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "🇵🇹"
            textSize = 25f
            gravity = Gravity.CENTER
        })
        root.addView(header, marginParams())

        val search = EditText(this).apply {
            hint = "🔎 ابحث عن فعل..."
            textSize = 16f
            isSingleLine = true
            setPadding(12, 8, 12, 8)
            background = rounded(Color.WHITE, 16)
        }
        root.addView(search, marginParams())

        val verbScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val verbButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        verbScroll.addView(verbButtons)
        root.addView(verbScroll, marginParams())

        val tenseRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val detailScroll = ScrollView(this).apply { isFillViewport = true }
        val detail = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 4, 4, 12) }
        detailScroll.addView(detail)
        tenseRow.visibility = View.GONE
        root.addView(tenseRow, marginParams())
        root.addView(detailScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(makeTile("＋ إضافة فعل جديد", 0xFF168B55.toInt()) {
            editWord(null)
        }, marginParams())

        root.addView(makeTile("⌂ الرئيسية", 0xFF64748B.toInt()) {
            showingConjugations = false
            buildUi()
        }, marginParams())

        setContentView(root)

        var selectedVerb = verbs.firstOrNull()
        var selectedTense = "المضارع"
        val tenseColors = mapOf("المضارع" to 0xFF059669.toInt(), "الماضي" to 0xFFF59E0B.toInt(), "المستقبل" to 0xFF7C3AED.toInt())

        fun renderDetail() {
            detail.removeAllViews()
            val verb = selectedVerb
            if (verb == null) {
                detail.addView(TextView(this).apply {
                    text = "لم تضف أفعالًا بعد.\nأضف فعلًا مثل ser أو trabalhar، وسيظهر هنا تلقائيًا."
                    textSize = 17f; setTextColor(0xFF475569.toInt()); gravity = Gravity.CENTER; setPadding(20, 30, 20, 30)
                    background = rounded(Color.WHITE, 18)
                }, marginParams())
                return
            }
            val titleCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 14, 16, 14); background = rounded(Color.WHITE, 18) }
            val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            titleRow.addView(TextView(this).apply { text = verb.pt; textSize = 28f; setTextColor(0xFF102A43.toInt()); setTypeface(null, android.graphics.Typeface.BOLD) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            titleRow.addView(makeTile("🔊", 0xFF1769E8.toInt()) { speak(verb.pt) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            titleCard.addView(titleRow)
            titleCard.addView(TextView(this).apply { text = verb.ar; textSize = 19f; setTextColor(0xFF52677F.toInt()); setPadding(0, 3, 0, 0) })
            detail.addView(titleCard, marginParams())

            val pronouns = listOf("eu", "tu", "ele / ela", "nós", "vocês", "eles / elas")
            val arabicPronouns = listOf("أنا", "أنتَ / أنتِ", "هو / هي", "نحن", "أنتم", "هم / هن")
            listOf("المضارع", "الماضي", "المستقبل").forEach { tense ->
                val section = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(9, 8, 9, 9)
                    background = rounded(Color.WHITE, 16)
                }
                section.addView(TextView(this).apply {
                    text = when (tense) {
                        "الماضي" -> "🕘 الماضي — Pretérito perfeito"
                        "المستقبل" -> "📅 المستقبل — Futuro simples"
                        else -> "☀️ المضارع — Presente"
                    }
                    textSize = 17f
                    setTextColor(tenseColors[tense] ?: 0xFF1769E8.toInt())
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setPadding(5, 6, 5, 8)
                })
                val forms = conjugationForms(verb.pt, tense)
                val table = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(0xFFEAF1FA.toInt(), 12); setPadding(5, 4, 5, 4) }
                pronouns.forEachIndexed { index, pronoun ->
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(5, 4, 5, 4)
                        if (index % 2 == 0) background = rounded(Color.WHITE, 9)
                    }
                    row.addView(TextView(this).apply {
                        text = pronoun
                        textSize = 12f
                        setTextColor(0xFF64748B.toInt())
                    }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.85f))
                    row.addView(makeTile("🔊", 0xFF1769E8.toInt()) {
                        val form = forms.getOrElse(index) { "" }
                        if (form.isNotBlank() && form != "—") speak(form)
                    }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(2, 0, 5, 0) })
                    row.addView(TextView(this).apply {
                        text = forms.getOrElse(index) { "—" }
                        textSize = 15f
                        setTextColor(0xFF102A43.toInt())
                        setTypeface(null, android.graphics.Typeface.BOLD)
                        gravity = Gravity.CENTER
                    }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.15f))
                    row.addView(TextView(this).apply {
                        text = arabicPronouns[index]
                        textSize = 12f
                        setTextColor(0xFF52677F.toInt())
                        gravity = Gravity.END
                    }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                    table.addView(row)
                }
                section.addView(table)
                detail.addView(section, marginParams())
            }
            detail.addView(makeTile("🔊 سماع الفعل", 0xFF1769E8.toInt()) { speak(verb.pt) }, marginParams())
            detail.addView(TextView(this).apply {
                text = "اضغط على زر 🔊 بجانب أي تصريف لسماع نطقه بالبرتغالية الأوروبية.\nملاحظة: الأفعال غير المنتظمة الشائعة لها تصريفات خاصة؛ الأفعال الأخرى تُصرّف وفق القاعدة العامة."
                textSize = 12f; setTextColor(0xFF64748B.toInt()); setPadding(4, 8, 4, 8)
            })
        }

        fun renderTenses() {
            tenseRow.removeAllViews()
            listOf("المضارع", "الماضي", "المستقبل").forEach { tense ->
                val button = makeTile(
                    when (tense) { "الماضي" -> "🕘 الماضي"; "المستقبل" -> "📅 المستقبل"; else -> "☀️ المضارع" },
                    if (selectedTense == tense) tenseColors[tense]!! else 0xFFE2E8F0.toInt()
                ) { selectedTense = tense; renderTenses(); renderDetail() }
                if (selectedTense != tense) button.setTextColor(0xFF334155.toInt())
                tenseRow.addView(button, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 2, 2, 2) })
            }
        }

        fun renderVerbButtons(query: String = "") {
            verbButtons.removeAllViews()
            val matching = verbs.filter { it.pt.contains(query, true) || it.ar.contains(query, true) }
            if (matching.isEmpty()) {
                verbButtons.addView(TextView(this).apply { text = "لا توجد أفعال مطابقة"; textSize = 14f; setTextColor(0xFF64748B.toInt()); setPadding(10, 12, 10, 12) })
            }
            matching.forEach { verb ->
                val button = makeTile(verb.pt, if (selectedVerb?.pt == verb.pt) 0xFF1769E8.toInt() else Color.WHITE) {
                    selectedVerb = verb
                    renderVerbButtons(search.text.toString())
                    renderDetail()
                }
                if (selectedVerb?.pt != verb.pt) button.setTextColor(0xFF102A43.toInt())
                verbButtons.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(3, 2, 3, 2) })
            }
        }

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderVerbButtons(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        renderVerbButtons()
        renderDetail()
    }

    private fun conjugationForms(rawVerb: String, tense: String): List<String> {
        val verb = rawVerb.trim().lowercase(Locale.ROOT).removeSuffix("-se")
        val irregular = mapOf(
            "ser" to mapOf(
                "المضارع" to listOf("sou", "és", "é", "somos", "são", "são"),
                "الماضي" to listOf("fui", "foste", "foi", "fomos", "foram", "foram"),
                "المستقبل" to listOf("serei", "serás", "será", "seremos", "serão", "serão")
            ),
            "estar" to mapOf(
                "المضارع" to listOf("estou", "estás", "está", "estamos", "estão", "estão"),
                "الماضي" to listOf("estive", "estiveste", "esteve", "estivemos", "estiveram", "estiveram"),
                "المستقبل" to listOf("estarei", "estarás", "estará", "estaremos", "estarão", "estarão")
            ),
            "ter" to mapOf(
                "المضارع" to listOf("tenho", "tens", "tem", "temos", "têm", "têm"),
                "الماضي" to listOf("tive", "tiveste", "teve", "tivemos", "tiveram", "tiveram"),
                "المستقبل" to listOf("terei", "terás", "terá", "teremos", "terão", "terão")
            ),
            "ir" to mapOf(
                "المضارع" to listOf("vou", "vais", "vai", "vamos", "vão", "vão"),
                "الماضي" to listOf("fui", "foste", "foi", "fomos", "foram", "foram"),
                "المستقبل" to listOf("irei", "irás", "irá", "iremos", "irão", "irão")
            ),
            "fazer" to mapOf(
                "المضارع" to listOf("faço", "fazes", "faz", "fazemos", "fazem", "fazem"),
                "الماضي" to listOf("fiz", "fizeste", "fez", "fizemos", "fizeram", "fizeram"),
                "المستقبل" to listOf("farei", "farás", "fará", "faremos", "farão", "farão")
            ),
            "poder" to mapOf(
                "المضارع" to listOf("posso", "podes", "pode", "podemos", "podem", "podem"),
                "الماضي" to listOf("pude", "pudeste", "pôde", "pudemos", "puderam", "puderam"),
                "المستقبل" to listOf("poderei", "poderás", "poderá", "poderemos", "poderão", "poderão")
            ),
            "querer" to mapOf(
                "المضارع" to listOf("quero", "queres", "quer", "queremos", "querem", "querem"),
                "الماضي" to listOf("quis", "quiseste", "quis", "quisemos", "quiseram", "quiseram"),
                "المستقبل" to listOf("quererei", "quererás", "quererá", "quereremos", "quererão", "quererão")
            ),
            "dizer" to mapOf(
                "المضارع" to listOf("digo", "dizes", "diz", "dizemos", "dizem", "dizem"),
                "الماضي" to listOf("disse", "disseste", "disse", "dissemos", "disseram", "disseram"),
                "المستقبل" to listOf("direi", "dirás", "dirá", "diremos", "dirão", "dirão")
            ),
            "vir" to mapOf(
                "المضارع" to listOf("venho", "vens", "vem", "vimos", "vêm", "vêm"),
                "الماضي" to listOf("vim", "vieste", "veio", "viemos", "vieram", "vieram"),
                "المستقبل" to listOf("virei", "virás", "virá", "viremos", "virão", "virão")
            ),
            "ver" to mapOf(
                "المضارع" to listOf("vejo", "vês", "vê", "vemos", "veem", "veem"),
                "الماضي" to listOf("vi", "viste", "viu", "vimos", "viram", "viram"),
                "المستقبل" to listOf("verei", "verás", "verá", "veremos", "verão", "verão")
            ),
            "saber" to mapOf(
                "المضارع" to listOf("sei", "sabes", "sabe", "sabemos", "sabem", "sabem"),
                "الماضي" to listOf("soube", "soubeste", "soube", "soubemos", "souberam", "souberam"),
                "المستقبل" to listOf("saberei", "saberás", "saberá", "saberemos", "saberão", "saberão")
            ),
            "dar" to mapOf(
                "المضارع" to listOf("dou", "dás", "dá", "damos", "dão", "dão"),
                "الماضي" to listOf("dei", "deste", "deu", "demos", "deram", "deram"),
                "المستقبل" to listOf("darei", "darás", "dará", "daremos", "darão", "darão")
            )
        )
        irregular[verb]?.get(tense)?.let { return it }
        val infinitive = rawVerb.trim().lowercase(Locale.ROOT)
        val base = if (infinitive.endsWith("-se")) infinitive.dropLast(3) else infinitive
        if (tense == "المستقبل") {
            val endings = listOf("ei", "ás", "á", "emos", "ão", "ão")
            return endings.map { base + it }
        }
        val ending = when {
            base.endsWith("ar") -> "ar"
            base.endsWith("er") -> "er"
            base.endsWith("ir") -> "ir"
            else -> return listOf("—", "—", "—", "—", "—", "—")
        }
        val stem = base.dropLast(2)
        val endings = if (tense == "الماضي") {
            if (ending == "ar") listOf("ei", "aste", "ou", "ámos", "aram", "aram")
            else listOf("i", "este", "eu", "emos", "eram", "eram")
        } else {
            when (ending) {
                "ar" -> listOf("o", "as", "a", "amos", "am", "am")
                "er" -> listOf("o", "es", "e", "emos", "em", "em")
                else -> listOf("o", "es", "e", "imos", "em", "em")
            }
        }
        return endings.map { stem + it }
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radiusDp * resources.displayMetrics.density
    }

    private fun marginParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        setMargins(0, 4, 0, 4)
    }

    private fun makeTile(label: String, color: Int, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 14f; setTextColor(Color.WHITE); isAllCaps = false; setPadding(8, 9, 8, 9)
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(lighten(color, 0.13f), color)).apply {
            cornerRadius = 18 * resources.displayMetrics.density
        }
        // Custom glossy 3D icons matching the app's visual design.
        val iconRes = when {
            label.contains("البطاقات") || label.contains("كلماتي") -> R.drawable.books_icon
            label.contains("اختبار") -> R.drawable.target_icon
            label.contains("تصريف") -> R.drawable.running_icon
            label.contains("Excel") || label.contains("استيراد") -> R.drawable.excel_icon
            label.contains("الجمل") || label.contains("الأمثلة") -> R.drawable.open_book_icon
            label.contains("البحث") || label.contains("التصنيف") -> R.drawable.search_icon
            label.contains("Português") || label.contains("البرتغالية") -> R.drawable.portugal_book_icon
            label.contains("الصوت") || label.contains("تذكير") -> R.drawable.speaker_icon
            label.contains("تعديل") -> R.drawable.pencil_icon
            label.contains("حذف") -> R.drawable.trash_icon
            label.contains("مفضلة") -> R.drawable.favorite_icon
            label.contains("الوضع") || label.contains("إعدادات") -> R.drawable.theme_icon
            else -> 0
        }
        if (iconRes != 0) {
            val icon = getDrawable(iconRes)?.mutate()
            val size = (42 * resources.displayMetrics.density).toInt()
            icon?.setBounds(0, 0, size, size)
            setCompoundDrawables(null, icon, null, null)
            compoundDrawablePadding = (3 * resources.displayMetrics.density).toInt()
        }
        elevation = 3f
        stateListAnimator = null
        setOnClickListener { action() }
    }

    private fun lighten(color: Int, amount: Float): Int {
        val r = (Color.red(color) + (255 - Color.red(color)) * amount).toInt()
        val g = (Color.green(color) + (255 - Color.green(color)) * amount).toInt()
        val b = (Color.blue(color) + (255 - Color.blue(color)) * amount).toInt()
        return Color.rgb(r, g, b)
    }

    private fun editWord(existing: Int?) {
        val current = existing?.let { words[it] }
        val pt = EditText(this).apply { hint = "الكلمة بالبرتغالية"; textSize = 17f; setSingleLine(true); current?.let { setText(it.pt) } }
        val ar = EditText(this).apply { hint = "الترجمة بالعربية"; textSize = 17f; setSingleLine(true); current?.let { setText(it.ar) } }
        val exPt = EditText(this).apply { hint = "مثال بالبرتغالية (اختياري)"; textSize = 16f; current?.let { setText(it.examplePt) } }
        val exAr = EditText(this).apply { hint = "ترجمة المثال (اختياري)"; textSize = 16f; current?.let { setText(it.exampleAr) } }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 0, 22, 0); addView(pt); addView(ar); addView(exPt); addView(exAr) }
        AlertDialog.Builder(this).setTitle(if (existing == null) "إضافة كلمة" else "تعديل الكلمة").setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val p = pt.text.toString().trim(); val a = ar.text.toString().trim()
                if (p.isNotEmpty() && a.isNotEmpty()) {
                    val w = Word(p, a, exPt.text.toString().trim(), exAr.text.toString().trim())
                    if (existing == null) words.add(w) else if (existing in words.indices) words[existing] = w
                    saveWords()
                    when {
                        showingMyWords -> showMyWords()
                        showingConjugations -> showConjugations()
                        else -> renderWords()
                    }
                    updateStatus()
                } else toast("اكتب الكلمة والترجمة")
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun renderWords() {
        list.removeAllViews()
        if (words.isEmpty()) {
            list.addView(TextView(this).apply { text = "لم تضف كلمات بعد. أضف كلمة أو استورد ملف Excel."; textSize = 16f; setTextColor(0xFF64748B.toInt()); setPadding(12, 18, 12, 18); background = rounded(Color.WHITE, 16) }, marginParams())
            return
        }
        words.forEachIndexed { i, w ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 12); background = rounded(Color.WHITE, 20); elevation = 2f
            }
            card.addView(TextView(this).apply { text = w.pt; textSize = 22f; setTextColor(0xFF102A43.toInt()); setTypeface(null, android.graphics.Typeface.BOLD) })
            card.addView(TextView(this).apply { text = w.ar; textSize = 18f; gravity = Gravity.END; setTextColor(0xFF334E68.toInt()); setPadding(0, 2, 0, 4) })
            if (w.examplePt.isNotBlank()) {
                card.addView(TextView(this).apply { text = "${w.examplePt}\n${w.exampleAr}"; textSize = 14f; setTextColor(0xFF486581.toInt()); setPadding(8, 8, 8, 8); background = rounded(0xFFF1F5F9.toInt(), 10) })
            }
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            buttons.addView(makeTile("🔊", 0xFF1769E8.toInt()) { speak(w.pt) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.7f).apply { setMargins(0, 4, 3, 0) })
            buttons.addView(makeTile("تعديل", 0xFF64748B.toInt()) { editWord(i) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 4, 3, 0) })
            buttons.addView(makeTile("حذف", 0xFFDC2626.toInt()) { confirmDelete(i) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(3, 4, 0, 0) })
            card.addView(buttons)
            list.addView(card, marginParams())
        }
    }

    private fun confirmDelete(i: Int) {
        if (i !in words.indices) return
        AlertDialog.Builder(this).setMessage("حذف ${words[i].pt}؟").setPositiveButton("حذف") { _, _ -> words.removeAt(i); saveWords(); if (showingMyWords) showMyWords() else renderWords(); updateStatus() }.setNegativeButton("إلغاء", null).show()
    }

    private fun showExamples() {
        val examples = words.filter { it.examplePt.isNotBlank() }
        if (examples.isEmpty()) {
            AlertDialog.Builder(this).setTitle("الجمل والأمثلة")
                .setMessage("لا توجد أمثلة محفوظة بعد. أضف كلمة ثم اكتب المثال البرتغالي وترجمته، أو استورد ملف Excel بأربعة أعمدة: البرتغالية، العربية، المثال، ترجمة المثال.")
                .setPositiveButton("حسنًا", null).show()
            return
        }
        val body = examples.joinToString("\n\n──────────\n\n") { "${it.examplePt}\n${it.exampleAr}\n(${it.pt} = ${it.ar})" }
        val text = TextView(this).apply { this.text = body; textSize = 17f; setTextColor(0xFF243B53.toInt()); setPadding(22, 14, 22, 14) }
        AlertDialog.Builder(this).setTitle("الجمل والأمثلة (${examples.size})").setView(ScrollView(this).apply { addView(text) }).setPositiveButton("إغلاق", null).show()
    }

    private fun startFlashcards() {
        if (words.isEmpty()) { toast("أضف كلمات أولًا"); return }
        var index = 0
        var revealed = false
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16); background = rounded(0xFFF1F7FF.toInt(), 28) }
        lateinit var dialog: AlertDialog
        val topHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(14, 12, 10, 12); background = rounded(0xFF1769E8.toInt(), 20) }
        val headerTitle = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        headerTitle.addView(TextView(this).apply { text = "🃏 البطاقات التعليمية"; textSize = 20f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) })
        headerTitle.addView(TextView(this).apply { text = "تعلّم كلمة جديدة في كل بطاقة"; textSize = 12f; setTextColor(0xFFEAF2FF.toInt()); setPadding(0, 3, 0, 0) })
        topHeader.addView(headerTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        topHeader.addView(makeTile("✕", 0xFF0E4DA8.toInt()) { dialog.dismiss() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panel.addView(topHeader, marginParams())
        val progress = TextView(this).apply { textSize = 14f; setTextColor(0xFF475569.toInt()); gravity = Gravity.CENTER; setPadding(0, 8, 0, 8) }
        val progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = words.size; this.progress = 1; progressTintList = android.content.res.ColorStateList.valueOf(0xFF10B981.toInt()); progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xFFDCE5F1.toInt()) }
        val wordCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(18, 22, 18, 22); minimumHeight = (270 * resources.displayMetrics.density).toInt(); background = rounded(Color.WHITE, 24) }
        val wordText = TextView(this).apply { textSize = 32f; gravity = Gravity.CENTER; setTextColor(0xFF102A72.toInt()); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 10, 0, 10) }
        val speaker = makeTile("🔊 استمع للنطق الأوروبي", 0xFF1769E8.toInt()) { speak(words[index % words.size].pt) }
        val translation = TextView(this).apply { textSize = 23f; gravity = Gravity.CENTER; setTextColor(0xFF334155.toInt()); setPadding(0, 14, 0, 4) }
        val example = TextView(this).apply { textSize = 15f; gravity = Gravity.CENTER; setTextColor(0xFF64748B.toInt()); setPadding(4, 10, 4, 0) }
        wordCard.addView(wordText); wordCard.addView(speaker); wordCard.addView(translation); wordCard.addView(example)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val previous = makeTile("← السابق", 0xFF64748B.toInt()) {}
        val reveal = makeTile("👁 إظهار الترجمة", 0xFF1769E8.toInt()) {}
        val next = makeTile("التالي ⟶", 0xFF059669.toInt()) {}
        nav.addView(previous, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 8, 2, 2) })
        nav.addView(reveal, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f).apply { setMargins(2, 8, 2, 2) })
        nav.addView(next, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 8, 2, 2) })
        val selfRate = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        var refresh: () -> Unit = {}
        val difficult = makeTile("🔴 صعب", 0xFFFCE7F3.toInt()) { index = (index + 1) % words.size; revealed = false; refresh() }
        difficult.setTextColor(0xFFBE185D.toInt())
        val known = makeTile("✅ أعرفها", 0xFFD1FAE5.toInt()) { index = (index + 1) % words.size; revealed = false; refresh() }
        known.setTextColor(0xFF047857.toInt())
        selfRate.addView(difficult, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 8, 2, 2) })
        selfRate.addView(known, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(2, 8, 2, 2) })
        panel.addView(progress); panel.addView(progressBar); panel.addView(wordCard, marginParams()); panel.addView(nav); panel.addView(selfRate)
        dialog = AlertDialog.Builder(this).setView(panel).create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        refresh = {
            val w = words[index % words.size]
            progress.text = "${index + 1} / ${words.size}"
            progressBar.progress = index + 1
            wordText.text = w.pt
            translation.text = if (revealed) w.ar else "تذكّر المعنى ثم اضغط إظهار الترجمة"
            example.text = if (revealed && w.examplePt.isNotBlank()) "${w.examplePt}\n${w.exampleAr}" else ""
            reveal.text = if (revealed) "إخفاء الترجمة" else "👁 إظهار الترجمة"
        }
        previous.setOnClickListener { index = (index - 1 + words.size) % words.size; revealed = false; refresh() }
        next.setOnClickListener { index = (index + 1) % words.size; revealed = false; refresh() }
        reveal.setOnClickListener { revealed = !revealed; refresh() }
        refresh(); dialog.show()
    }

    private fun startQuiz() {
        if (words.size < 2) { toast("أضف كلمتين على الأقل لبدء الاختبار"); return }
        val quizWords = words.shuffled().take(minOf(10, words.size))
        var index = 0
        var score = 0
        var answered = false
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16); background = rounded(0xFFF5F3FF.toInt(), 28) }
        lateinit var dialog: AlertDialog
        val topHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(14, 12, 10, 12); background = rounded(0xFF7C3AED.toInt(), 20) }
        val headerTitle = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        headerTitle.addView(TextView(this).apply { text = "🎯 اختبار الكلمات"; textSize = 20f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD) })
        headerTitle.addView(TextView(this).apply { text = "اختر الترجمة الصحيحة واجمع النقاط"; textSize = 12f; setTextColor(0xFFF3E8FF.toInt()); setPadding(0, 3, 0, 0) })
        topHeader.addView(headerTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        topHeader.addView(makeTile("✕", 0xFF5B21B6.toInt()) { dialog.dismiss() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panel.addView(topHeader, marginParams())
        val progress = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; setTextColor(0xFF475569.toInt()); setPadding(0, 8, 0, 8) }
        val progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = quizWords.size; this.progress = 1; progressTintList = android.content.res.ColorStateList.valueOf(0xFF8B5CF6.toInt()); progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xFFE9D5FF.toInt()) }
        val questionCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(18, 18, 18, 18); background = rounded(Color.WHITE, 22) }
        val prompt = TextView(this).apply { text = "ما ترجمة هذه الكلمة؟"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(0xFF64748B.toInt()) }
        val word = TextView(this).apply { textSize = 30f; gravity = Gravity.CENTER; setTextColor(0xFF4C1D95.toInt()); setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, 12, 0, 12) }
        val sound = makeTile("🔊 استمع", 0xFF7C3AED.toInt()) { speak(word.text.toString()) }
        questionCard.addView(prompt); questionCard.addView(word); questionCard.addView(sound)
        val optionsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val feedback = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER; setPadding(10, 10, 10, 10); visibility = View.GONE }
        val next = makeTile("التالي ⟶", 0xFF1769E8.toInt()) {}
        panel.addView(progress); panel.addView(progressBar); panel.addView(questionCard, marginParams()); panel.addView(optionsBox); panel.addView(feedback); panel.addView(next)
        dialog = AlertDialog.Builder(this).setView(panel).create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        fun loadQuestion() {
            answered = false
            val item = quizWords[index]
            progress.text = "السؤال ${index + 1} من ${quizWords.size} • النتيجة $score"
            progressBar.progress = index + 1
            word.text = item.pt
            feedback.visibility = View.GONE
            optionsBox.removeAllViews()
            val options = (words.filter { it.pt != item.pt }.shuffled().take(3).map { it.ar } + item.ar).distinct().shuffled()
            options.forEachIndexed { optionIndex, option ->
                val button = makeTile("${('A'.code + optionIndex).toChar()}     $option", 0xFFFFFFFF.toInt()) {}.apply { setTextColor(0xFF243B53.toInt()); textSize = 17f; gravity = Gravity.CENTER_VERTICAL; background = rounded(Color.WHITE, 16) }
                button.setOnClickListener {
                    if (answered) return@setOnClickListener
                    answered = true
                    val correct = option == item.ar
                    if (correct) score++
                    feedback.visibility = View.VISIBLE
                    feedback.text = if (correct) "✅ صحيح! ${item.pt} = ${item.ar}" else "❌ الإجابة الصحيحة: ${item.ar}"
                    feedback.setTextColor(if (correct) 0xFF047857.toInt() else 0xFFB91C1C.toInt())
                    feedback.background = rounded(if (correct) 0xFFD1FAE5.toInt() else 0xFFFEE2E2.toInt(), 14)
                    for (childIndex in 0 until optionsBox.childCount) { val child = optionsBox.getChildAt(childIndex); if (child is Button) child.isEnabled = false }
                    button.background = rounded(if (correct) 0xFFD1FAE5.toInt() else 0xFFFEE2E2.toInt(), 16)
                }
                optionsBox.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 4, 0, 4) })
            }
            next.text = if (index == quizWords.lastIndex) "إنهاء الاختبار" else "التالي ⟶"
        }
        next.setOnClickListener {
            if (!answered) { toast("اختر إجابة أولًا"); return@setOnClickListener }
            if (index < quizWords.lastIndex) { index++; loadQuestion() }
            else { AlertDialog.Builder(this).setTitle("انتهى الاختبار 🎉").setMessage("نتيجتك: $score من ${quizWords.size}").setPositiveButton("حسنًا", null).show(); dialog.dismiss() }
        }
        loadQuestion(); dialog.show()
    }

    private fun speak(text: String) {
        if (!ttsReady) { toast("الصوت البرتغالي غير متاح حاليًا على الهاتف"); return }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "word-${System.currentTimeMillis()}")
    }

    private fun importWords() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-excel", "text/csv", "text/comma-separated-values", "text/plain"
            ))
        }
        startActivityForResult(intent, importRequest)
    }

    private fun importFromUri(uri: Uri) {
        try {
            val name = (contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else ""
            } ?: "").lowercase(Locale.ROOT)
            val rows = if (name.endsWith(".xlsx")) readXlsx(uri) else readDelimited(uri)
            if (rows.isEmpty()) { toast("لم أجد صفوفًا في الملف"); return }
            val first = rows.first().map { it.trim().lowercase(Locale.ROOT) }
            val headerLikely = first.any { it.contains("portugu") || it == "pt" || it.contains("العربي") || it == "ar" || it.contains("ترجم") }
            var ptCol = 0; var arCol = 1; var exPtCol = 2; var exArCol = 3
            var startRow = 0
            if (headerLikely) {
                fun findCol(predicate: (String) -> Boolean, fallback: Int): Int = first.indexOfFirst(predicate).let { if (it >= 0) it else fallback }
                ptCol = findCol({ it.contains("portugu") || it == "pt" || it == "portugues" || it == "português" }, 0)
                arCol = findCol({ it.contains("العربي") || it == "ar" || it.contains("ترجم") }, if (ptCol == 0) 1 else 0)
                exPtCol = findCol({ it.contains("exemplo") || it.contains("مثال") && it.contains("برتغ") }, 2)
                exArCol = findCol({ it.contains("tradução do exemplo") || it.contains("ترجمة المثال") }, 3)
                startRow = 1
            }
            var added = 0; var updated = 0
            for (r in startRow until rows.size) {
                val row = rows[r]
                val pt = row.getOrNull(ptCol)?.trim().orEmpty()
                val ar = row.getOrNull(arCol)?.trim().orEmpty()
                if (pt.isBlank() || ar.isBlank()) continue
                val exPt = row.getOrNull(exPtCol)?.trim().orEmpty()
                val exAr = row.getOrNull(exArCol)?.trim().orEmpty()
                val index = words.indexOfFirst { it.pt.equals(pt, ignoreCase = true) }
                val word = Word(pt, ar, exPt, exAr)
                if (index >= 0) { words[index] = word; updated++ } else { words.add(word); added++ }
            }
            saveWords(); if (showingMyWords) showMyWords() else renderWords(); updateStatus()
            toast("تم الاستيراد: أضيف $added، وتم تحديث $updated كلمة")
        } catch (e: Exception) {
            toast("تعذر استيراد الملف. استخدم Excel بصيغة .xlsx أو CSV")
        }
    }

    private fun readDelimited(uri: Uri): List<List<String>> {
        val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: return emptyList()
        val lines = text.removePrefix("\uFEFF").split(Regex("\r?\n")).filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList()
        val delimiter = listOf('\t', ';', ',').maxByOrNull { d -> lines.first().count { it == d } } ?: ','
        return lines.map { line ->
            val cells = mutableListOf<String>(); val cell = StringBuilder(); var quoted = false; var i = 0
            while (i < line.length) {
                val ch = line[i]
                if (ch == '"') {
                    if (quoted && i + 1 < line.length && line[i + 1] == '"') { cell.append('"'); i++ } else quoted = !quoted
                } else if (ch == delimiter && !quoted) { cells.add(cell.toString()); cell.setLength(0) } else cell.append(ch)
                i++
            }
            cells.add(cell.toString()); cells
        }
    }

    private fun readXlsx(uri: Uri): List<List<String>> {
        val entries = mutableMapOf<String, ByteArray>()
        val input = contentResolver.openInputStream(uri) ?: return emptyList()
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && (entry.name == "xl/sharedStrings.xml" || entry.name == "xl/worksheets/sheet1.xml")) {
                    val out = ByteArrayOutputStream(); zip.copyTo(out); entries[entry.name] = out.toByteArray()
                }
                entry = zip.nextEntry
            }
        }
        val sheet = entries["xl/worksheets/sheet1.xml"] ?: return emptyList()
        val shared = entries["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) } ?: emptyList()
        val result = mutableListOf<List<String>>()
        val parser = Xml.newPullParser(); parser.setInput(ByteArrayInputStream(sheet), "UTF-8")
        var event = parser.eventType; var inCell = false; var cellType = ""; var cellRef = ""; var value = ""; var inValue = false; var row = mutableMapOf<Int, String>()
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> row = mutableMapOf()
                    "c" -> { inCell = true; cellType = parser.getAttributeValue(null, "t") ?: ""; cellRef = parser.getAttributeValue(null, "r") ?: ""; value = "" }
                    "v", "t" -> if (inCell) inValue = true
                }
                XmlPullParser.TEXT -> if (inValue) value += parser.text
                XmlPullParser.END_TAG -> when (parser.name) {
                    "v", "t" -> inValue = false
                    "c" -> {
                        val col = cellRef.takeWhile { it.isLetter() }.fold(0) { acc, ch -> acc * 26 + (ch.uppercaseChar() - 'A' + 1) } - 1
                        val decoded = if (cellType == "s") shared.getOrNull(value.toIntOrNull() ?: -1).orEmpty() else value
                        if (col >= 0) row[col] = decoded
                        inCell = false
                    }
                    "row" -> if (row.isNotEmpty()) result.add((0..(row.keys.maxOrNull() ?: 0)).map { row[it].orEmpty() })
                }
            }
            event = parser.next()
        }
        return result
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val out = mutableListOf<String>(); val parser = Xml.newPullParser(); parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        var event = parser.eventType; var inSi = false; var inText = false; val current = StringBuilder()
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name) { "si" -> { inSi = true; current.setLength(0) }; "t" -> if (inSi) inText = true }
                XmlPullParser.TEXT -> if (inSi && inText) current.append(parser.text)
                XmlPullParser.END_TAG -> when (parser.name) { "t" -> inText = false; "si" -> { out.add(current.toString()); inSi = false } }
            }
            event = parser.next()
        }
        return out
    }

    private fun exportWords() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "PortugueseWords.json") }
        startActivityForResult(intent, exportRequest)
    }

    @Deprecated("Deprecated in Android but kept for compatibility with target devices")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == importRequest && resultCode == RESULT_OK && data?.data != null) {
            importFromUri(data.data!!)
        }
        if (requestCode == exportRequest && resultCode == RESULT_OK && data?.data != null) {
            try {
                val arr = JSONArray(); words.forEach { arr.put(JSONObject().put("pt", it.pt).put("ar", it.ar).put("examplePt", it.examplePt).put("exampleAr", it.exampleAr)) }
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(arr.toString(2)) }
                toast("تم تصدير الكلمات بنجاح")
            } catch (e: Exception) { toast("تعذر التصدير: ${e.message}") }
        }
    }

    private fun loadWords() {
        words.clear()
        val arr = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) { val o = arr.optJSONObject(i) ?: continue; words.add(Word(o.optString("pt"), o.optString("ar"), o.optString("examplePt"), o.optString("exampleAr"))) }
    }
    private fun saveWords() { val arr = JSONArray(); words.forEach { arr.put(JSONObject().put("pt", it.pt).put("ar", it.ar).put("examplePt", it.examplePt).put("exampleAr", it.exampleAr)) }; prefs.edit().putString("items", arr.toString()).apply() }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
    }
    private fun requestExactAlarmThenSchedule() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotificationPermission()
            toast("اسمح بالإشعارات ثم اضغط تشغيل مرة أخرى")
            return
        }
        prefs.edit().putBoolean("reminders_enabled", true).apply()
        ReminderScheduler.scheduleNext(this)
        updateStatus("التذكير يعمل في الخلفية: كل ${prefs.getInt("interval_minutes", 5)} دقيقة بين 08:00 و22:00")
        if (Build.VERSION.SDK_INT >= 23) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                AlertDialog.Builder(this)
                    .setTitle("السماح بالعمل في الخلفية")
                    .setMessage("لتحسين انتظام التذكيرات والشاشة مقفلة، اسمح للتطبيق بتجاوز تحسين البطارية. قد يزيد ذلك استهلاك البطارية، خصوصًا عند اختيار تذكير كل دقيقة.")
                    .setPositiveButton("فتح الإعدادات") { _, _ ->
                        try {
                            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                        } catch (_: Exception) {
                            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                        }
                    }
                    .setNegativeButton("لاحقًا", null)
                    .show()
            }
        }
    }
    private fun updateStatus(message: String? = null) { status.text = message ?: "عدد الكلمات المحفوظة: ${words.size}\nالتذكير: كل ${prefs.getInt("interval_minutes", 5)} دقيقة، 08:00–22:00" }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

object ReminderScheduler {
    fun scheduleNext(context: Context) {
        val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("reminders_enabled", false)) return
        val intent = Intent(context, ReminderService::class.java).setAction(ReminderService.ACTION_RESCHEDULE)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        } catch (_: Exception) {
            // The UI will remain usable; the user can tap Start again if Android blocks service startup.
        }
    }

    fun cancel(context: Context) {
        context.stopService(Intent(context, ReminderService::class.java))
        val alarmIntent = PendingIntent.getBroadcast(context, 12, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(alarmIntent)
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(1001)
    }
}

class ReminderService : Service() {
    companion object {
        const val ACTION_RESCHEDULE = "com.bekri.wordreminder.RESCHEDULE"
        private const val SERVICE_NOTIFICATION_ID = 2001
        private const val WORD_NOTIFICATION_ID = 1001
        private const val SERVICE_CHANNEL = "reminder_service"
        private const val WORD_CHANNEL = "words"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null
    private var index = 0
    private val tick = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences("words", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("reminders_enabled", false)) {
                stopSelf()
                return
            }
            val now = java.util.Calendar.getInstance()
            val hour = now.get(java.util.Calendar.HOUR_OF_DAY)
            if (hour >= 22 || hour < 8) {
                val next = java.util.Calendar.getInstance().apply {
                    if (hour >= 22) add(java.util.Calendar.DAY_OF_YEAR, 1)
                    set(java.util.Calendar.HOUR_OF_DAY, 8)
                    set(java.util.Calendar.MINUTE, 0)
                    set(java.util.Calendar.SECOND, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                }
                releaseWakeLock() // Do not keep the CPU awake overnight.
                scheduleMorningWake(next.timeInMillis)
                return
            }
            val arr = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
            if (arr.length() > 0) {
                if (index >= arr.length()) index = 0
                val item = arr.optJSONObject(index)
                if (item != null) {
                    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                    val open = PendingIntent.getActivity(this@ReminderService, 2, Intent(this@ReminderService, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this@ReminderService, WORD_CHANNEL) else android.app.Notification.Builder(this@ReminderService)
                    val text = "${item.optString("pt")} — ${item.optString("ar")}"
                    val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle(item.optString("pt"))
                        .setContentText(item.optString("ar"))
                        .setStyle(android.app.Notification.BigTextStyle().bigText(text))
                        .setContentIntent(open)
                        .setAutoCancel(true)
                        .build()
                    // Cancel first so Android treats each reminder as a fresh alert, even for a one-word list.
                    manager.cancel(WORD_NOTIFICATION_ID)
                    manager.notify(WORD_NOTIFICATION_ID, notification)
                    index = (index + 1) % arr.length()
                    prefs.edit().putInt("next_index", index).apply()
                }
            }
            val minutes = prefs.getInt("interval_minutes", 5).coerceIn(1, 10)
            handler.postDelayed(this, minutes * 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WordReminder:ReminderLoop").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWakeLock() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
    }

    private fun scheduleMorningWake(at: Long) {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java).setAction("com.bekri.wordreminder.MORNING_WAKE")
        val pi = PendingIntent.getBroadcast(this, 13, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else alarm.setExact(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: SecurityException) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            manager.createNotificationChannel(android.app.NotificationChannel(SERVICE_CHANNEL, "حالة التذكير", android.app.NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
            manager.createNotificationChannel(android.app.NotificationChannel(WORD_CHANNEL, "تذكير الكلمات", android.app.NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, SERVICE_CHANNEL) else android.app.Notification.Builder(this)
        val ongoing = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("كلمات البرتغالية")
            .setContentText("التذكير نشط في الخلفية")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(SERVICE_NOTIFICATION_ID, ongoing, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(SERVICE_NOTIFICATION_ID, ongoing)
        }
        handler.removeCallbacks(tick)
        val prefs = getSharedPreferences("words", Context.MODE_PRIVATE)
        if (prefs.getBoolean("reminders_enabled", false)) {
            val now = java.util.Calendar.getInstance()
            val hour = now.get(java.util.Calendar.HOUR_OF_DAY)
            if (hour >= 22 || hour < 8) {
                val next = java.util.Calendar.getInstance().apply {
                    if (hour >= 22) add(java.util.Calendar.DAY_OF_YEAR, 1)
                    set(java.util.Calendar.HOUR_OF_DAY, 8); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
                }
                releaseWakeLock()
                scheduleMorningWake(next.timeInMillis)
            } else {
                acquireWakeLock()
                index = prefs.getInt("next_index", 0).coerceAtLeast(0)
                val minutes = prefs.getInt("interval_minutes", 5).coerceIn(1, 10)
                handler.postDelayed(tick, minutes * 60_000L)
            }
        } else {
            stopSelf()
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Keep the user-enabled reminder service running when the app is swiped from Recents.
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(SERVICE_NOTIFICATION_ID)
        }
        releaseWakeLock()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}

class ReminderReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
        if (prefs.getBoolean("reminders_enabled", false) && intent?.action == "com.bekri.wordreminder.MORNING_WAKE") {
            ReminderScheduler.scheduleNext(context)
        }
    }
}

class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val prefs = context.getSharedPreferences("words", Context.MODE_PRIVATE)
            if (prefs.getBoolean("reminders_enabled", false)) ReminderScheduler.scheduleNext(context)
        }
    }
}
