# OneClick ID · Android prototype

OneClick ID is a local-first Android prototype for identity profiles and a dedicated WebView browser with user-triggered form autofill.

## Included in this source
- Jetpack Compose dashboard: Home, Profiles, Settings.
- Room database for profiles, create/delete/default selection.
- Dedicated WebView browser with address bar, page title/progress and form-field count.
- User-triggered Quick Fill for common email, password and name fields.
- Random password generation at fill time; passwords are not persisted in the profile database.
- No automatic form submission.
- Unit tests for password and identifier generation.

## Honest status
This is a functional prototype foundation, not a universal sign-in bypass. It does not create temporary inboxes, read email, provision aliases, integrate Google sign-in, isolate browser cookies per profile, bypass CAPTCHA, or defeat paywalls/account restrictions. Google sign-in to this app would not automatically sign into arbitrary third-party sites.

## Security warnings
- Do not use this as a production password manager. The generated password is temporary and not saved; if a site requires it later, use a trusted password manager to save it yourself.
- WebView autofill is heuristic. Modern sites may use custom controls, shadow DOM, cross-origin frames or scripts that ignore synthetic events.
- JavaScript is enabled for modern websites. File/content access is disabled. Only browse sites you trust and inspect all fields before submitting.
- WebView cookies are shared within this app; the current prototype does not isolate browser sessions by profile.
- Use email addresses you control or aliases already provisioned with a provider. No mailbox is accessed by this app.

## Build
Requirements: Android Studio with Android SDK Platform 35, JDK 17, internet for the first Gradle sync. The project is configured for Gradle 8.9 and Android Gradle Plugin 8.7.3 to match AndroidForge environments that run Gradle 8.9.

1. Extract the ZIP.
2. Open the `OneClickID` folder in Android Studio.
3. Let Gradle sync, then Build > Build APK(s).
4. Expected debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

The Gradle wrapper properties are included, but the binary `gradle-wrapper.jar` is not. If Android Studio says the wrapper JAR is missing, open the project through Android Studio's Gradle tooling or install Gradle 8.9 and run `gradle wrapper --gradle-version 8.9` from the project root. You can also create a fresh Compose project and copy the `app/src` and app-level build files into it.

CLI build once wrapper is available:
```bash
./gradlew assembleDebug
./gradlew testDebugUnitTest
```

## First test pass
1. Open Profiles and add an email address you control.
2. Open a site with a simple test registration form.
3. Tap Quick Fill and select the profile.
4. Inspect the form. The app intentionally never taps Submit.
5. Test create/delete/default profile behavior and navigation.

## Next engineering milestones
P0: UI tests, URL safety review, clear-browsing-data control, robust error states.
P1: Better form detection and a preview of proposed field values before filling.
P2: Provider-specific email alias integration and mailbox access using documented APIs and minimal OAuth scopes.
P3: Credential Manager for signing into OneClick ID itself, after configuring an OAuth Web client ID and server-side ID-token validation if a backend is introduced.
P4: Android AutofillService for native apps and browser integrations, explicitly enabled by the user in Android Settings.
P5: Per-profile isolated browser storage, accessibility/TalkBack pass, threat model and security review.

## Official references
- Android Credential Manager / Sign in with Google: https://developer.android.com/identity/sign-in/credential-manager-siwg
- Android AutofillService: https://developer.android.com/reference/android/service/autofill/AutofillService
- Android Gradle Plugin 8.7 release notes: https://developer.android.com/build/releases/past-releases/agp-8-7-0-release-notes

## Build verification
The Gradle configuration has been adjusted to match AndroidForge’s reported Gradle 8.9 runtime. The source has not been compiled in this environment, so a successful APK build is not yet verified.


## AndroidForge build fixes

This source revision fixes two Kotlin compilation issues found in AndroidForge logs:

- `ProfileRepository.observeProfiles()` now has spacing around the generic return type and assignment so Kotlin does not tokenize `>>=` as an operator.
- `BrowserScreen` explicitly opts in to the experimental Material 3 API used by `ModalBottomSheet`.

The project is configured for Gradle 8.9 with Android Gradle Plugin 8.7.3. The ZIP was checked for archive integrity, but an Android SDK/Gradle build was not available in the packaging environment; successful APK compilation still needs verification in AndroidForge.
