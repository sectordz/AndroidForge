plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.flashcard3d.demo"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.flashcard3d.demo"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
