package com.example.screentranslate

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val captureRequest = 4812
    private val overlayRequest = 4813

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "مترجم الشاشة\n\nالبرتغالية ⇢ العربية"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val help = TextView(this).apply {
            text = "\n1. اسمح بالظهور فوق التطبيقات.\n2. وافق على مشاركة الشاشة عندما يطلب Android ذلك.\n3. اسحب الفقاعة إلى أي حافة واضغط عليها مطولًا للترجمة."
            textSize = 16f
            textDirection = TextView.TEXT_DIRECTION_RTL
            setPadding(0, 18, 0, 18)
        }
        val start = Button(this).apply {
            text = "تفعيل الزر العائم"
            setOnClickListener { requestOverlayThenCapture() }
        }
        layout.addView(title)
        layout.addView(help)
        layout.addView(start)
        setContentView(layout)
    }

    private fun requestOverlayThenCapture() {
        if (!Settings.canDrawOverlays(this)) {
            val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(i, overlayRequest)
        } else requestCapture()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequest) {
            if (Settings.canDrawOverlays(this)) requestCapture()
        } else if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, FloatingTranslateService::class.java).apply {
                action = FloatingTranslateService.ACTION_START
                putExtra(FloatingTranslateService.EXTRA_RESULT_CODE, resultCode)
                putExtra(FloatingTranslateService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            finish()
        }
    }

    private fun requestCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }
}
