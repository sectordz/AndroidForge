package com.bekri.wordreminder

import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.AbsListView
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.widget.SeekBar
import kotlin.math.max
import kotlin.math.min

/**
 * Fx3D — one place that gives the whole interface a 3D look:
 *  - Depth3DDrawable : solid "side wall" under the face + top gloss + rim light + real outline for shadows.
 *  - tilt on touch   : any clickable view tilts toward the finger and sinks like a physical key.
 *  - entrance / float: cards pop in with perspective, hero logo floats gently.
 *  - deepen(root)    : walks a view tree (and views added later) and upgrades flat rounded backgrounds.
 */
object Fx3D {

    // ---------- colour helpers ----------
    fun shade(color: Int, f: Float): Int =
        Color.argb(Color.alpha(color), (Color.red(color) * f).toInt().coerceIn(0, 255),
            (Color.green(color) * f).toInt().coerceIn(0, 255), (Color.blue(color) * f).toInt().coerceIn(0, 255))

    fun tint(color: Int, f: Float): Int = Color.argb(Color.alpha(color),
        (Color.red(color) + (255 - Color.red(color)) * f).toInt(),
        (Color.green(color) + (255 - Color.green(color)) * f).toInt(),
        (Color.blue(color) + (255 - Color.blue(color)) * f).toInt())

    // ---------- the 3D drawable ----------
    /**
     * Draws [face] (any drawable — keeps its own gradient/stroke) lifted above a darker "side wall".
     * Padding is NOT reported, so existing setPadding() calls on views keep working.
     */
    class Depth3DDrawable(
        private val face: Drawable,
        private val radius: Float,
        private val depth: Float,
        private val sideColor: Int,
        private val glossy: Boolean = true
    ) : Drawable() {
        private val sidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = sideColor }
        private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val glossPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f }
        private val rect = RectF()

        override fun onBoundsChange(b: Rect) {
            face.setBounds(b.left, b.top, b.right, (b.bottom - depth).toInt().coerceAtLeast(b.top + 1))
            val h = (b.height() - depth).coerceAtLeast(1f)
            glossPaint.shader = LinearGradient(0f, b.top.toFloat(), 0f, b.top + h * 0.55f,
                0x55FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
            rimPaint.shader = LinearGradient(0f, b.top.toFloat(), 0f, b.top + h,
                0xAAFFFFFF.toInt(), 0x11FFFFFF, Shader.TileMode.CLAMP)
            edgePaint.shader = LinearGradient(0f, b.top + h, 0f, b.bottom.toFloat(),
                shade(sideColor, 1.25f), shade(sideColor, 0.8f), Shader.TileMode.CLAMP)
        }

        override fun draw(c: Canvas) {
            val b = bounds
            // side wall (offset down by depth)
            rect.set(b.left.toFloat(), b.top + depth, b.right.toFloat(), b.bottom.toFloat())
            c.drawRoundRect(rect, radius, radius, sidePaint)
            c.drawRoundRect(rect, radius, radius, edgePaint)
            // face
            face.draw(c)
            if (glossy) {
                val fh = (b.height() - depth)
                rect.set(b.left + 1f, b.top + 1f, b.right - 1f, b.top + fh - 1f)
                c.drawRoundRect(rect, radius, radius, glossPaint)
                c.drawRoundRect(rect, radius, radius, rimPaint)
            }
        }

        override fun getOutline(outline: Outline) {
            val b = bounds
            outline.setRoundRect(b.left, b.top, b.right, b.bottom, radius)
            outline.alpha = 0.9f
        }

        override fun setAlpha(a: Int) { face.alpha = a; sidePaint.alpha = a }
        override fun setColorFilter(cf: ColorFilter?) { face.colorFilter = cf }
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    /** Opaque rounded face with vertical light→dark gradient + depth. */
    fun raised(color: Int, radiusPx: Float, depthPx: Float): Drawable {
        if (Color.alpha(color) < 255 || radiusPx < 1f) {
            return GradientDrawable().apply { setColor(color); cornerRadius = radiusPx }
        }
        val face = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(tint(color, 0.20f), color, shade(color, 0.86f))).apply { cornerRadius = radiusPx }
        return Depth3DDrawable(face, radiusPx, depthPx, shade(color, 0.58f))
    }

    /** Gradient face (keeps the caller's gradient) with depth. */
    fun raisedGradient(orientation: GradientDrawable.Orientation, colors: IntArray, radiusPx: Float, depthPx: Float): Drawable {
        val face = GradientDrawable(orientation, colors).apply { cornerRadius = radiusPx }
        return Depth3DDrawable(face, radiusPx, depthPx, shade(colors.last(), 0.58f))
    }


    /** Dark-navy glass card with a glowing blue border and 3D depth (matches the LusoPro look). */
    fun neon(dark: Boolean, radiusPx: Float, depthPx: Float, strokePx: Float): Drawable {
        val top = if (dark) 0xFF1C3F86.toInt() else 0xFFFFFFFF.toInt()
        val bottom = if (dark) 0xFF0A1C47.toInt() else 0xFFDCECFF.toInt()
        val face = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = radiusPx
            setStroke(strokePx.toInt().coerceAtLeast(1), if (dark) 0xFF2F8CFF.toInt() else 0xFF7DB8FF.toInt())
        }
        return Depth3DDrawable(face, radiusPx, depthPx, if (dark) 0xFF040E2B.toInt() else 0xFF9FC4F0.toInt())
    }

    /** Circular progress ring with the percentage in the middle. */
    class RingView(ctx: Context) : View(ctx) {
        var percent = 0
        var textColor = Color.WHITE
        private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x33FFFFFF; strokeCap = Paint.Cap.ROUND }
        private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true }
        private val oval = RectF()
        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val sw = w * 0.13f
            track.strokeWidth = sw; arc.strokeWidth = sw
            oval.set(sw, sw, w - sw, height - sw)
            arc.shader = android.graphics.SweepGradient(w / 2, height / 2f, intArrayOf(0xFF2FD3FF.toInt(), 0xFF2F7BFF.toInt(), 0xFF2FD3FF.toInt()), null)
            c.drawOval(oval, track)
            c.save(); c.rotate(-90f, w / 2, height / 2f)
            c.drawArc(oval, 0f, 360f * percent / 100f, false, arc); c.restore()
            txt.color = textColor; txt.textSize = w * 0.26f
            c.drawText("$percent%", w / 2, height / 2f + txt.textSize * 0.35f, txt)
        }
    }

    // ---------- upgrade existing flat backgrounds ----------
    private fun upgradeBackground(v: View, density: Float) {
        val bg = v.background ?: return
        if (bg !is GradientDrawable) return                // already 3D / layered designs are left untouched
        val radius = try { bg.cornerRadius } catch (_: Throwable) { 0f }
        if (radius < 10f * density) return                  // skip ovals, tiny pills, flat panels
        val colors: IntArray? = try { bg.colors } catch (_: Throwable) { null }
        val solid: Int? = try { bg.color?.defaultColor } catch (_: Throwable) { null }
        val base = colors?.lastOrNull() ?: solid ?: return
        if (colors != null && colors.any { Color.alpha(it) < 255 }) return
        if (colors == null && Color.alpha(base) < 255) return
        val depth = (if (radius > 18f * density) 4f else 3f) * density
        v.background = Depth3DDrawable(bg, radius, depth, shade(base, 0.58f))
        if (v.elevation < 2f * density) v.elevation = 3f * density
        v.clipToOutline = false
    }

    // ---------- touch tilt (called from Activity.dispatchTouchEvent) ----------
    private var pressed: View? = null
    private val loc = IntArray(2)

    private fun skip(v: View) = v is EditText || v is ScrollView || v is HorizontalScrollView ||
        v is AbsListView || v is SeekBar

    private fun hit(v: View, x: Float, y: Float): View? {
        if (v.visibility != View.VISIBLE) return null
        v.getLocationOnScreen(loc)
        if (x < loc[0] || x > loc[0] + v.width || y < loc[1] || y > loc[1] + v.height) return null
        if (v is ViewGroup) {
            for (i in v.childCount - 1 downTo 0) hit(v.getChildAt(i), x, y)?.let { return it }
        }
        return if (v.isClickable && !skip(v)) v else null
    }

    fun track(root: View, ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                release(pressed); pressed = null
                val v = hit(root, ev.rawX, ev.rawY) ?: return
                pressed = v
                val d = v.resources.displayMetrics
                v.cameraDistance = 9000f * d.density
                v.getLocationOnScreen(loc)
                val nx = ((ev.rawX - loc[0]) / max(1, v.width) - 0.5f) * 2f      // -1..1
                val ny = ((ev.rawY - loc[1]) / max(1, v.height) - 0.5f) * 2f
                val big = v.width > d.widthPixels * 0.85f && v.height > d.heightPixels * 0.22f
                val tilt = if (big) 1.5f else 7f
                v.animate().cancel()
                v.animate().scaleX(if (big) 0.992f else 0.965f).scaleY(if (big) 0.992f else 0.965f)
                    .rotationY(nx * tilt).rotationX(-ny * tilt)
                    .translationZ(-2f * d.density).translationY(1.5f * d.density)
                    .setDuration(90).setInterpolator(DecelerateInterpolator()).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { release(pressed); pressed = null }
        }
    }

    private fun release(v: View?) {
        v ?: return
        v.animate().cancel()
        v.animate().scaleX(1f).scaleY(1f).rotationX(0f).rotationY(0f).translationZ(0f).translationY(0f)
            .setDuration(260).setInterpolator(OvershootInterpolator(2.2f)).start()
    }

    // ---------- entrance & idle animation ----------
    /** Card flips up from the floor with perspective; [index] staggers siblings. */
    fun enter(v: View, index: Int = 0) {
        v.cameraDistance = 9000f * v.resources.displayMetrics.density
        v.alpha = 0f; v.rotationX = -35f; v.translationY = 28f * v.resources.displayMetrics.density
        v.pivotY = 0f
        v.post {
            v.pivotY = v.height.toFloat()
            v.animate().alpha(1f).rotationX(0f).translationY(0f).setStartDelay(60L * index)
                .setDuration(420).setInterpolator(OvershootInterpolator(1.1f)).start()
        }
    }

    /** Gentle idle 3D bob/rotation (hero logo). Stops automatically when the view leaves the screen. */
    fun float(v: View) {
        v.cameraDistance = 9000f * v.resources.displayMetrics.density
        val dy = 3f * v.resources.displayMetrics.density
        val a1 = ObjectAnimator.ofFloat(v, View.TRANSLATION_Y, -dy, dy)
        val a2 = ObjectAnimator.ofFloat(v, View.ROTATION_Y, -10f, 10f)
        listOf(a1, a2).forEach { it.duration = 2200; it.repeatCount = ObjectAnimator.INFINITE; it.repeatMode = ObjectAnimator.REVERSE; it.start() }
        v.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(p0: View) {}
            override fun onViewDetachedFromWindow(p0: View) { a1.cancel(); a2.cancel() }
        })
    }

    // ---------- deepen a whole screen ----------
    fun deepen(root: View) {
        val density = root.resources.displayMetrics.density
        upgradeBackground(root, density)
        if (root is ViewGroup) {
            root.setOnHierarchyChangeListener(object : ViewGroup.OnHierarchyChangeListener {
                override fun onChildViewAdded(parent: View, child: View) { deepen(child) }
                override fun onChildViewRemoved(parent: View, child: View) {}
            })
            for (i in 0 until root.childCount) deepen(root.getChildAt(i))
        }
    }

    @Suppress("unused")
    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()
    @Suppress("unused")
    private fun clampDepth(r: Float) = min(max(r * 0.2f, 3f), 8f)
}
