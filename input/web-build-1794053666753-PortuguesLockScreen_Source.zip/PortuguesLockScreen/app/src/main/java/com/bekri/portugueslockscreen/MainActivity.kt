package com.bekri.portugueslockscreen

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val bg = 0xFF07162E.toInt()
        val white = 0xFFFFFFFF.toInt()
        val blue = 0xFF193B70.toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 56, 36, 36)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "Português\nLock Screen"
            textSize = 30f
            setTextColor(white)
            textAlignment = TextView.TEXT_ALIGNMENT_CENTER
        }
        val subtitle = TextView(this).apply {
            text = "تعلم البرتغالية كلما أضأت شاشة هاتفك"
            textSize = 17f
            setTextColor(0xFFD7E5FA.toInt())
            textAlignment = TextView.TEXT_ALIGNMENT_CENTER
            setPadding(0, 24, 0, 32)
        }
        val info = TextView(this).apply {
            text = "ستظهر بطاقة تعليمية في إشعارات شاشة القفل، مع جملة برتغالية وترجمتها العربية. اضغط «استمع» لسماع النطق."
            textSize = 16f
            setTextColor(white)
            setPadding(0, 0, 0, 28)
        }
        val start = Button(this).apply {
            text = "تفعيل بطاقات شاشة القفل"
            setBackgroundColor(blue)
            setTextColor(white)
            setOnClickListener { enableCards() }
        }
        val stop = Button(this).apply {
            text = "إيقاف الميزة"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenWakeService::class.java))
                Toast.makeText(this@MainActivity, "تم طلب إيقاف الخدمة", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(info)
        layout.addView(start, LinearLayout.LayoutParams(-1, -2))
        layout.addView(stop, LinearLayout.LayoutParams(-1, -2))
        setContentView(layout)
    }

    private fun enableCards() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 22)
            return
        }
        startServiceNow()
    }

    private fun startServiceNow() {
        val i = Intent(this, ScreenWakeService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        Toast.makeText(this, "تم تفعيل بطاقات التعلم", Toast.LENGTH_LONG).show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 22 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startServiceNow()
        else Toast.makeText(this, "اسمح بالإشعارات حتى تظهر البطاقة على شاشة القفل", Toast.LENGTH_LONG).show()
    }
}
