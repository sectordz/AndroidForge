package com.bekri.portugueslockscreen

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.speech.tts.TextToSpeech
import java.util.Locale

class CardActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            "SPEAK_PT" -> {
                val phrase = intent.getStringExtra("phrase") ?: return
                engineHolder?.shutdown()
                engineHolder = TextToSpeech(context.applicationContext) { status ->
                    if (status == TextToSpeech.SUCCESS) {
                        engineHolder?.language = Locale.forLanguageTag("pt-PT")
                        engineHolder?.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "phrase")
                    }
                }
            }
            "NEXT_CARD" -> {
                val i = Intent(context, ScreenWakeService::class.java)
                if (android.os.Build.VERSION.SDK_INT >= 26) context.startForegroundService(i)
                else context.startService(i)
            }
        }
    }
    companion object { @Volatile private var engineHolder: TextToSpeech? = null }
}
