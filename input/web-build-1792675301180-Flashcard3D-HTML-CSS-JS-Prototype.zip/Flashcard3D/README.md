# Flashcard 3D — HTML/CSS/JavaScript prototype

Standalone Android WebView project for a Portuguese/Arabic flashcard demo (`avô`).

## Technologies
- HTML5 for semantic structure
- CSS3 for neon styling, responsive layout, shadows, perspective, floating animation, and safe-height adaptation
- JavaScript for touch/mouse parallax, settings, navigation feedback, and speech controls
- Android WebView + native Android TextToSpeech bridge for Portuguese/Arabic pronunciation

## Run
Open the `Flashcard3D` folder in Android Studio and build/run the app.

Note: the current grandpa artwork is a transparent 2D cutout with CSS perspective/parallax effects. A truly rotatable 3D character requires a rigged GLB/glTF model and a renderer such as Three.js/WebGL; that model is not included in this prototype yet. The page works offline because all UI and artwork are bundled locally.
