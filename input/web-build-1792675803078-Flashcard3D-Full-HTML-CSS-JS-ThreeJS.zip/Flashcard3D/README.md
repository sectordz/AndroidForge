# Flashcard 3D — HTML/CSS/JavaScript + Three.js prototype

This is a standalone Android WebView app. The full learning interface is implemented in HTML5, CSS3, and JavaScript. Android/Kotlin remains only as the app shell and native Portuguese/Arabic text-to-speech bridge.

## Technologies
- HTML5: card structure and bilingual content
- CSS3: responsive layout, neon glass panels, 3D-like lighting, mobile-safe sizing and fallback animation
- JavaScript: interaction, settings, navigation feedback, audio controls and pointer/touch response
- Three.js/WebGL: transparent character artwork rendered as a textured plane in a 3D scene with perspective, floating animation and touch/mouse tilt
- GLB/glTF support is the next step for a genuinely modelled, rotatable character. The included grandfather artwork is still a transparent 2D cutout rendered in 3D space, not a rigged 3D character model.
- Android WebView + Kotlin TextToSpeech bridge

## Build
Open the `Flashcard3D` folder in Android Studio and run/build the app. Internet access is currently used to load Three.js from jsDelivr. If that CDN is unavailable, the bundled CSS image fallback still displays the card.

## Notes
- The app has one sample word: `avô` (الجدّ), one Portuguese example and Arabic translation.
- The project is source code; a successful APK build has not been verified in this environment.
