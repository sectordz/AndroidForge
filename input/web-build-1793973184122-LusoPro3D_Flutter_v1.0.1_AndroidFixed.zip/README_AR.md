# LusoPro 3D — Flutter + Dart v1.0.1

## إصلاح مشكلة AndroidForge
تمت إضافة هيكل منصة Android الذي كان مفقودًا:
- `android/settings.gradle`
- `android/build.gradle`
- `android/app/build.gradle`
- `android/app/src/main/AndroidManifest.xml`
- `MainActivity.kt` وملفات موارد Android
- `android/gradle/wrapper/gradle-wrapper.properties`

هذه الملفات تجعل المشروع معروفًا كمشروع Flutter Android بدل أن يكون مجلد Dart فقط.

## محتويات التطبيق
- واجهات Flutter عربية داكنة بطابع زجاجي.
- الصفحات الرئيسية، الدروس، القاموس، البطاقات، والتقدم.
- SQLite مع فهرس FTS4 للبحث المحلي.
- عينة كلمات وأمثلة عربية/برتغالية.
- نطق PT-PT عبر flutter_tts بحسب الأصوات المثبتة على الجهاز.

## البناء
يجب أن تكون Flutter SDK مثبتة في بيئة البناء. استخدم:
```bash
flutter pub get
flutter build apk --debug
```
أو من Android Studio افتح مجلد المشروع الذي يحتوي `pubspec.yaml`.

## سهولة التعديل
- `lib/main.dart`: الشاشات ومنطق التطبيق.
- `pubspec.yaml`: الحزم والإعدادات.
- `assets/images/`: الصور.
- `android/`: إعدادات بناء Android.

## ملاحظات
- هذه نسخة أولية؛ القاموس الحالي عينة صغيرة وليس 20,000 كلمة.
- لم أتمكن من تشغيل Flutter أو بناء APK في بيئة الإنشاء الحالية لعدم توفر Flutter SDK. يجب تأكيد البناء في AndroidForge.
- أصول الصور ثلاثية الأبعاد الحقيقية لكل مفردة/درس ما زالت مرحلة لاحقة؛ التصميم الحالي يستخدم رموزًا توضيحية.
