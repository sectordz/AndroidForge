package com.lusopro.threed

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
